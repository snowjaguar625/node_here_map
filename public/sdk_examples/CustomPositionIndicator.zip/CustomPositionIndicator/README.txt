/*
 * Copyright (c) 2011-2017 HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */

### CustomPositionIndicator ###

===========================================================================
DESCRIPTION:

Simple ObjC sample app to show how to use custom position indicator with NMAMapLocalModel

===========================================================================
INSTRUCTIONS (CocoaPods)

1) Run "pod install" or "pod update" in the root "CustomPositionIndicator" folder to install
   the HERE SDK.

2) In the "General" settings of the App target:
    - Select an eligible provisioning profile or enable "Automatically
      manage signing".

3) In HelloMapAppDelegate.m:
    - Enter an app id, app code and license key.

===========================================================================
BUILD REQUIREMENTS:

* Xcode 8 & iOS 9 SDK or above
* HERE Premium SDK Version 3.4 or above

===========================================================================
TARGET PLATFORM:

* iOS 9.0 and above
