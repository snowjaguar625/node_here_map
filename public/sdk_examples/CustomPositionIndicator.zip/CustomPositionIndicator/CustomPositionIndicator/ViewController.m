//
//  ViewController.m
//  CustomPositionIndicator
//
//  Created by Lee, Ian on 08/08/2017.
//  Copyright © 2017 Lee, Ian. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>
#import <CoreMotion/CoreMotion.h>

@import NMAKit;

@interface ViewController ()<CLLocationManagerDelegate>
@property (weak, nonatomic) IBOutlet NMAMapView* mapView;
@property (nonatomic) NMAPositioningManager* positionManager;
@property (nonatomic, strong) CLLocationManager *locationManager;

@end

@implementation ViewController {
    
    NMAGeoCoordinates* _geoCoord;
    NMAMapLocalModel* _customPosIndicator;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //create geo coordinate
    _geoCoord = [[NMAGeoCoordinates alloc] initWithLatitude:52.500556 longitude:13.398889];
    // set map view with geo center
    [self.mapView setGeoCenter:_geoCoord];
    [self.mapView setZoomLevel:13.2];
    
    if ([[NMAPositioningManager sharedPositioningManager] startPositioning]) {
        // Register to positioning manager notifications
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(positionDidUpdate) name:NMAPositioningManagerDidUpdatePositionNotification object:[NMAPositioningManager sharedPositioningManager]];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didLosePosition) name:NMAPositioningManagerDidLosePositionNotification object:[NMAPositioningManager sharedPositioningManager]];
        self.positionManager = [NMAPositioningManager sharedPositioningManager];
    }
    
    self.locationManager = [[CLLocationManager alloc] init];
    
    self.locationManager.delegate = self;
    
    self.mapView.positionIndicator.visible = YES;
    self.mapView.positionIndicator.accuracyIndicatorVisible = YES;
    self.mapView.positionIndicator.tracksCourse = NO;
    
    _customPosIndicator = nil;
    [self createCustomPositionIndicator];
    
    [self.locationManager startUpdatingHeading];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateHeading:(nonnull CLHeading *)newHeading {
    NSLog(@"%f", newHeading.magneticHeading);
    if(_customPosIndicator != nil){
        [_customPosIndicator setYaw:newHeading.magneticHeading];
    }
}

- (void) viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

- (void) viewWillDisappear:(BOOL)animated
{
    [[NMAPositioningManager sharedPositioningManager] stopPositioning];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NMAPositioningManagerDidUpdatePositionNotification object:[NMAPositioningManager sharedPositioningManager]];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NMAPositioningManagerDidLosePositionNotification object:[NMAPositioningManager sharedPositioningManager]];
}

// Handle NMAPositioningManagerDidUpdatePositioinNotification
- (void) positionDidUpdate
{
    NMAGeoPosition *position = [[NMAPositioningManager sharedPositioningManager] currentPosition];
    [self.mapView setGeoCenter:position.coordinates withAnimation:NMAMapAnimationLinear];
}

// Handle NMAPositioningManagerDidLosePositionNotification
- (void) didLosePosition
{
    
}

/**
 * create a NMAMapMarker object, then add it to current active map view.
 */
- (void)createCustomPositionIndicator {
    if (_customPosIndicator == nil) {
        NMAFloatMesh *mesh = [[NMAFloatMesh alloc] init];
        
        float size = 5.0f;
        
        float vertices[4 * 3] = {-size / 2,   -size/2, 0.0f,
            -size/2,   size / 2, 0.0f,
            size / 2,   -size/2, 0.0f,
            size/2,   size/2, 0.0f,
        };
        
        [mesh setVertices:vertices withCount:4];
        
        float textureCoordinates[4 * 2] = {0.0,  0.0,
            0.0,  1.0,
            1.0,  0.0,
            1.0,  1.0};
        
        [mesh setTextureCoordinates:textureCoordinates withCount:4];
        
        short triangles[2 * 3] = {2, 1, 0,
            1, 2, 3};
        
        [mesh setTriangles:triangles withCount:2];
        
        _customPosIndicator = [[NMAMapLocalModel alloc] initWithMesh:mesh];
        
        NMAImage *image = [NMAImage imageWithUIImage:[UIImage imageNamed:@"256-256-pin2.png"]];
        
        /*
         // To load svg file as a custom position indicator, please use this code.
         NSBundle* main = [NSBundle mainBundle];
         NSString *resourcePath = [main pathForResource:@"tracker-1093167" ofType:@"svg"];
         
         NSLog(@"resourcePath: %@", resourcePath);
         NSData *resourceData = [NSData dataWithContentsOfFile:resourcePath];
         NMAImage *image = [NMAImage imageWithData:resourceData];
         */
        
        [_customPosIndicator setAutoscaled:true];
        [_customPosIndicator setTexture:image];
        [_customPosIndicator setCoordinates:[NMAGeoCoordinates alloc]];
        
        self.mapView.positionIndicator.displayObject = _customPosIndicator;
        
        self.mapView.positionIndicator.visible = true;
        
    }
}

@end
