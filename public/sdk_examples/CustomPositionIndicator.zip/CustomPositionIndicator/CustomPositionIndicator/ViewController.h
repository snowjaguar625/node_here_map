//
//  ViewController.h
//  CustomPositionIndicator
//
//  Created by Lee, Ian on 08/08/2017.
//  Copyright © 2017 Lee, Ian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

