//
//  main.m
//  CustomPositionIndicator
//
//  Created by Lee, Ian on 08/08/2017.
//  Copyright © 2017 Lee, Ian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
