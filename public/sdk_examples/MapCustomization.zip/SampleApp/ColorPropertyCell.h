/***************************************************************
 * Copyright © 2011-2016 HERE Global B.V. All rights reserved. *
 **************************************************************/

#import <UIKit/UIKit.h>
@class ColorPropertyCell;
@class NMACustomizableColor;

@protocol ColorPropertyCellDelegate <NSObject>
- (void)dataUpdatedFromCell:(ColorPropertyCell*) cell;
@end

@interface ColorPropertyCell : UITableViewCell<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UILabel *propertyNameLabel;
@property (weak, nonatomic) IBOutlet UITextField *redTextField;
@property (weak, nonatomic) IBOutlet UITextField *greenTextField;
@property (weak, nonatomic) IBOutlet UITextField *blueTextField;

@property (weak, nonatomic) id<ColorPropertyCellDelegate> delegate;

@property NSUInteger property;

-(void)setupCellWithProperty:(NSUInteger) propertyIdentifier
                     withRed:(int) red
                   withGreen:(int) green
                    withBlue:(int) blue
                andNameLabel:(NSString*) nameLabel;

@end