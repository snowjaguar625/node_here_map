//
//  AppDelegate.m
//  SampleApp

#import "AppDelegate.h"
#import <NMAKit/NMAKit.h>

#define kSampleAppID @""
#define kSampleAppCode @""
#define kSampleLicenseKey @""

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [NMAApplicationContext setAppId:kSampleAppID appCode:kSampleAppCode licenseKey:kSampleLicenseKey];

    return YES;
}

-(void)applicationDidEnterBackground:(UIApplication *)application
{
    [[NMAPositioningManager sharedPositioningManager] stopPositioning];
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    if (![[NMAPositioningManager sharedPositioningManager] isActive])
    {
        [[NMAPositioningManager sharedPositioningManager] startPositioning];
    }
}

@end
