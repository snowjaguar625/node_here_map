/***************************************************************
 * Copyright © 2011-2016 HERE Global B.V. All rights reserved. *
 **************************************************************/

#import <UIKit/UIKit.h>
@class PrimitivePropertyCell;

@protocol PrimitivePropertyCellDelegate <NSObject>
- (void)dataUpdatedToValue:(NSString*)textFieldValue
                  fromCell:(PrimitivePropertyCell*) cell;
@end

@interface PrimitivePropertyCell : UITableViewCell<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *valueTextField;
@property (weak, nonatomic) IBOutlet UILabel *propertyNameLabel;
@property (weak, nonatomic) id<PrimitivePropertyCellDelegate> delegate;

@property NSUInteger cellPropertyType;
@property NSUInteger propertyIndex;
@property NSInteger property;

-(void)setupCellForPropertyType:(NSUInteger) propertyType
                  fromIndexPath:(NSUInteger) fromPropertyIndex
                  withNameLabel:(NSString*) nameLabel
                   withProperty:(NSUInteger) theProperty
             withTextFieldValue:(NSString*) textFieldValue;


@end