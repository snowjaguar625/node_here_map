//
//  MainViewController.h
//  SampleApp

#import <UIKit/UIKit.h>
#import <NMAKit/NMAKit.h>
#import <QuartzCore/QuartzCore.h>
#import "PrimitivePropertyCell.h"
#import "ColorPropertyCell.h"

@class SharedMemory;

@interface MainViewController : UIViewController<NMAMapViewDelegate, NMAMapGestureDelegate,
                                                 UITableViewDelegate,  UITableViewDataSource,
                                                 UISearchResultsUpdating,
                                                 PrimitivePropertyCellDelegate, ColorPropertyCellDelegate>
{
    SharedMemory * sharedMemory;
    NMACustomizableScheme *customScheme;
    UISearchController *searchController;
    UITableViewController *resultsController;
}

//UI controls
@property (weak, nonatomic) IBOutlet UITableView *customizationTableView;
@property (weak, nonatomic) IBOutlet UIButton *myLocationButton;
@property (weak, nonatomic) IBOutlet UILabel *zoomLevelLabel;
@property (nonatomic) UISlider * zoomSlider;
@property (weak, nonatomic) IBOutlet UIToolbar *myToolBar;


@property NMAZoomRange *currentZoomRange;
@property (nonatomic) NSDictionary *allCustomizableProperties;
@property (nonatomic) NSMutableArray *sortedCustomizableProperties;
@property (nonatomic) NSMutableArray *filteredCustomizableProperties;

- (IBAction)centerTouched:(id)sender;


@end
