/***************************************************************
 * Copyright © 2011-2016 HERE Global B.V. All rights reserved. *
 **************************************************************/

#import "ColorPropertyCell.h"
#import <NMAKit/NMACustomizableVariable.h>

@implementation ColorPropertyCell

@synthesize property;

-(void)awakeFromNib
{
    //setup target/actions
    [self.redTextField addTarget:self action:@selector(colorPropertyChanged:) forControlEvents:UIControlEventEditingChanged];
    [self.greenTextField addTarget:self action:@selector(colorPropertyChanged:) forControlEvents:UIControlEventEditingChanged];
    [self.blueTextField addTarget:self action:@selector(colorPropertyChanged:) forControlEvents:UIControlEventEditingChanged];
}

-(void)setupCellWithProperty:(NSUInteger) propertyIdentifier
                     withRed:(int) red
                   withGreen:(int) green
                    withBlue:(int) blue
               andNameLabel:(NSString*) nameLabel
{
    self.property = propertyIdentifier;
    self.propertyNameLabel.text = nameLabel;
    
    [self.redTextField setText: [NSString stringWithFormat:@"%li", (long)red]];
    [self.greenTextField setText: [NSString stringWithFormat:@"%li", (long)green]];
    [self.blueTextField setText: [NSString stringWithFormat:@"%li", (long)blue]];
    
    //setup ui delegates
    self.redTextField.delegate = self;
    self.greenTextField.delegate = self;
    self.blueTextField.delegate = self;
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

-(void)colorPropertyChanged:(UITextField *)textField
{
    [self.delegate dataUpdatedFromCell:self];
}


-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}


@end
