//
//  MainViewController.m
//  SampleApp

#import "MainViewController.h"
#import <NMAKit/NMAKit.h>
#import <NMAKit/NMACustomizableScheme.h>

const int kDefaultNavigationTilt = 70;
const float kMapInitialZoomLevel = 2.0f;

static NSString *kPrimitiveCellIdentifier = @"primitiveCellIdentifier";
static NSString *kColorIdentifier = @"colorCellIdentifier";

@interface MainViewController ()

typedef NS_ENUM(NSUInteger, FilterType) {
    kFloatProperty = 0,
    kIntegerProperty,
    kColorProperty,
    kAllProperties,
    __numberOfProperties
};
@property (weak, nonatomic) IBOutlet NMAMapView *mapView;
@end

@implementation MainViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self mapViewSetup];
    self.myLocationButton.layer.cornerRadius = 8;
    self.myLocationButton.clipsToBounds = YES;
    
    [self centerTouched:self];
    
    //configure UITableView
    self.customizationTableView.delegate = self;
    self.customizationTableView.dataSource = self;
    self.customizationTableView.rowHeight = UITableViewAutomaticDimension;
    self.customizationTableView.estimatedRowHeight = 60.0;
    
    //setup zoom slider
    self.zoomSlider = [[UISlider alloc] init];
    [self.zoomSlider addTarget:self action:@selector(zoomSliderChangedValue:) forControlEvents:UIControlEventValueChanged];
    [self.zoomSlider setMinimumValue:0.0];
    [self.zoomSlider setMaximumValue:20.0];
    UIBarButtonItem *sliderToolBar = [[UIBarButtonItem alloc] initWithCustomView:self.zoomSlider];
    [sliderToolBar setWidth:150.0];
    NSArray *toolBarButtons = @[sliderToolBar];
    [self.myToolBar setItems: toolBarButtons];
    
    //set initial zoom
    [self.mapView setZoomLevel: kMapInitialZoomLevel];
    [self.zoomSlider setValue:kMapInitialZoomLevel];
    [self.zoomLevelLabel setText:[NSString stringWithFormat:@"Zoom Level: %.2f", kMapInitialZoomLevel]];
    
    //initialize custom scheme
    customScheme = [self.mapView getCustomizableSchemeWithName:@"aNewCustomScheme"];
    if (!customScheme) {
        customScheme = [self.mapView createCustomizableSchemeWithName:@"aNewCustomScheme" basedOnScheme:[self.mapView mapScheme]];
    }
    [self.mapView setMapScheme:@"aNewCustomScheme"];
    
    //setup zoom range which is used when modifying a property, currently changing a property affects all zoom levels:
    _currentZoomRange = [[NMAZoomRange alloc] init];
    _currentZoomRange.min = 0;
    _currentZoomRange.max = 20;
    
    //setup properties list
    
    //fetch all available properties
    self.allCustomizableProperties = [NMACustomizableVariable allAvailableProperties];
    NSArray *sortedKeys = [[self.allCustomizableProperties allKeys] sortedArrayUsingSelector:@selector(compare:)];
    self.sortedCustomizableProperties = [NSMutableArray array];
    for (NSString *key in sortedKeys) {
        [self.sortedCustomizableProperties addObject:[self.allCustomizableProperties objectForKey:key]];
    }
    
    //allocate array for search results
    self.filteredCustomizableProperties = [[NSMutableArray alloc] init];
    
    searchController = [[UISearchController alloc] initWithSearchResultsController:nil];
    searchController.hidesNavigationBarDuringPresentation = NO;
    searchController.searchBar.searchBarStyle = UISearchBarStyleMinimal;
    searchController.dimsBackgroundDuringPresentation = NO;
    
    searchController.searchResultsUpdater = self;
    [searchController.searchBar sizeToFit];
    [searchController.searchBar setBackgroundColor: [UIColor whiteColor]];
    [self.customizationTableView setTableHeaderView: searchController.searchBar];
    
    [self.customizationTableView reloadData];
}

-(void)mapViewSetup
{
    //set geo center
    if(![[NMAPositioningManager sharedPositioningManager] startPositioning])
        NSLog(@"Warning: Could not start positioning..");
    else NSLog(@"NMAPositioningManager started..");
    
    [self.mapView setGeoCenter:[self getCurrentPosition] withAnimation:NMAMapAnimationNone];
    self.mapView.copyrightLogoPosition = NMALayoutPositionBottomCenter;
    
    self.mapView.projectionType = NMAProjectionTypeGlobe;
    self.mapView.delegate = self;
    
    [self.mapView setCopyrightLogoPosition: NMALayoutPositionCenterRight];
    self.mapView.positionIndicator.visible = YES;
    
    [_mapView respondToEvents: NMAMapEventZoomLevelChanged
                    withBlock:^(NMAMapEvent event, NMAMapView *mapView, id eventData) {
                        [self updateUIZoomLevel];
                        return YES;
                    }];
}

-(void)viewDidAppear:(BOOL)animated
{
    [self setNeedsStatusBarAppearanceUpdate];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(positionUpdate)
                                                 name:NMAPositioningManagerDidUpdatePositionNotification
                                               object:[NMAPositioningManager sharedPositioningManager]];
}

-(void)viewDidDisappear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NMAPositioningManagerDidUpdatePositionNotification
                                                  object:[NMAPositioningManager sharedPositioningManager]];
}

-(void)positionUpdate
{
    //NMAGeoCoordinates *geoCoordCenter = nil;
    CGPoint screenCenter = CGPointMake(([UIScreen mainScreen].bounds.size.width)/2, ([UIScreen mainScreen].bounds.size.height)/2);
    
    NMAGeoPosition* pos = [[NMAPositioningManager sharedPositioningManager] currentPosition];
    if (pos)
    {
        NSLog(@"received position: %@", pos.coordinates);
    }
    else
    {
        NSLog(@"using mock position");
        pos = [NMAGeoPosition geoPositionWithCoordinates:[self getCurrentPosition] speed:0.0 course:0.0 accuracy:1.0];
    }
    [self.mapView setGeoCoordinates:pos.coordinates toPoint:screenCenter
                      withAnimation:NMAMapAnimationRocket zoomLevel:40
                        orientation:pos.course
                               tilt:kDefaultNavigationTilt];
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleDefault;
}

#pragma mark - UISlider actions

-(void)zoomSliderChangedValue:(id)sender
{
    UISlider *slider = (UISlider*)sender;
    float zoomLevel = slider.value;
    [self.mapView setZoomLevel:zoomLevel];
    [self updateUIZoomLevel];
}

-(void)updateUIZoomLevel
{
    float zoomLevel = self.mapView.zoomLevel;
    [self.zoomLevelLabel setText:[NSString stringWithFormat:@"Zoom Level: %.2f", zoomLevel]];
    [self.zoomSlider setValue:zoomLevel];
    [self.customizationTableView reloadData];
}

#pragma mark - UISearchViewController delegates

-(void)updateSearchResultsForSearchController:(UISearchController *)theSearchController
{
    NSString * searchString = theSearchController.searchBar.text;
    [self.filteredCustomizableProperties removeAllObjects];
    for (NSString * key in self.allCustomizableProperties) {
        if ([[key lowercaseString] containsString: [searchString lowercaseString]]) {
            [self.filteredCustomizableProperties addObject: [self.allCustomizableProperties objectForKey:key]];
        }
    }
    [self.customizationTableView reloadData];
}

#pragma mark - UITableViewDataSource

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NMACustomizableVariable *currentVariable;
    
    if (searchController.active && ![searchController.searchBar.text isEqualToString:@""])
    {
        currentVariable = [self.filteredCustomizableProperties objectAtIndex:indexPath.row];
    }
    else
    {
        currentVariable = [self.sortedCustomizableProperties objectAtIndex:indexPath.row];
    }
    
    switch (currentVariable.propertyType) {
        case NMACustomizableIntegerType:
            return 60.0;
            
        case NMACustomizableFloatType:
            return 60.0;
            
        case NMACustomizableColorType:
            return 100.0;
            
        default:
            return 0.0;
            break;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (searchController.active && ![searchController.searchBar.text isEqualToString:@""])
    {
        return [self.filteredCustomizableProperties count];
    }
    else
    {
        return [self.allCustomizableProperties count];
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return @"All Properties";
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //setup primitive  cell
    PrimitivePropertyCell *primitiveCell = [tableView dequeueReusableCellWithIdentifier:kPrimitiveCellIdentifier];
    if (primitiveCell == nil) {
        primitiveCell = [[[NSBundle mainBundle] loadNibNamed:@"PrimitivePropertyCell" owner:self options:nil] objectAtIndex:0];
    }
    
    //setup font color cell
    ColorPropertyCell *colorCell = [self.customizationTableView dequeueReusableCellWithIdentifier:kColorIdentifier];
    if (colorCell == nil) {
        colorCell = [[[NSBundle mainBundle] loadNibNamed:@"ColorPropertyCell" owner:self options:nil] objectAtIndex:0];
    }
    
    NMACustomizableVariable *currentVariable;
    
    if (searchController.active && ![searchController.searchBar.text isEqualToString:@""])
    {
        currentVariable = [self.filteredCustomizableProperties objectAtIndex:indexPath.row];
    }
    else
    {
        currentVariable = [self.sortedCustomizableProperties objectAtIndex:indexPath.row];
    }
    
    switch (currentVariable.propertyType)
    {
        case NMACustomizableIntegerType: {
            int intValue = [customScheme integerForProperty:(NMASchemeIntegerProperty)currentVariable.propertyIdentifier forZoomLevel:self.mapView.zoomLevel];
            
            [primitiveCell setupCellForPropertyType:kIntegerProperty fromIndexPath:indexPath.row
                                      withNameLabel:currentVariable.variableName
                                       withProperty:currentVariable.propertyIdentifier
                                 withTextFieldValue:[NSString stringWithFormat:@"%i", intValue]];
            primitiveCell.delegate = self;
            
            return primitiveCell;
        }
            
        case NMACustomizableFloatType: {
            float floatValue = [customScheme floatForProperty:(NMASchemeFloatProperty)currentVariable.propertyIdentifier forZoomLevel:self.mapView.zoomLevel];
            
            [primitiveCell setupCellForPropertyType:kFloatProperty fromIndexPath:indexPath.row
                                      withNameLabel:currentVariable.variableName
                                       withProperty:currentVariable.propertyIdentifier
                                 withTextFieldValue:[NSString stringWithFormat:@"%.2f", floatValue]];
            primitiveCell.delegate = self;
            
            return primitiveCell;
        }
            
        case NMACustomizableColorType: {
            NMACustomizableColor *customColor = [customScheme colorForProperty:(NMASchemeColorProperty)currentVariable.propertyIdentifier forZoomLevel:self.mapView.zoomLevel];
            [colorCell setupCellWithProperty:(NMASchemeColorProperty)currentVariable.propertyIdentifier
                                     withRed:(int)customColor.red withGreen:(int)customColor.green withBlue:(int)customColor.blue andNameLabel:currentVariable.variableName];
            colorCell.delegate = self;
            
            return colorCell;
        }
        default:
            return nil;
            break;
    }
}


#pragma mark - UITableViewCell delegates

//primitive cell delegate
- (void)dataUpdatedToValue:(NSString *)textFieldValue fromCell:(PrimitivePropertyCell *)cell
{
    switch ((FilterType)cell.cellPropertyType) {
        case kFloatProperty: {
            [customScheme setFloatProperty:(NMASchemeFloatProperty)cell.property
                                 withValue:[textFieldValue floatValue]
                              forZoomRange:_currentZoomRange];
            break;
        }
            
        case kIntegerProperty: {
            [customScheme setIntegerProperty:(NMASchemeIntegerProperty)cell.property
                                   withValue:[textFieldValue intValue]
                                forZoomRange:_currentZoomRange];
            break;
        }
            
        default:
            break;
    }
    [self.mapView setNeedsDisplay];
}

//Color cell delegate
- (void)dataUpdatedFromCell:(ColorPropertyCell *)cell
{
    NMACustomizableColor *color = [customScheme colorForProperty:(NMASchemeColorProperty)cell.property forZoomLevel:self.mapView.zoomLevel];
    
    [color setRed:[cell.redTextField.text integerValue]];
    [color setGreen:[cell.greenTextField.text integerValue]];
    [color setBlue:[cell.blueTextField.text integerValue]];
    
    [customScheme setColorProperty:color forZoomRange:_currentZoomRange];
    [self.mapView setNeedsDisplay];
}

#pragma mark - user action handling

- (IBAction)centerTouched:(id)sender
{
    [self.mapView setGeoCenter:[self getCurrentPosition] withAnimation:NMAMapAnimationLinear];
}

//utility method
-(NMAGeoCoordinates*)getCurrentPosition
{
    NMAGeoCoordinates *geoCoordCenter = nil;
    NMAGeoPosition* pos = [[NMAPositioningManager sharedPositioningManager] currentPosition];
    if (pos)
    {
        //Using current position..
        geoCoordCenter = pos.coordinates;
    }
    else //Use mock position
    {
        geoCoordCenter = [[NMAGeoCoordinates alloc] initWithLatitude:52.530421 longitude:13.385141];
    }
    return geoCoordCenter;
}

@end

