/***************************************************************
 * Copyright © 2011-2016 HERE Global B.V. All rights reserved. *
 **************************************************************/

#import "PrimitivePropertyCell.h"

@implementation PrimitivePropertyCell

@synthesize cellPropertyType;
@synthesize propertyIndex;
@synthesize property;
@synthesize valueTextField;

-(void)awakeFromNib
{
    [self.valueTextField addTarget:self action:@selector(textChanged:) forControlEvents:UIControlEventEditingChanged];
}

-(void)setupCellForPropertyType:(NSUInteger) propertyType
                  fromIndexPath:(NSUInteger) fromPropertyIndex
                  withNameLabel:(NSString*) nameLabel
                   withProperty:(NSUInteger) theProperty
             withTextFieldValue:(NSString*) textFieldValue
{
    self.valueTextField.delegate = self;
    self.cellPropertyType = propertyType;
    self.propertyIndex = fromPropertyIndex;
    self.property = theProperty;
    self.propertyNameLabel.text = nameLabel;
    self.valueTextField.text = textFieldValue;
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

-(void)textChanged:(UITextField *)textField
{
    [self.delegate dataUpdatedToValue:textField.text fromCell:self];
}


-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}


@end
