package com.here.tcsdemo;

import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.here.android.mpa.common.GeoCoordinate;
import com.here.android.mpa.common.GeoPosition;
import com.here.android.mpa.common.OnEngineInitListener;
import com.here.android.mpa.common.PositioningManager;
import com.here.android.mpa.mapping.LocalMesh;
import com.here.android.mpa.mapping.Map;
import com.here.android.mpa.mapping.MapCircle;
import com.here.android.mpa.mapping.MapFragment;
import com.here.android.mpa.mapping.MapLocalModel;
import com.here.android.mpa.mapping.MapOverlayType;

import java.lang.ref.WeakReference;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();

    // map embedded in the map fragment
    private Map m_map = null;

    // map fragment embedded in this activity
    private MapFragment mapFragment = null;

    // helper for the very first fix after startup (we want to jump to that position then)
    private boolean firstPositionSet = false;

    // custom position marker
    private MapCircle m_PositionMarker;
    private MapCircle m_PositionAccuracyIndicator;
    private MapLocalModel m_PositionMesh;

    // compass sensors
    private SensorManager mSensorManager;
    private Sensor mAccelerometer;
    private Sensor mMagnetometer;

    // compass data
    private float mAzimuth;
    private float[] mGravity = new float[3];
    private float[] mGeomagnetic = new float[3];
    // listen for sensor updates
    private SensorEventListener sensorHandler = new SensorEventListener() {

        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {

            final float alpha = (float) 0.8;
            synchronized (this) {

                if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                    // Isolate the force of gravity with the low-pass filter. See Android documentation for details:
                    // http://developer.android.com/guide/topics/sensors/sensors_motion.html#sensors-motion-accel
                    mGravity[0] = alpha * mGravity[0] + (1 - alpha) * sensorEvent.values[0];
                    mGravity[1] = alpha * mGravity[1] + (1 - alpha) * sensorEvent.values[1];
                    mGravity[2] = alpha * mGravity[2] + (1 - alpha) * sensorEvent.values[2];
                }

                if (sensorEvent.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
                    mGeomagnetic = sensorEvent.values.clone();
                }
            }

            if (mGravity != null && mGeomagnetic != null) {
                float R[] = new float[9];
                float I[] = new float[9];

                if (SensorManager.getRotationMatrix(R, I, mGravity, mGeomagnetic)) {
                    float[] mOrientation = new float[3];
                    SensorManager.getOrientation(R, mOrientation); // mOrientation contains: azimuth, pitch and roll

                    mAzimuth = (float) Math.toDegrees(mOrientation[0]);
                    //float mPitch = (float) Math.toDegrees(mOrientation[1]);
                    //float mRoll = (float) Math.toDegrees(mOrientation[2]);
                    //float mInclination = (float) Math.toDegrees(SensorManager.getInclination(I));

                    if (mAzimuth < 0.0f) {
                        mAzimuth += 360.0f;
                    }

                    Log.v(TAG, "Rotate to " + mAzimuth);

                    // set yaw of our 3D position indicator to indicate compass direction
                    if (m_PositionMesh != null)
                        m_PositionMesh.setYaw(-mAzimuth);  // Think about animation and less updates here in production environments
                }
            }

        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {
            Log.d(TAG, "Accuracy changed for " + sensor.getName() + " to " + i);
        }
    };
    // listen for positioning events
    private PositioningManager.OnPositionChangedListener mapPositionHandler = new PositioningManager.OnPositionChangedListener() {
        @Override
        public void onPositionUpdated(PositioningManager.LocationMethod method, GeoPosition position, boolean isMapMatched) {

            if (!position.isValid())
                return;

            if (!firstPositionSet) {
                m_map.setCenter(position.getCoordinate(), Map.Animation.BOW);
                firstPositionSet = true;
            }

            // get the new coordinate
            GeoCoordinate pos = position.getCoordinate();

            // set custom position indicator and accuracy indicator
            m_PositionMarker.setCenter(pos);
            m_PositionMesh.setAnchor(pos);
            m_PositionAccuracyIndicator.setCenter(pos);
            m_PositionAccuracyIndicator.setRadius(position.getLatitudeAccuracy());
        }

        @Override
        public void onPositionFixChanged(PositioningManager.LocationMethod method, PositioningManager.LocationStatus status) {
            Log.i(TAG, "Position fix changed : " + status.name() + " / " + method.name());
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.d(TAG, "onCreate");

        setContentView(R.layout.activity_main);

        // get the system sensors for compass
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mMagnetometer = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

        // Search for the map fragment to finish setup by calling init().
        mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.mapfragment);
        mapFragment.init(new OnEngineInitListener() {
            @Override
            public void onEngineInitializationCompleted(Error error) {
                if (error == Error.NONE) {

                    Log.i(TAG, "HERE Map initialized");

                    // get and store map instance since we need it more often
                    m_map = mapFragment.getMap();

                    // more map settings
                    m_map.setProjectionMode(Map.Projection.GLOBE);  // globe projection
                    m_map.setExtrudedBuildingsVisible(true);  // enable 3D building footprints
                    m_map.setLandmarksVisible(true);  // 3D Landmarks visible
                    m_map.setZoomLevel(16);  // set start zoom level to block-level
                    m_map.setMapScheme(Map.Scheme.NORMAL_DAY);   // normal day mapscheme

                    // This code would show SDK version of positioning indicator - in this demo we don't use it and create our own one afterwards
                    //
                    // m_map.getPositionIndicator().setVisible(true);
                    // m_map.getPositionIndicator().setAccuracyIndicatorVisible(true);
                    //

                    // create a 3D mesh as position marker, since we can then use yaw to rotate
                    createPositionMarkerMesh();

                    // create a custom position indicator dot
                    m_PositionMarker = new MapCircle();
                    m_PositionMarker.setFillColor(Color.argb(200, 0, 200, 0));
                    m_PositionMarker.setLineWidth(3);
                    m_PositionMarker.setLineColor(Color.BLACK);
                    m_PositionMarker.setRadius(3);

                    // create a custom accuracy indicator circle
                    m_PositionAccuracyIndicator = new MapCircle();
                    m_PositionAccuracyIndicator.setFillColor(Color.argb(70, 0, 200, 0)); // translucent
                    m_PositionAccuracyIndicator.setLineWidth(3);
                    m_PositionAccuracyIndicator.setLineColor(Color.BLACK);
                    m_PositionAccuracyIndicator.setRadius(20);
                    m_PositionAccuracyIndicator.setOverlayType(MapOverlayType.ROAD_OVERLAY); // put accuracy indicator behind buildings in render stack

                    // add this to the map. at this moment we still didn't define the position, we'll do this later on position updates
                    m_map.addMapObject(m_PositionAccuracyIndicator);
                    m_map.addMapObject(m_PositionMarker);

                    // setup positioning and event listener
                    // start() is also called in onResume() but this can't be called before init is done, so we also do it after initialization
                    PositioningManager.getInstance().addListener(new WeakReference<>(mapPositionHandler));
                    PositioningManager.getInstance().start(PositioningManager.LocationMethod.GPS_NETWORK); // use gps plus cell and wifi

                    // set to last known position, if available
                    GeoPosition lkp = PositioningManager.getInstance().getLastKnownPosition();
                    if (lkp != null && lkp.isValid()) {
                        m_map.setCenter(lkp.getCoordinate(), Map.Animation.NONE);

                        // set custom position indicator
                        m_PositionMarker.setCenter(lkp.getCoordinate());
                        m_PositionAccuracyIndicator.setCenter(lkp.getCoordinate());
                        m_PositionMesh.setAnchor(new GeoCoordinate(lkp.getCoordinate().getLatitude(), lkp.getCoordinate().getLongitude())); // ignoring altitude, since it would also set the imnage on this height
                    }
                } else {
                    Log.e(TAG, "ERROR: Cannot initialize Map Fragment - error: " + error.name());
                }
            }
        });
    }

    // create a very simple triangle to render on the map. normally you would exported a 3D model and use a 3D loader for this
    private void createPositionMarkerMesh() {

        FloatBuffer buff = FloatBuffer.allocate(9);

        buff.put(0);
        buff.put(0.5f);
        buff.put(0);
        buff.put(0.2f);
        buff.put(-0.3f);
        buff.put(0);
        buff.put(-0.2f);
        buff.put(-0.3f);
        buff.put(0);

        IntBuffer vertIndicieBuffer = IntBuffer.allocate(3);
        vertIndicieBuffer.put(2);
        vertIndicieBuffer.put(1);
        vertIndicieBuffer.put(0);

        LocalMesh myMesh = new LocalMesh();
        myMesh.setVertices(buff);
        myMesh.setVertexIndices(vertIndicieBuffer);

        m_PositionMesh = new MapLocalModel();
        m_PositionMesh.setMesh(myMesh);
        m_PositionMesh.setScale(7.0f);
        m_PositionMesh.setDynamicScalingEnabled(true); // keep size when zooming

        m_map.addMapObject(m_PositionMesh); // add mesh to map. we set position later when we have the first reliable information
    }

    @Override
    protected void onPause() {
        Log.d(TAG, "onPause");

        super.onPause();

        mSensorManager.unregisterListener(sensorHandler);

        if (m_map != null && PositioningManager.getInstance().isActive()) {
            PositioningManager.getInstance().stop();
        }

    }

    // Resume positioning listener on wake up
    @Override
    public void onResume() {
        super.onResume();

        Log.d(TAG, "onResume");

        // See: http://stackoverflow.com/questions/17337504/need-to-read-android-sensors-with-fixed-sampling-rate
        mSensorManager.registerListener(sensorHandler, mAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        mSensorManager.registerListener(sensorHandler, mMagnetometer, SensorManager.SENSOR_DELAY_NORMAL);

        if (m_map != null && !PositioningManager.getInstance().isActive()) {
            PositioningManager.getInstance().start(PositioningManager.LocationMethod.GPS_NETWORK); // use gps plus cell and wifi
        }
    }

    @Override
    protected void onDestroy() {
        Log.d(TAG, "onDestroy");

        if (m_map != null) {
            PositioningManager.getInstance().stop();
            PositioningManager.getInstance().removeListener(mapPositionHandler);
        }

        super.onDestroy();
    }

}
