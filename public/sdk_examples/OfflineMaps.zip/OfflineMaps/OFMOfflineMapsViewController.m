/*
 * Copyright © 2016 HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */

#import "OFMOfflineMapsViewController.h"
#import "OFMPackageCell.h"
#import "NMAMapPackage+Sort.h"
#import "colors.h"
#import "dbg.h"

#import <NMAKit/NMAKit.h>

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static NSString *SEGUE_SHOW_HUD = @"ShowHudFromOfflineMaps";

static NSString *STORYBOARD_IDENTIFIER = @"OfflineMaps";

static NSString *CELL_IDENTIFIER = @"PackageCell";

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@interface OFMOfflineMapsViewController () <UITableViewDataSource,
                                            UITableViewDelegate>

- (void)setup;

@property(nonatomic,strong) NSMutableArray *children;

// for the hud
@property (weak, nonatomic) IBOutlet UIView *containerView;

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@implementation OFMOfflineMapsViewController

#pragma mark - Public methods

- (void)viewDidLoad {
    [super viewDidLoad];

    [self setup];
}

- (void)didReceiveMemoryWarning {
    DBG_CALLED

    [super didReceiveMemoryWarning];
}

- (BOOL)prefersStatusBarHidden {
    return NO;
}

- (void)selectCell:(NSInteger)row {
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:0];

    [self.tableView selectRowAtIndexPath:indexPath
                                animated:FALSE
                          scrollPosition:UITableViewScrollPositionNone];
}

- (void)getPackages {
    if (![NMAApplicationContext isOnline]) {
        [self alertForNotOnline];
    }
    else {
        [self showHud];

        [[NMAMapLoader sharedMapLoader] getMapPackages];
    }
}

- (void)install:(NSInteger)row {
    // convert the row to the package
    NMAMapPackage *package = self.children[row];

    [self showHud];
    [self installPackage:package];
}

- (void)uninstall:(NSInteger)row {
    // convert the row to the package
    NMAMapPackage *package = self.children[row];

    [self showHud];
    [self uninstallPackage:package];
}

- (void)showHud {
    DBG_CALLED

    // disables
    self.navigationItem.leftBarButtonItem.enabled = NO;
    self.navigationItem.rightBarButtonItem.enabled = NO;

    // configure the hud
    [self.hudViewController reset];
    [self.hudViewController setTitle:@"Offline Maps"];
    [self.hudViewController setDetails:@"Initiating..."]; // whatever the task is ...

    // show the container view
    self.containerView.hidden = NO;
}

- (void)hideHud {
    DBG_CALLED

    // hide the container view
    self.containerView.hidden = YES;

    // enables
    self.navigationItem.leftBarButtonItem.enabled = YES;
    self.navigationItem.rightBarButtonItem.enabled = YES;
}

- (void)didGetPackages:(NSArray *)packages {
    DBG("package count:|%lu|\n", (unsigned long)packages.count)

    self.children = [NSMutableArray arrayWithArray:packages];

    // sort the tags
    [self.children sortUsingSelector:@selector(sortByTitle:)];

    [self.tableView reloadData];
}

- (void)showResult:(NMAMapLoaderResult)mapLoaderResult
      forOperation:(Operation)operation {
    DBG("result:|%ld|\n", (long)mapLoaderResult)

    // let the super class do the real work
    [super showResult:mapLoaderResult
         forOperation:operation];

    // if not updating and succeed, refresh the cell
    if (operation != kOperationUpdate ||
        mapLoaderResult == NMAMapLoaderResultSuccess) {
        NSIndexPath *indexpath = self.tableView.indexPathForSelectedRow;
        OFMPackageCell *cell = [self.tableView cellForRowAtIndexPath:indexpath];
        NMAMapPackage *package = self.children[indexpath.row];

        // either installed or uninstalled
        cell.installed = (package.installationStatus != NMAMapPackageInstallationNone);
    }
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    DBG("segue:|%@|\n", segue.identifier)

    if ([[segue identifier] isEqualToString:SEGUE_SHOW_HUD]) {
        // save the view controller which is hidden initially
        self.hudViewController = (CMNHudViewController *)[segue destinationViewController];
    }
}

#pragma mark - Private methods

- (void)setup {
    DBG_CALLED

    // trick: important!
    //        make sure to call it
    [super setup];

    // we are after an a all-white navigation bar
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.backgroundColor = [UIColor whiteColor];

    // if we have the parent, get its children
    // else we need to download the packages first
    if (self.parent) {
        DBG("\n"
            "....title:|%@|\n"
            "....children count:|%lu|\n",
            self.parent.title,
            (unsigned long)self.parent.children.count)

        self.children = [NSMutableArray arrayWithArray:self.parent.children];

        // sort the tags
        [self.children sortUsingSelector:@selector(sortByTitle:)];

        [self.tableView reloadData];
    }
    else {
        // trick: we don't need a back button as we are the initial
        //        view controller
        self.navigationItem.leftBarButtonItem = nil;

        // we need to get the packages first
        // note that this different then installing the packages...
        [self getPackages];
    }
}

#pragma mark - IBAction methods

- (IBAction)onBack:(UIBarButtonItem *)sender {
    DBG_CALLED

    [self.navigationController popViewControllerAnimated:TRUE];
}

- (IBAction)onUpdate:(UIBarButtonItem *)sender {
    DBG_CALLED

    if (![NMAApplicationContext isOnline]) {
        [self alertForNotOnline];
    }
    else if (![[NMAMapLoader sharedMapLoader] checkForMapDataUpdate]) {
        [self alertForUpdateFailure];
    }
    else {
        // trick: udpate check has started
        [self showHud];
    }
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    DBG_CALLED

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger count = self.children.count;

    DBG("count:|%ld|\n", (long)count)

    return count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    OFMPackageCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER
                                                          forIndexPath:indexPath];
    NMAMapPackage *package = self.children[indexPath.row];

    // configure the cell
    cell.title.text = package.title;
    cell.size.text = [NSString stringWithFormat:@"%d MB", (int)(package.sizeOnDisk/1024)];
    cell.row = indexPath.row;
    cell.installed = (package.installationStatus != NMAMapPackageInstallationNone);
    cell.hasChildren = (package.children.count > 0);
    cell.parent = self;

    DBG("\n"
        "....row:|%ld|\n"
        "....title:|%@|\n"
        "....children count:|%lu|\n",
        (long)indexPath.row,
        cell.title.text,
        (unsigned long)package.children.count)

    return cell;
}

#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    DBG_CALLED

    return 55.0f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NMAMapPackage *package = self.children[indexPath.row];

    DBG("\n"
        "....row:|%ld|\n"
        "....title:|%@|\n",
        (long)indexPath.row,
        package.title)

    if (package.children.count) {
        DBG("has children: go deeper!\n")

        // create the view controller from the storyboard
        OFMOfflineMapsViewController *vc = [self.storyboard
                                                instantiateViewControllerWithIdentifier:STORYBOARD_IDENTIFIER];

        // configure the view controller
        vc.parent = self.children[indexPath.row];

        // unleash the new view controller
        [self.navigationController pushViewController:vc animated:YES];
    }
    else {
        DBG("no children: do nothing...\n")
    }

    // trick: make sure to the selected row is completely
    //        visible!
    [self.tableView scrollToRowAtIndexPath:indexPath
                          atScrollPosition:UITableViewScrollPositionNone
                                  animated:FALSE];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    DBG_CALLED

    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 28)];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, tableView.frame.size.width - 10, 18)];

    // configure the label
    label.font = [UIFont boldSystemFontOfSize:15];
    label.text = (self.parent ? self.parent.title : @"Continents");
    label.textColor = [UIColor whiteColor];

    // configure the view
    [view setBackgroundColor:COLOR_HERE];
    [view addSubview:label];

    return view;
}

@end
