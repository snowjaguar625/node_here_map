/*
 * Copyright © 2016 HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// declaring them as "defines" is simpler than other options!

#define COLOR_HERE                           [UIColor colorWithRed:0.141 green:0.247 blue:0.557 alpha:1]

#define COLOR_LIGHT_BLUE_100                 [UIColor colorWithRed:0.702 green:0.898 blue:0.988 alpha:1]
