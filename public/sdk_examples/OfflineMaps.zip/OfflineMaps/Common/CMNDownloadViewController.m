/*
 * Copyright © 20YY-201X HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */ 

#import "CMNDownloadViewController.h"
#import "dbg.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@interface CMNDownloadViewController ()

@end

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@implementation CMNDownloadViewController

#pragma mark - Public methods

- (void)setup {
    DBG_CALLED

    // configure the map downloader
    [NMAMapLoader sharedMapLoader].delegate = self;
}

- (void)showHud {
    ASSERT(NO,  @"showHud method should be overriden by child class!\n")
}

- (void)hideHud {
    ASSERT(NO, @"hideHud method should be overriden by child class!\n")
}

- (void)showResult:(NMAMapLoaderResult)mapLoaderResult
      forOperation:(Operation)operation {
    DBG("\n"
        "....result:|%ld|\n"
        "....operation:|%ld|\n",
        (long)mapLoaderResult,
        (long)operation)

    // set the verdict
    switch (mapLoaderResult) {
        case NMAMapLoaderResultSuccess:
            [self.hudViewController setDetails:@"Succeeded"];

            // trick: make sure the progress bar looks
            //        completed!
            [self.hudViewController setProgress:1.0f];
            break;

        case NMAMapLoaderResultOperationCancelled:
            [self.hudViewController setDetails:@"Cancelled"];
            break;

        default:
            [self.hudViewController setDetails:@"Failed!"];
            break;
    }

    // done
    [self.hudViewController hideCancelButton:YES];

    // dismiss the hud after some time
    dispatch_time_t dismissTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC));

    dispatch_after(dismissTime, dispatch_get_main_queue(), ^(void) {
        [self hideHud];
    });
}

- (void)didGetPackages:(NSArray *)packages {
    ASSERT(NO, @"didGetPackages: method should be overriden by child class for accessing all the packages!\n")
}

- (void)installPackage:(NMAMapPackage *)package {
    // initiate installing the package operation
    [[NMAMapLoader sharedMapLoader] installMapPackages:@[package]];

    // update the hud
    NSString *details = [NSString stringWithFormat:@"Region: %@\nSize: %d MB",
                             package.title,
                             (int)(package.sizeOnDisk / 1024)];

    [self.hudViewController setDetails:details];

    DBG("\n"
        "%@", details)
}

- (void)uninstallPackage:(NMAMapPackage *)package {
    // initiate uninstalling the package operation
    [[NMAMapLoader sharedMapLoader] uninstallMapPackages:@[package]];

    // update the hud
    NSString *details = [NSString stringWithFormat:@"Region: %@\nSize: %d MB",
                             package.title,
                             (int)(package.sizeOnDisk / 1024)];

    [self.hudViewController setTitle:@"Uninstall"];
    [self.hudViewController setDetails:details];

    DBG("\n"
        "%@", details)
}

- (void)updateFromVersion:(NSString *)currentVersion toVersion:(NSString *)newestVersion {
    // initiate updating operation
    [[NMAMapLoader sharedMapLoader] performMapDataUpdate];

    // update the hud
    NSString *details = [NSString stringWithFormat:@"Current version: %@\nNew version: %@",
                             currentVersion,
                             newestVersion];

    [self.hudViewController setTitle:@"Update"];
    [self.hudViewController setDetails:details];

    DBG("\n"
        "%@", details)
}

#pragma mark - NMAMapLoaderDelegate

- (void)mapLoader:(NMAMapLoader *)mapLoader didUpdateProgress:(float)progress {
    DBG("progress:|%.0f%%|\n", progress * 100.0f)

    [self.hudViewController setProgress:progress];
}

- (void)mapLoader:(NMAMapLoader *)mapLoader didGetPackagesWithResult:(NMAMapLoaderResult)mapLoaderResult {
    DBG("result:|%lu|\n", (unsigned long)mapLoaderResult)

    [self showResult:mapLoaderResult
        forOperation:kOperationPackages];

    // are we succeeded in getting all the packages?
    if (mapLoaderResult == NMAMapLoaderResultSuccess) {
        [self didGetPackages:mapLoader.rootPackage.children];
    }
}

- (void)mapLoader:(NMAMapLoader *)mapLoader didInstallPackagesWithResult:(NMAMapLoaderResult)mapLoaderResult {
    DBG("result:|%lu|\n", (unsigned long)mapLoaderResult)

    [self showResult:mapLoaderResult
        forOperation:kOperationInstall];
}

- (void)mapLoader:(NMAMapLoader *)mapLoader didUninstallPackagesWithResult:(NMAMapLoaderResult)mapLoaderResult {
    DBG("result:|%lu|\n", (unsigned long)mapLoaderResult)

    [self showResult:mapLoaderResult
        forOperation:kOperationUninstall];
}

- (void)mapLoader:(NMAMapLoader *)mapLoader
    didFindUpdate:(BOOL)isUpdateAvailable
      fromVersion:(NSString *)currentMapVersion
        toVersion:(NSString *)newestMapVersion
       withResult:(NMAMapLoaderResult)mapLoaderResult {
    DBG(@"\n"
        "....update?|%@|\n"
        "....current map version:|%@|\n"
        "....newest map version:|%@\n"
        "....result:|%lu|\n",
        STRINGIZE_BOOL(isUpdateAvailable),
        currentMapVersion,
        newestMapVersion,
        (unsigned long)mapLoaderResult)

    if (mapLoaderResult != NMAMapLoaderResultSuccess) {
        [self showResult:NMAMapLoaderResultSearchFailed
            forOperation:kOperationUpdate];
    }
    else if (isUpdateAvailable) {
        [self updateFromVersion:currentMapVersion toVersion:newestMapVersion];
    }
    else {
        [self.hudViewController needCloseButton];
        [self.hudViewController setDetails:@"No update is available"];
    }
}

- (void)mapLoader:(NMAMapLoader *)mapLoader
 didGetUpdateSize:(NSUInteger)size
       withResult:(NMAMapLoaderResult)mapLoaderResult {
    DBG("\n"
        "....result:|%lu|\n"
        "....update size:|%lu|\n",
        (unsigned long)mapLoaderResult,
        (unsigned long)size)

    [self showResult:mapLoaderResult
        forOperation:kOperationUpdate];
}

- (void)mapLoader:(NMAMapLoader *)mapLoader didUpdateWithResult:(NMAMapLoaderResult)mapLoaderResult {
    DBG("result:|%lu|\n", (unsigned long)mapLoaderResult)

    [self showResult:mapLoaderResult
        forOperation:kOperationUpdate];
}

- (void)mapLoader:(NMAMapLoader *)mapLoader
 didGetMapPackage:(NMAMapPackage *)package
 atGeoCoordinates:(NMAGeoCoordinates *)coordinates
       withResult:(NMAMapLoaderResult)mapLoaderResult {
    DBG("\n"
        "....result:|%lu|\n"
        "....latitude:|%3.4f|\n"
        "....longitude:|%3.4f|\n",
        (unsigned long)mapLoaderResult,
        coordinates.latitude,
        coordinates.longitude)

    // are we succeeded in getting a single package?
    if (mapLoaderResult == NMAMapLoaderResultSuccess &&
        package) {
        // yes, proceed...
        [self installPackage:package];
    }
    else {
        // no, inform the user and automatically hide the hud
        [self showResult:NMAMapLoaderResultSearchFailed
            forOperation:kOperationPackage];
    }
}

- (void)mapLoaderDidLoseConnection:(NMAMapLoader *)mapLoader {
    DBG_CALLED
}

- (void)mapLoaderDidFindConnection:(NMAMapLoader *)mapLoader {
    DBG_CALLED
}

@end
