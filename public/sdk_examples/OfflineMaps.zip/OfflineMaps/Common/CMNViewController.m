/*
 * Copyright © 20YY-201X HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */ 

#import "CMNViewController.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@interface CMNViewController ()

- (void)showAlert:(NSString *)title;

@end

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@implementation CMNViewController

#pragma mark - Public methods

- (void)alertForNotOnline {
    [self showAlert:@"No Internet Connection!"];
}

- (void)alertForUnknownPosition {
    [self showAlert:@"The Current Position is Unknown!"];
}

- (void)alertForNavigationFailure {
    [self showAlert:@"Navigation Failed!"];
}

- (void)alertForUpdateFailure {
    [self showAlert:@"Unable to check! Please check later..."];
}

// for search failures
- (void)alertForSuggestionFailure {
    [self showAlert:@"Suggestion failed!"];
}

- (void)alertForEmailConfiguration {
    [self showAlert:@"Not Configured to Send Email!"];
}

- (void)alertForEmailFailure {
    [self showAlert:@"Failed to Send Email!"];
}

#pragma mark - Private methods

- (void)showAlert:(NSString *)title {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title
                                                                   message:nil
                                                            preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"OK"
                                                 style:UIAlertActionStyleDefault
                                               handler:nil];

    [alert addAction:ok];


    // trcik: when the ok button is tapped, the alert
    //        is dismissed automatically!
    [self presentViewController:alert animated:YES completion:nil];
}

@end
