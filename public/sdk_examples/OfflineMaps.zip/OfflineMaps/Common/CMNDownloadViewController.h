/*
 * Copyright © 20YY-201X HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */ 

#import "CMNViewController.h"
#import "CMNHudViewController.h"

#import <NMAKit/NMAKit.h>

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

typedef NS_ENUM(NSInteger, Operation) {
    kOperationPackage   = 0,
    kOperationPackages  = 1,
    kOperationInstall   = 2,
    kOperationUninstall = 3,
    kOperationUpdate    = 4
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//
// superclass implementing the NMAMapLoaderDelegate interface
// note that subclasses should implement showHud and hideHud methods
// and provide the hud object, i.e. hudViewController
//
@interface CMNDownloadViewController : CMNViewController <NMAMapLoaderDelegate>

- (void)setup;

// must be overriden always!
- (void)showHud;

// must be overriden always!
- (void)hideHud;

- (void)showResult:(NMAMapLoaderResult)mapLoaderResult
      forOperation:(Operation)operation;

- (void)didGetPackages:(NSArray *)packages;

- (void)installPackage:(NMAMapPackage *)package;

- (void)uninstallPackage:(NMAMapPackage *)package;

- (void)updateFromVersion:(NSString *)currentVersion toVersion:(NSString *)newestVersion;

@property (weak, nonatomic) CMNHudViewController *hudViewController;

@end
