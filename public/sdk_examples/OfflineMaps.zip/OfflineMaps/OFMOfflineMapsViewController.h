/*
 * Copyright © 2016 HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */
 
#import "CMNDownloadViewController.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//
// the main view controller
// note that for all the asynchronous operations, shows a hud
// getting, installing, uninstalling, updating and cancelling
// are asynchronous operations
// depends on the superclass for the NMAMapLoaderDelegate
// implementation
//
@interface OFMOfflineMapsViewController : CMNDownloadViewController

- (void)selectCell:(NSInteger)row;

- (void)install:(NSInteger)row;

- (void)uninstall:(NSInteger)row;

- (void)showHud;

- (void)hideHud;

- (void)didGetPackages:(NSArray *)packages;

- (void)showResult:(NMAMapLoaderResult)mapLoaderResult
      forOperation:(Operation)operation;

// trick: initially there is no parent as we go
//        deeper and deeper parent packages appear!
@property (weak, nonatomic) NMAMapPackage *parent;

@end
