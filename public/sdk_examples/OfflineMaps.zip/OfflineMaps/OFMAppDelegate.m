/*
 * Copyright © 2016 HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */

#import "OFMAppDelegate.h"
#import "license.h"
#import "dbg.h"

#import <NMAKit/NMAKit.h>

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@interface OFMAppDelegate ()

@end

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@implementation OFMAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    DBG_CALLED

    [NMAApplicationContext setAppId:APP_ID
                            appCode:APP_CODE
                         licenseKey:LICENSE_KEY];

    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    DBG_CALLED
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    DBG_CALLED
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    DBG_CALLED
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    DBG_CALLED
}

- (void)applicationWillTerminate:(UIApplication *)application {
    DBG_CALLED
}

@end
