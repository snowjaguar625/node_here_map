/*
 * Copyright © 2016 HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */

#import "OFMOfflineMapsViewController.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//
// models a package to be displayed in a cell
//
@interface OFMPackageCell : UITableViewCell

@property (nonatomic) NSInteger row;

@property (nonatomic) BOOL installed;

@property (nonatomic) BOOL hasChildren;

@property (weak, nonatomic) OFMOfflineMapsViewController *parent;

@property (weak, nonatomic) IBOutlet UILabel *title;

@property (weak, nonatomic) IBOutlet UILabel *size;

@property (weak, nonatomic) IBOutlet UIButton *button;

@end
