/*
 * Copyright © 2016 HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */

#import "OFMPackageCell.h"
#import "colors.h"
#import "dbg.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// declaring them as "defines" is simpler than other options!

#define SELECTED_CELL_TEXT_COLOR                     [UIColor whiteColor]

#define UNSELECTED_CELL_TEXT_COLOR                   COLOR_HERE

#define SELECTED_CELL_BACKGROUND_COLOR               COLOR_HERE

#define UNSELECTED_CELL_BACKGROUND_COLOR             [UIColor whiteColor]

#define HAS_CHILDREN_CELL_BACKGROUND_COLOR           COLOR_LIGHT_BLUE_100

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@interface OFMPackageCell ()

@end

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@implementation OFMPackageCell

#pragma mark - Public methods

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    DBG("\n"
        "....selected:|%@|\n"
        "....title:|%@|\n",
        STRINGIZE_BOOL(selected),
        self.title.text)

    // update the colors depending on selection status
    if (selected) {
        self.title.textColor = SELECTED_CELL_TEXT_COLOR;
        self.size.textColor = SELECTED_CELL_TEXT_COLOR;
        self.button.tintColor = SELECTED_CELL_TEXT_COLOR;
        self.backgroundColor = SELECTED_CELL_BACKGROUND_COLOR;
        self.contentView.backgroundColor = SELECTED_CELL_BACKGROUND_COLOR;
    }
    else if (self.hasChildren) {
        self.title.textColor = UNSELECTED_CELL_TEXT_COLOR;
        self.size.textColor = UNSELECTED_CELL_TEXT_COLOR;
        self.button.tintColor = UNSELECTED_CELL_TEXT_COLOR;
        self.backgroundColor = HAS_CHILDREN_CELL_BACKGROUND_COLOR;
        self.contentView.backgroundColor = HAS_CHILDREN_CELL_BACKGROUND_COLOR;
    }
    else {
        self.title.textColor = UNSELECTED_CELL_TEXT_COLOR;
        self.size.textColor = UNSELECTED_CELL_TEXT_COLOR;
        self.button.tintColor = UNSELECTED_CELL_TEXT_COLOR;
        self.backgroundColor = UNSELECTED_CELL_BACKGROUND_COLOR;
        self.contentView.backgroundColor = UNSELECTED_CELL_BACKGROUND_COLOR;
    }
}

#pragma mark - Setter/getter methods

- (void)setInstalled:(BOOL)installed {
    DBG("installed:|%@|\n", STRINGIZE_BOOL(installed))

    // assign the value
    _installed = installed;

    // trick: set the button image based on the
    //        installation status!
    // trick: use the image with the tint
    //        color!
    NSString *file = (_installed ? @"icon_checkmark.png" : @"icon_download.png");
    UIImage *image = [[UIImage imageNamed:file] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];

    [self.button setImage:image forState:UIControlStateNormal];
}

#pragma mark - IBAction methods

- (IBAction)onButton:(UIButton *)sender {
    DBG("\n"
        "....row:|%ld|\n"
        "....title:|%@|\n",
        (long)self.row,
        self.title.text)

    // trick: if the cell isn't selected, make
    //        sure it is selected
    if (!self.selected) {
        [self.parent selectCell:self.row];
    }

    // if the package is installed, do nothing
    // else, install the package
    if (self.installed) {
        DBG("installed: uninstall!\n")

        [self.parent uninstall:self.row];
    }
    else {
        DBG("not installed: installing!\n")

        [self.parent install:self.row];
    }
}

@end
