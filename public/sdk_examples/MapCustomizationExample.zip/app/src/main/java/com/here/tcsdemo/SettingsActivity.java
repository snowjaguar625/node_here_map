package com.here.tcsdemo;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.here.android.mpa.mapping.Map;
import com.here.android.mpa.mapping.customization.CustomizableScheme;
import com.here.android.mpa.mapping.customization.ZoomRange;
import com.here.tcsdemo.helper.CustomizableProperty;
import com.here.tcsdemo.helper.MapCustomizationHelper;

import java.util.List;

public class SettingsActivity extends Activity {

    private final String TAG = SettingsActivity.class.getCanonicalName();
    private final MapCustomizationHelper helper = new MapCustomizationHelper();
    private Spinner parameters, colors;
    private EditText field, rangeFrom, rangeTo;
    private Button save;
    private TextView label;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        final CustomizableScheme scheme = getScheme();

        parameters = (Spinner) findViewById(R.id.settings_options_spinner);
        parameters.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, helper.getParameters()));
        parameters.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selected = (String) parent.getSelectedItem();
                CustomizableProperty property = helper.getProperty(selected);
                if (property.getType().equals("Color")) {
                    colors.setVisibility(View.VISIBLE);
                    label.setVisibility(View.GONE);
                    field.setVisibility(View.GONE);
                } else {
                    colors.setVisibility(View.GONE);
                    label.setVisibility(View.VISIBLE);
                    label.setText(property.getType());
                    field.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        colors = (Spinner) findViewById(R.id.settings_color_values_spinner);
        colors.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, helper.getColors()));
        colors.setVisibility(View.GONE);

        field = (EditText) findViewById(R.id.editText);
        field.setVisibility(View.GONE);

        label = (TextView) findViewById(R.id.textView);
        label.setVisibility(View.GONE);

        rangeFrom = (EditText) findViewById(R.id.settings_editText_range_from);
        rangeTo = (EditText) findViewById(R.id.settings_edittext_range_to);

        save = (Button) findViewById(R.id.settings_save);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String selected = (String) parameters.getSelectedItem();
                CustomizableProperty property = helper.getProperty(selected);
                String color = (String) colors.getSelectedItem();
                String value = field.getText().toString();
                // Create zoom range from input
                // zoom range is expected in range[0, 20]
                int zoomRangeFrom = Integer.parseInt(rangeFrom.getText().toString());
                int zoomRangeTo = Integer.parseInt(rangeTo.getText().toString());
                ZoomRange range = new ZoomRange(zoomRangeFrom, zoomRangeTo);
                switch (property.getType()) {
                    case "Color":
                        // Set color variable
                        CustomizableScheme.ErrorCode error = scheme.setVariableValue(
                                property.getColorProperty(), helper.getColor(color), range);
                        // Process possible error
                        if (!error.equals(CustomizableScheme.ErrorCode.ERROR_NONE)) {
                            Log.e(TAG, "Can't set custom value: " + error);
                        }
                        break;
                    case "Float":
                        // Set float variable
                        error = scheme.setVariableValue(
                                property.getFloatProperty(), Float.parseFloat(value), range);
                        // Process possible error
                        if (!error.equals(CustomizableScheme.ErrorCode.ERROR_NONE)) {
                            Log.e(TAG, "Can't set custom value: " + error);
                        }
                        break;
                    default:
                        // Set integer variable
                        error = scheme.setVariableValue(
                                property.getIntegerProperty(), Integer.parseInt(value), range);
                        // Process possible error
                        if (!error.equals(CustomizableScheme.ErrorCode.ERROR_NONE)) {
                            Log.e(TAG, "Can't set custom value: " + error);
                        }
                        break;
                }
                // Set modified map scheme, i.e. "apply" changes to the map
                MainMapActivity.map.setMapScheme(scheme);
                finish();
            }
        });

    }

    // Method returns Map Scheme for customization
    private CustomizableScheme getScheme() {
        // Get list of all map schemes
        List<String> schemes = MainMapActivity.map.getMapSchemes();
        for (String str : schemes) {
            if (str.equals("test.scheme")) {
                // If scheme is already exist, then return it
                return MainMapActivity.map.getCustomizableScheme("test.scheme");
            }
        }
        // If scheme doesn't exist, then create a new scheme for modification based on existed one
        return MainMapActivity.map.createCustomizableScheme("test.scheme", Map.Scheme.NORMAL_DAY);
    }

}
