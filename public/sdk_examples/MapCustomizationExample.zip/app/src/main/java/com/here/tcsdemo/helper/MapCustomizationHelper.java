package com.here.tcsdemo.helper;

import android.graphics.Color;
import android.util.Log;

import com.here.android.mpa.mapping.customization.CustomizableVariables;
import com.here.android.mpa.mapping.customization.SchemeColorProperty;
import com.here.android.mpa.mapping.customization.SchemeFloatProperty;
import com.here.android.mpa.mapping.customization.SchemeIntegerProperty;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MapCustomizationHelper {

    private final String TAG = MapCustomizationHelper.class.getCanonicalName();
    private final List<CustomizableProperty> properties;
    private final Map<String, Integer> colors;

    public MapCustomizationHelper() {
        properties = new ArrayList<>();
        try {
            final Class<?>[] parent = CustomizableVariables.class.getClasses();
            for (Class<?> clazz : parent) {
                for (Field field : clazz.getDeclaredFields()) {
                    if (field.getType().getName().contains("SchemeFloatProperty")) {
                        SchemeFloatProperty property = (SchemeFloatProperty) field.get(null);
                        properties.add(new CustomizableProperty(property, "Float"));
                    } else if (field.getType().getName().contains("SchemeIntegerProperty")) {
                        SchemeIntegerProperty property = (SchemeIntegerProperty) field.get(null);
                        properties.add(new CustomizableProperty(property, "Integer"));
                    } else if (field.getType().getName().contains("SchemeColorProperty")) {
                        SchemeColorProperty property = (SchemeColorProperty) field.get(null);
                        properties.add(new CustomizableProperty(property, "Color"));
                    }

                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Can't process field");

        }

        colors = new HashMap<>();
        try {
            Field[] fields = Color.class.getFields();
            for (Field field : fields) {
                colors.put(field.getName(), field.getInt(field));
            }
        } catch (Exception e) {
            Log.e(TAG, "Can't process field");
        }
    }

    public List<String> getParameters() {
        List<String> list = new ArrayList<>(properties.size());
        for (CustomizableProperty item : properties) {
            list.add(item.getName());
        }
        Collections.sort(list);
        return list;
    }

    public CustomizableProperty getProperty(String name) {
        CustomizableProperty result = new CustomizableProperty();
        for (CustomizableProperty item : properties) {
            if (item.getName().equals(name)) {
                result = item;
                break;
            }
        }
        return result;
    }

    public int getColor(String name) {
        return colors.get(name);
    }

    public List<String> getColors() {
        List<String> list = new ArrayList<>(colors.size());
        for (Map.Entry<String, Integer> item : colors.entrySet()) {
            list.add(item.getKey());
        }
        Collections.sort(list);
        return list;
    }

}
