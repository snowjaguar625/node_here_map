package com.here.tcsdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.here.android.mpa.common.OnEngineInitListener;
import com.here.android.mpa.mapping.Map;
import com.here.android.mpa.mapping.MapFragment;

public class MainMapActivity extends Activity {

    protected static Map map = null;
    private final String TAG = MainMapActivity.class.getCanonicalName();
    private MapFragment mapFragment = null;
    private Button settings;
    private Button clear;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        settings = (Button) findViewById(R.id.button_customize);
        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), SettingsActivity.class);
                startActivity(intent);
            }
        });

        clear = (Button) findViewById(R.id.button_clear);
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // To reset modifications just set one of predefined schemes,
                // they are not modifiable
                map.setMapScheme(Map.Scheme.NORMAL_DAY);
            }
        });

        // Search for the map fragment to finish setup by calling init().
        mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.mapfragment);
        mapFragment.init(new OnEngineInitListener() {
            @Override
            public void onEngineInitializationCompleted(Error error) {
                if (error == Error.NONE) {
                    // retrieve a reference of the map from the map fragment
                    map = mapFragment.getMap();
                } else {
                    Log.e(TAG, "ERROR: " + error);
                    Log.e(TAG, error.getDetails());
                    Log.e(TAG, error.getStackTrace());
                }
            }
        });
    }

}
