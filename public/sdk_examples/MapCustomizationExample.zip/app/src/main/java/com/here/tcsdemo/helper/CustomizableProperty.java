package com.here.tcsdemo.helper;

import com.here.android.mpa.mapping.customization.SchemeColorProperty;
import com.here.android.mpa.mapping.customization.SchemeFloatProperty;
import com.here.android.mpa.mapping.customization.SchemeIntegerProperty;

public class CustomizableProperty {

    private final String name;
    private final String type;
    private final SchemeColorProperty colorProperty;
    private final SchemeFloatProperty floatProperty;
    private final SchemeIntegerProperty integerProperty;

    public CustomizableProperty() {
        name = "";
        type = "";
        colorProperty = null;
        floatProperty = null;
        integerProperty = null;
    }

    public CustomizableProperty(SchemeColorProperty prop, String type) {
        colorProperty = prop;
        floatProperty = null;
        integerProperty = null;
        this.type = type;
        name = prop.getName();
    }

    public CustomizableProperty(SchemeIntegerProperty prop, String type) {
        integerProperty = prop;
        colorProperty = null;
        floatProperty = null;
        this.type = type;
        name = prop.getName();
    }

    public CustomizableProperty(SchemeFloatProperty prop, String type) {
        floatProperty = prop;
        colorProperty = null;
        integerProperty = null;
        this.type = type;
        name = prop.getName();
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public SchemeColorProperty getColorProperty() {
        return colorProperty;
    }

    public SchemeFloatProperty getFloatProperty() {
        return floatProperty;
    }

    public SchemeIntegerProperty getIntegerProperty() {
        return integerProperty;
    }

}
