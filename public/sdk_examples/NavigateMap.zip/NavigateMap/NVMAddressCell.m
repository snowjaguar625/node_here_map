/*
 * Copyright © 2016 HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */

#import "NVMAddressCell.h"
#import "colors.h"
#import "dbg.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// declaring them as "defines" is simpler than other options!

#define SELECTED_CELL_TEXT_COLOR                     [UIColor whiteColor]

#define UNSELECTED_CELL_TEXT_COLOR                   COLOR_APP

#define SELECTED_CELL_BACKGROUND_COLOR               COLOR_APP

#define UNSELECTED_CELL_BACKGROUND_COLOR             [UIColor whiteColor]

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@interface NVMAddressCell ()

@end

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@implementation NVMAddressCell

#pragma mark - Public methods

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    DBG("\n"
        "....selected:|%@|\n"
        "....name:|%@|\n"
        "....vicinity:|%@|\n",
        STRINGIZE_BOOL(selected),
        self.nameLabel.text,
        self.vicinitylabel.text)

    // update the colors depending on selection status
    if (selected) {
        self.nameLabel.textColor = SELECTED_CELL_TEXT_COLOR;
        self.vicinitylabel.textColor = SELECTED_CELL_TEXT_COLOR;
        self.backgroundColor = SELECTED_CELL_BACKGROUND_COLOR;
        self.contentView.backgroundColor = SELECTED_CELL_BACKGROUND_COLOR;
    } else {
        self.nameLabel.textColor = UNSELECTED_CELL_TEXT_COLOR;
        self.vicinitylabel.textColor = UNSELECTED_CELL_TEXT_COLOR;
        self.backgroundColor = UNSELECTED_CELL_BACKGROUND_COLOR;
        self.contentView.backgroundColor = UNSELECTED_CELL_BACKGROUND_COLOR;
    }
}

@end
