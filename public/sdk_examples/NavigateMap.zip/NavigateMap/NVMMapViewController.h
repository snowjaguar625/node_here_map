/*
 * Copyright © 2016 HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */

#import "CMNDownloadViewController.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

typedef NS_ENUM(NSInteger, TransportMode) {
    kTransportModePedestrian = 0,
    kTransportModeCar        = 1
};

typedef NS_ENUM(NSInteger, MapScheme) {
    kMapSchemeNormal    = 0,
    kMapSchemeSatellite = 1,
    kMapSchemeHybrid    = 2
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@interface NVMMapViewController : CMNDownloadViewController

- (void)showHud;

- (void)hideHud;

@property (nonatomic) TransportMode transportMode;

@property (nonatomic) MapScheme mapScheme;

@property (strong, nonatomic) NMAPlaceLink *searchedLink;

@end
