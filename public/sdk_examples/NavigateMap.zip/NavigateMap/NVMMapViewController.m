/*
 * Copyright © 2016 HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */

#import "NVMMapViewController.h"
#import "license.h"
#import "dbg.h"

#import <MessageUI/MessageUI.h>
#import <AVFoundation/AVFoundation.h>

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// declaring them as "defines" is simpler than other options!

#define DEFAULT_ZOOM_LEVEL               14.68f

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static NSString *SEGUE_SHOW_HUD = @"ShowHudFromMap";

static NSString *SEGUE_SHOW_SEARCH = @"ShowSearchFromMap";

static NSString *SEGUE_SHOW_SETTINGS = @"ShowSettingsFromMap";

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@interface NVMMapViewController () <MFMailComposeViewControllerDelegate,
                                    NMAMapViewDelegate,
                                    NMAMapGestureDelegate,
                                    NMANavigationManagerDelegate,
                                    NMAAudioManagerDelegate,
                                    NMAVoiceCatalogDelegate>

- (void)setup;

- (void)stringizeNavigation;

- (void)registerForNotifications;

- (void)unregisterFromNotifications;

- (void)userTappedMarker;

- (void)navigateFromCurrentPosition:(NMAGeoCoordinates *)coordinates;

- (void)centerHandler;

- (void)cancelHandler;

- (void)clearNavigation;

- (void)clearManeuver;

- (void)displayMailComposerSheet;

- (void)handleNavigateStateChangedNotification;

- (void)handlePositionUpdatedNotification;

- (void)handlePositionLostNotification;

@property (nonatomic) BOOL isNavigating;

// note that audio instructions available for the car mode
// and vibrations & beeps for the pedestrian mode
@property (nonatomic) NMATransportMode nmaTransportMode;

@property (strong, nonatomic) NSArray *stringizeTurns;

// we let the user to create a single marker
// so, no need to use a NMAMapContainer
@property (strong, nonatomic) NMAMapMarker *marker;

@property (strong, nonatomic) NMACoreRouter *coreRouter;

@property (strong, nonatomic) NMAMapRoute *mapRoute;

@property (strong, nonatomic) NMARoute *route;

@property (weak, nonatomic) IBOutlet UILabel *distanceLabel;

@property (weak, nonatomic) IBOutlet UILabel *instructionLabel;

@property (weak, nonatomic) IBOutlet UILabel *roadLabel;

@property (weak, nonatomic) IBOutlet UIButton *searchButton;

@property (weak, nonatomic) IBOutlet UISwitch *simulationSwitch;

@property (weak, nonatomic) IBOutlet UIButton *cancelButton;

@property (weak, nonatomic) IBOutlet UIButton *centerButton;

@property (weak, nonatomic) IBOutlet UIButton *navigationButton;

@property (weak, nonatomic) IBOutlet UIButton *settingsButton;

@property (weak, nonatomic) IBOutlet UIView *containerView;

@property (weak, nonatomic) IBOutlet UIView *simulationView;

@property (weak, nonatomic) IBOutlet UIView *maneuverView;

@property (weak, nonatomic) IBOutlet NMAMapView *mapView;

@end

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@implementation NVMMapViewController

#pragma mark - Public methods

- (void)dealloc {
    DBG_CALLED

    [self unregisterFromNotifications];
}

- (void)viewDidLoad {
    [super viewDidLoad];

    [self setup];
    [self stringizeNavigation];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    // returning from the search view with a link?
    if (self.searchedLink) {
        // remove the existing marker if any
        [self.mapView removeMapObject:self.marker];

        // get the coordinates of the searched link
        NMAGeoCoordinates *coordinates = self.searchedLink.position;

        // add the icon into the map
        self.marker.coordinates = coordinates;
        [self.mapView addMapObject:self.marker];

        // navigate to the coordinate
        [self navigateFromCurrentPosition:coordinates];
    }
}

- (void)didReceiveMemoryWarning {
    DBG_CALLED

    [super didReceiveMemoryWarning];
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}

- (void)showHud {
    DBG_CALLED

    // configure the hud
    [self.hudViewController reset];
    [self.hudViewController setDetails:@"Initiating..."]; // whatever the task is ...

    // show the container view
    self.containerView.hidden = NO;
}

- (void)hideHud {
    DBG_CALLED

    // hide the container view
    self.containerView.hidden = YES;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    DBG("segue:|%@|", segue.identifier)

    if ([[segue identifier] isEqualToString:SEGUE_SHOW_HUD]) {
        // save the view controller which is hidden initially
        self.hudViewController = (CMNHudViewController *)[segue destinationViewController];
    }
}

#pragma mark - Private methods

- (void)setup {
    // trick: important!
    //        make sure to call it
    [super setup];

    // start the positioning manager if not started already
    if (![[NMAPositioningManager sharedPositioningManager] isActive]) {
        [[NMAPositioningManager sharedPositioningManager] startPositioning];
    }

    // trick: give some time to the positioning
    //        manager!
    [[NSRunLoop mainRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.25f]];

    // Create the router
    self.coreRouter = [[NMACoreRouter alloc] init];

    // initial settings
    self.maneuverView.hidden = YES;
    self.searchButton.hidden = NO;
    self.navigationButton.hidden = YES;
    self.cancelButton.hidden = YES;
    [self hideHud];
    [self registerForNotifications];
    [self clearManeuver];
    self.simulationView.hidden = YES; // available only for the debug builds when navigation requested
    self.simulationSwitch.on = NO; // no simulation
    self.isNavigating = NO;
    self.transportMode = kTransportModeCar;
    self.mapScheme = kMapSchemeNormal;

    // configure the map
    self.mapView.delegate = self;
    self.mapView.extrudedBuildingsVisible = YES;
    self.mapView.gestureDelegate = self;
    self.mapView.copyrightLogoPosition = NMALayoutPositionBottomCenter;
    self.mapView.zoomLevel = DEFAULT_ZOOM_LEVEL;
    self.mapView.tilt = 0.0f;
    self.mapView.orientation = 0.0f;
    self.mapView.mapScheme = NMAMapSchemeNormalDay;
    self.mapView.positionIndicator.visible = YES;
    self.mapView.positionIndicator.accuracyIndicatorVisible = YES;

    [self.mapView respondToEvents:(NMAMapEventGestureBegan | NMAMapEventAnimationBegan) withBlock:
         ^(NMAMapEvent event, NMAMapView *mapView, id eventData) {
             DBG("gesture or animation began")

             // do something...

             return YES; // continue to respond
         }];

    [self.mapView respondToEvents:(NMAMapEventGestureEnded | NMAMapEventAnimationEnded) withBlock:
         ^(NMAMapEvent event, NMAMapView *mapView, id eventData) {
             DBG("gesture or animation ended")

             // do something...

             return YES; // continue to respond
         }];

    // configure the marker
    self.marker = [[NMAMapMarker alloc] init];
    self.marker.icon = [NMAImage imageWithUIImage:[UIImage imageNamed:@"icon_pin.png"]];
    [self.marker setAnchorOffsetUsingLayoutPosition:NMALayoutPositionBottomCenter];

    // try to get the current position
    // if fails, use the default coordinate: the lincoln memorial in washington, dc
    NMAGeoPosition *position = [NMAPositioningManager sharedPositioningManager].currentPosition;
    NMAGeoCoordinates *center = (position ? position.coordinates : [[NMAGeoCoordinates alloc] initWithLatitude:38.889269
                                                                                                     longitude:-77.050176]);

    DBG("center\n"
        "....latitude:|%3.4f|\n"
        "....longitude:|%3.4f|\n",
        center.latitude,
        center.longitude)

    // set the map center
    [self.mapView setGeoCenter:center withAnimation:NMAMapAnimationNone];

    // configure the audio
    [NMAAudioManager sharedAudioManager].delegate = self;
    [NMAVoiceCatalog sharedVoiceCatalog].delegate = self;
    [[NMAVoiceCatalog sharedVoiceCatalog] updateVoiceCatalog];

    // for the debug builds, dump some data...

    DBG("\n"
        "....actual tilt:|%2.2f|\n"
        "....min tilt at zoom level:|%2.2f|\n"
        "....max tilt at zoom level:|%2.2f|\n",
        self.mapView.clippedTilt,
        [self.mapView minimumTiltAtZoomLevel:self.mapView.zoomLevel],
        [self.mapView maximumTiltAtZoomLevel:self.mapView.zoomLevel])

    DBG("layer categores:\n"
        "%@\n",
        [self.mapView visibleMapLayerCategories])

    DBG("poi categores:\n"
        "%@\n",
        [self.mapView poiCategories])
}

- (void)stringizeNavigation {
    self.stringizeTurns = [NSArray arrayWithObjects:
                               @"",                       // NMAManeuverTurnUndefined
                               @"Continue",               // NMAManeuverTurnNone
                               @"Keep middle",            // NMAManeuverTurnKeepMiddle
                               @"Keep right",             // NMAManeuverTurnKeepRight
                               @"Slight right turn",      // NMAManeuverTurnLightRight
                               @"Right turn",             // NMAManeuverTurnQuiteRight
                               @"Full right turn",        // NMAManeuverTurnHeavyRight
                               @"Keep left",              // NMAManeuverTurnKeepLeft
                               @"Slight left turn",       // NMAManeuverTurnLightLeft
                               @"Left turn",              // NMAManeuverTurnQuiteLeft
                               @"Full left turn",         // NMAManeuverTurnHeavyLeft
                               @"Turn around",            // NMAManeuverTurnReturn
                               @"Take the first exit",    // NMAManeuverTurnRoundabout1
                               @"Take the second exit",   // NMAManeuverTurnRoundabout2
                               @"Take the third exit",    // NMAManeuverTurnRoundabout3
                               @"Take the fourth exit",   // NMAManeuverTurnRoundabout4
                               @"Take the fifth exit",    // NMAManeuverTurnRoundabout5
                               @"Take the sixth exit",    // NMAManeuverTurnRoundabout6
                               @"Take the seventh exit",  // NMAManeuverTurnRoundabout7
                               @"Take the eighth exit",   // NMAManeuverTurnRoundabout8
                               @"Take the ninth exit",    // NMAManeuverTurnRoundabout9
                               @"Take the tenth exit",    // NMAManeuverTurnRoundabout10
                               @"Take the eleventh exit", // NMAManeuverTurnRoundabout11
                               @"Take the twelfth exit",  // NMAManeuverTurnRoundabout12
                               nil];
}

- (void)registerForNotifications {
    DBG_CALLED

    // observe navigation state changes
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleNavigateStateChangedNotification)
                                                 name:NMANavigationManagerStateChangedNotification
                                               object:nil];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handlePositionUpdatedNotification)
                                                 name:NMAPositioningManagerDidUpdatePositionNotification
                                               object:nil];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handlePositionLostNotification)
                                                 name:NMAPositioningManagerDidLosePositionNotification
                                               object:nil];
}

- (void)unregisterFromNotifications {
    DBG_CALLED

    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:NMANavigationManagerStateChangedNotification
                                                  object:nil];

    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:NMAPositioningManagerDidUpdatePositionNotification
                                                  object:nil];

    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:NMAPositioningManagerDidLosePositionNotification
                                                  object:nil];
}

- (void)userTappedMarker {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil
                                                                   message:@"What to do?"
                                                            preferredStyle:UIAlertControllerStyleActionSheet];

    UIAlertAction *navigate = [UIAlertAction actionWithTitle:@"Navigate to Marker"
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction *action) {
                                  DBG("Navigate to marker")

                                  [self navigateFromCurrentPosition:self.marker.coordinates];
                              }];


    UIAlertAction *email = [UIAlertAction actionWithTitle:@"Email Marker"
                                                    style:UIAlertActionStyleDefault
                                                  handler:^(UIAlertAction *action) {
                                    DBG("Email marker")

                                    // make sure that the device can send email
                                    if ([MFMailComposeViewController canSendMail]) {
                                        [self displayMailComposerSheet];
                                    } else {
                                        [self alertForEmailConfiguration];
                                    }
                                }];

    UIAlertAction *remove = [UIAlertAction actionWithTitle:@"Remove Marker"
                                                     style:UIAlertActionStyleDestructive
                                                   handler:^(UIAlertAction *action) {
                                     DBG("remove marker")

                                     [self.mapView removeMapObject:self.marker];

                                 }];


    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Cancel"
                                                     style:UIAlertActionStyleCancel
                                                   handler:nil];

    [alert addAction:navigate];
    [alert addAction:email];
    [alert addAction:remove];
    [alert addAction:cancel];

    [self presentViewController:alert animated:YES completion:nil];
}

- (void)navigateFromCurrentPosition:(NMAGeoCoordinates *)coordinates {
    NMAGeoPosition *position = [NMAPositioningManager sharedPositioningManager].currentPosition;

    // do we know the current postion?
    if (position) {
        NMARoutingMode *routingMode = [[NMARoutingMode alloc] initWithRoutingType:NMARoutingTypeShortest
                                                                    transportMode:self.nmaTransportMode
                                                                   routingOptions:0];

        // configure the routing mode
        routingMode.resultLimit = 1;

        // configure the route: specify the start and end points
        NSMutableArray *stopList = [NSMutableArray array];

        [stopList addObject:position.coordinates];
        [stopList addObject:coordinates];

        DBG("routing from |%.5f,%.5f| to |%.5f,%.5f|",
            position.coordinates.latitude, position.coordinates.longitude,
            self.marker.coordinates.latitude, self.marker.coordinates.longitude)

        // trick: show hud as we will be busy until the routes
        //        are found, but hide its cancel button!
        //        it has no handler...
        [self.hudViewController setTitle:@"Navigate"];
        [self showHud];
        [self.hudViewController hideCancelButton:YES];

        __weak NVMMapViewController *weakSelf = self;

        NSProgress *success = [self.coreRouter calculateRouteWithStops:stopList
                                                           routingMode:routingMode
                                                       completionBlock:^(NMARouteResult *routeResult, NMARoutingError error) {
                                                           if (error == NMARoutingErrorNone) {
                                                               DBG("|%lu| route(s) obtained", (unsigned long)routeResult.routes.count);

                                                               // Get the first route
                                                               weakSelf.route = routeResult.routes[0];

                                                               // Update the map bounding box
                                                               [weakSelf.mapView setBoundingBox:self.route.boundingBox withAnimation:NMAMapAnimationRocket];

                                                               // Show the route on the map
                                                               weakSelf.mapRoute = [NMAMapRoute mapRouteWithRoute:self.route];
                                                               [weakSelf.mapView addMapObject:self.mapRoute];

                                                               // configure the position manager
                                                               [NMAPositioningManager sharedPositioningManager].mapMatchingEnabled = YES;

                                                               // configure the navigation
                                                               weakSelf.mapRoute = [NMAMapRoute mapRouteWithRoute:self.route];
                                                               [weakSelf.mapView addMapObject:self.mapRoute];
                                                               [weakSelf.mapView setBoundingBox:self.route.boundingBox withAnimation:NMAMapAnimationLinear];

                                                               // show/hide the buttons
                                                               weakSelf.searchButton.hidden = YES;
                                                               weakSelf.centerButton.hidden = YES;
                                                               weakSelf.navigationButton.hidden = NO;
                                                               weakSelf.cancelButton.hidden = NO;
#ifdef DEBUG
                                                               // show the simulation option
                                                               weakSelf.simulationView.hidden = NO;
#endif
                                                               // now, we are in the navigation mode
                                                               weakSelf.isNavigating = YES;
                                                           } else {
                                                               [self alertForRouteFailure];
                                                           }

                                                           [self hideHud];
                                                   }];
        
        if (!success) {
            [self alertForNavigationFailure];
        }
    } else {
        [self alertForUnknownPosition];
    }
}

- (void)centerHandler {
    NMAGeoPosition *position = [NMAPositioningManager sharedPositioningManager].currentPosition;

    // do we know the current postion?
    if (position) {
        DBG("cordinates:\n"
            "....latitude:|%3.4f|\n"
            "....longitude:|%3.4f|\n",
            position.coordinates.latitude,
            position.coordinates.longitude)

        [self.mapView setGeoCenter:position.coordinates
                     withAnimation:NMAMapAnimationBow];
    } else {
        [self alertForUnknownPosition];
    }
}

- (void)cancelHandler {
    DBG("state:|%lu|", (unsigned long)[NMANavigationManager sharedNavigationManager].navigationState)

    NMANavigationState navState = [NMANavigationManager sharedNavigationManager].navigationState;

    // trick: if the navigation isn't started, restoring back
    //        the map is problematic! so, fool the navigation
    //        manager: give it a start/stop cycle...
    //        restore the map fully...
    if (navState == NMANavigationStateIdle) {
        [[NMANavigationManager sharedNavigationManager] startTrackingWithTransportMode:self.nmaTransportMode];
    }

    // stop the navigation manager
    [[NMANavigationManager sharedNavigationManager] stop];

    // restore the settings updated for navigating
    [self clearNavigation];

    // show/hide the buttons
    self.searchButton.hidden = NO;
    self.centerButton.hidden = NO;
    self.navigationButton.hidden = YES;
    self.cancelButton.hidden = YES;

    // done
    self.isNavigating = FALSE;
}

- (void)clearNavigation {
    DBG_CALLED

    // resume screen autodim and locking
    [UIApplication sharedApplication].idleTimerDisabled = NO;

    // reset
    [NMAPositioningManager sharedPositioningManager].dataSource = nil;
    [NMAPositioningManager sharedPositioningManager].mapMatchingEnabled = NO;
    [NMANavigationManager sharedNavigationManager].delegate = nil;
    [NMANavigationManager sharedNavigationManager].map = nil;
    self.searchedLink = nil;
    self.mapView.tilt = 0.0f;
    self.mapView.orientation = 0.0f;
    self.mapView.zoomLevel = DEFAULT_ZOOM_LEVEL;
    self.maneuverView.hidden = YES;
    self.navigationButton.hidden = YES;
    self.searchButton.hidden = NO;
    [self clearManeuver];

#ifdef DEBUG
    // reset
    self.simulationSwitch.on = NO;
    self.simulationView.hidden = YES;
#endif

    // if there is a route, remove it
    if (self.mapRoute) {
        [self.mapView removeMapObject:self.mapRoute];
    }

    self.mapRoute = nil;
    self.route = nil;

    // position the indicator at the center of screen
    self.mapView.transformCenter = CGPointMake(0.5f, 0.5f);

    // try to center the map
    [self centerHandler];
}

- (void)clearManeuver {
    DBG_CALLED

    self.distanceLabel.text = @"Start";
    self.instructionLabel.text = @"";
    self.roadLabel.text = @"";
}

- (void)displayMailComposerSheet {
    MFMailComposeViewController *composer = [[MFMailComposeViewController alloc] init];

    // set the delegate
    composer.mailComposeDelegate = self;

    // set the transtion style as "flip horizontal"
    composer.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;

    // set the subject
    composer.subject = @"Coordinates from Navigate Map app";

    // set the message body
    NMAGeoCoordinates *coordinates = self.marker.coordinates;
    NSString *message = [NSString stringWithFormat:
                         @"<small>The HERE maps link:</small><br>"
                         "<a href=\"https://image.maps.cit.api.here.com/mia/1.6/mapview?c=%f,%f&z=11&u=1000&app_id=%@&app_code=%@\">%f, %f</a><br>"
                         "<br>",
                         coordinates.latitude, coordinates.longitude,
                         APP_ID, APP_CODE,
                         coordinates.latitude, coordinates.longitude];

    [composer setMessageBody:message
                      isHTML:YES];

    // display the composer
    [self presentViewController:composer animated:YES completion:nil];
}

- (void)handleNavigateStateChangedNotification {
    switch ([NMANavigationManager sharedNavigationManager].navigationState) {
        case NMANavigationStateIdle: {
                DBG("navigation state: idle")

                // update the button title: reset for the next time
                [self.navigationButton setTitle:@"Start" forState:UIControlStateNormal];
            }
            break;

        case NMANavigationStatePaused: {
                DBG("navigation state: paused")

                // resume screen autodim and locking
                [UIApplication sharedApplication].idleTimerDisabled = NO;

                // update the button title
                [self.navigationButton setTitle:@"Resume" forState:UIControlStateNormal];
            }
            break;

        case NMANavigationStateRunning: {
                DBG("navigation state: running")

                // disable screen autodim and locking
                [UIApplication sharedApplication].idleTimerDisabled = YES;

                // show the maneuver view
                self.maneuverView.hidden = NO;

                // position the indicator at the bottom of screen
                self.mapView.transformCenter = CGPointMake(0.5f, 0.85f);

                // update the button title
                [self.navigationButton setTitle:@"Pause" forState:UIControlStateNormal];
            }
            break;
    }
}

- (void)handlePositionUpdatedNotification {
    DBG_CALLED

    NMAManeuver *currentManeuver = [NMANavigationManager sharedNavigationManager].currentManeuver;

    // if maneuver available and maneuver view visible, update the data
    if (currentManeuver &&
        !self.maneuverView.hidden) {
        // try to update the distance
        if ([NMAPositioningManager sharedPositioningManager].currentPosition) {
            double distance = [NMANavigationManager sharedNavigationManager].distanceToCurrentManeuver;

            if (distance < 1000) {
                self.distanceLabel.text = [NSString stringWithFormat:
                                               @"%.0f m",
                                               distance];
            } else {
                self.distanceLabel.text = [NSString stringWithFormat:
                                               @"%.2f km",
                                               distance / 1000.0f];
            }
        } else {
            DBG("current position is unknown!")

            self.distanceLabel.text = @"Unknown";
        }

        // try to update the instruction
        if (currentManeuver.nextRoadName &&
            currentManeuver.nextRoadName.length > 0) {
            self.instructionLabel.text = [NSString stringWithFormat:
                                              @"%@ to %@",
                                              self.stringizeTurns[currentManeuver.turn],
                                              currentManeuver.nextRoadName];
        } else {
            DBG("next road name is unknown!\n")

            self.instructionLabel.text = @"";
        }

        // try to update the road
        if (currentManeuver.roadName &&
            currentManeuver.roadName.length > 0) {
            self.roadLabel.text = [NSString stringWithFormat:
                                       @"on %@",
                                       currentManeuver.roadName];
        } else {
            DBG("road name is unknown")

            self.roadLabel.text = @"";
        }
    }
}

- (void)handlePositionLostNotification {
    DBG_CALLED
}

#pragma mark - Setter/getter methods

- (void)setMapScheme:(MapScheme)mapScheme {
    // set the map scheme
    _mapScheme = mapScheme;

    // trick: convert our transport mode into
    //        the appropriate NMAMapScheme value!
    switch (mapScheme) {
        case kMapSchemeNormal:
            self.mapView.mapScheme = NMAMapSchemeNormalDay;
            break;

        case kMapSchemeSatellite:
            self.mapView.mapScheme = NMAMapSchemeSatelliteDay;
            break;

        case kMapSchemeHybrid:
            self.mapView.mapScheme = NMAMapSchemeHybridDay;
            break;
    }

    DBG("map scheme:|%ld -> %@|", (long)mapScheme, self.mapView.mapScheme)
}

- (void)setTransportMode:(TransportMode)transportMode {
    // set the transport mode
    _transportMode = transportMode;

    // trick: convert our transport mode into
    //        the appropriate NMATransportMode value!
    switch (transportMode) {
        case kTransportModePedestrian:
            self.nmaTransportMode = NMATransportModePedestrian;
            break;

        case kTransportModeCar:
            self.nmaTransportMode = NMATransportModeCar;
            break;
    }

    DBG("transport mode:|%ld -> %lu|", (long)transportMode, (unsigned long)self.nmaTransportMode)
}

#pragma mark - IBAction methods

- (IBAction)onSettings:(UIButton *)sender {
    DBG_CALLED

    [self performSegueWithIdentifier:SEGUE_SHOW_SETTINGS sender:self];
}

- (IBAction)onSearch:(UIButton *)sender {
    DBG_CALLED

    [self performSegueWithIdentifier:SEGUE_SHOW_SEARCH sender:self];
}

// basically just update the navigation state and
// leave the implementation to the handleNavigateStateChangedNotification
// method
//
- (IBAction)onNavigation:(UIButton *)sender {
    NMANavigationState navState = [NMANavigationManager sharedNavigationManager].navigationState;

    switch (navState) {
        case NMANavigationStateIdle: {
                DBG("start turn by turn navigation")
#ifdef DEBUG
                // should simulate?
                if (self.simulationSwitch.isOn) {
                    // yes, in this case we will use the route as our source and
                    // and update our "position" every second

                    // stop positioning as we will update the data source
                    [[NMAPositioningManager sharedPositioningManager] stopPositioning];

                    NMARoutePositionSource *routeSource = [[NMARoutePositionSource alloc] initWithRoute:self.route];

                    // configure the route
                    routeSource.updateInterval = 1.0f; // every second which is the default
                    routeSource.stationary = NO; // move along which is the default
                    routeSource.movementSpeed = (self.route.routingMode.transportMode == NMATransportModePedestrian ?
                                                     5.0f : 20.0f);  // 5m/s for walking speed and 20m/s for driving

                    // set the route as our source
                    [NMAPositioningManager sharedPositioningManager].dataSource = routeSource;

                    // re-start the positioning
                    [[NMAPositioningManager sharedPositioningManager] startPositioning];
                }

                // hide the buttons
                self.simulationView.hidden = YES;
                self.navigationButton.hidden = YES;
#endif
                // configure the navigation manager
                [NMANavigationManager sharedNavigationManager].map = self.mapView;
                [NMANavigationManager sharedNavigationManager].delegate = self;
                [NMANavigationManager sharedNavigationManager].mapTrackingTilt = NMAMapTrackingTilt3D;
                [NMANavigationManager sharedNavigationManager].voicePackageMeasurementSystem = NMAMeasurementSystemMetric;
    
                // start the navigation
                NSError *error = [[NMANavigationManager sharedNavigationManager] startTurnByTurnNavigationWithRoute:self.route];

                // succeeded?
                if (error &&
                    error.code != NMANavigationErrorNone) {
                    ERROR("unable to start navigation:|%ld -> %@|",
                          (long)error.code,
                          error.localizedDescription)

                    [self alertForNavigationFailure];

                    // cancel the navigation
                    [self cancelHandler];
                }
            }
            break;

        case NMANavigationStatePaused:
            DBG("resume navigation")

            [[NMANavigationManager sharedNavigationManager] setPaused:NO];
            break;

        case NMANavigationStateRunning:
            DBG("pause navigation")

            [[NMANavigationManager sharedNavigationManager] setPaused:YES];
            break;
    }
}

- (IBAction)onCancel:(UIButton *)sender {
    DBG_CALLED

    [self cancelHandler];
}

- (IBAction)onCenter:(UIButton *)sender {
    DBG_CALLED

    // try to center the map
    [self centerHandler];
}

#pragma mark - MFMailComposeViewControllerDelegate

- (void)mailComposeController:(MFMailComposeViewController *)controller
          didFinishWithResult:(MFMailComposeResult)result
                        error:(NSError *)error {
    DBG("result:|%ld|", (long)result)

    // inform the user the result only in case of failure
    switch (result) {
        case MFMailComposeResultCancelled:
        case MFMailComposeResultSaved:
        case MFMailComposeResultSent:
            // do nothing
            break;

        case MFMailComposeResultFailed:
        default:
            ERROR("unable to send the email:|%ld -> %@|",
                  (long)error.code,
                  error.localizedDescription)

            [self alertForEmailFailure];
            break;
    }

    // dismiss the mail composer
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - NMAMapViewDelegate

- (void)mapView:(NMAMapView *)mapView didSelectObjects:(NSArray *)objects {
    DBG("count:|%lu|", (unsigned long)objects.count)
}

- (void)mapViewDidBeginMovement:(NMAMapView *)mapView {
    DBG_CALLED
}

- (void)mapViewDidEndMovement:(NMAMapView *)mapView {
    DBG_CALLED
}

- (void)mapViewDidBeginAnimation:(NMAMapView *)mapView {
    DBG_CALLED
}

- (void)mapViewDidEndAnimation:(NMAMapView *)mapView {
    DBG_CALLED
}

- (void)mapViewDidDraw:(NMAMapView *)mapView {
    DBG_CALLED
}

#pragma mark - NMAMapGestureDelegate

- (void)mapView:(NMAMapView *)mapView didReceiveTapAtLocation:(CGPoint)location {
    NSArray *objects = [self.mapView visibleObjectsAtPoint:location];

    DBG("\n"
        "location:\n"
        "....x:|%2.2f|\n"
        "....y:|%2.2f|\n"
        "visible objects:\n"
        "....count:|%lu|\n"
        "%@\n",
        location.x,
        location.y,
         (unsigned long)objects.count,
        objects)

    // is there an ongoing navigation?
    if (self.isNavigating) {
        DBG("ongoing navigation: ignore the tap...")

        return;
    }

    // if the user tapped the marker, handle it
    // else, remove the eisting marker and insert
    // a new one
    for (NSObject *object in objects) {
        if ([object isEqual:self.marker]) {
            [self userTappedMarker];

            // don't go further
            return;
        }
    }

    // remove the existing marker
    [self.mapView removeMapObject:self.marker];

    // get the coordinates of the location
    NMAGeoCoordinates *coordinates = [self.mapView geoCoordinatesFromPoint:location];

    // add the icon into the map
    self.marker.coordinates = coordinates;
    [self.mapView addMapObject:self.marker];
}

// just to show you can handle the gestures and then optionally forward it to the
// default handlers
- (void)mapView:(NMAMapView *)mapView didReceiveDoubleTapAtLocation:(CGPoint)location {
    DBG("\n"
        "location:\n"
        "....x:|%2.2f|\n"
        "....y:|%2.2f|\n",
        location.x,
        location.y)

    // forward the gesture to its default handler
    [mapView.defaultGestureHandler mapView:mapView didReceiveDoubleTapAtLocation:location];
}

- (void)mapView:(NMAMapView *)mapView didReceiveLongPressAtLocation:(CGPoint)location {
    NMAGeoCoordinates *coordinates = [self.mapView geoCoordinatesFromPoint:location];

    DBG("\n"
        "location:\n"
        "....x:|%2.2f|\n"
        "....y:|%2.2f|\n"
        "cordinates:\n"
        "....latitude:|%3.4f|\n"
        "....longitude:|%3.4f|\n",
        location.x,
        location.y,
        coordinates.latitude,
        coordinates.longitude)

    if (self.isNavigating) {
        DBG("ongoing navigation: ignore the double tap...")
    } else if (![NMAApplicationContext isOnline]) {
        [self alertForNotOnline];
    } else {
        // retrieve the package for the location
        [self.hudViewController setTitle:@"Offline Map"];
        [self showHud];
        [[NMAMapLoader sharedMapLoader] getMapPackageAtGeoCoordinates:coordinates];
    }
}

#pragma mark - NMANavigationManagerDelegate

- (void)navigationManager:(NMANavigationManager*)navigationManager
       hasCurrentManeuver:(NMAManeuver*)maneuver
             nextManeuver:(NMAManeuver*)nextManeuver {
    DBG("\n"
        "....road:|%@|\n"
        "....distance to next maneuver:|%lu| m\n"
        "....next road:|%@|\n",
        maneuver.roadName,
        (unsigned long)maneuver.distanceToNextManeuver,
        nextManeuver.roadName)
}

- (void)navigationManagerDidLosePosition:(NMANavigationManager*)navigationManager {
    DBG_CALLED
}

- (void)navigationManagerDidFindPosition:(NMANavigationManager*)navigationManager {
    DBG_CALLED
}

- (void)navigationManager:(NMANavigationManager *)navigationManager didUpdateRoute:(NMARoute *)route {
    DBG_CALLED

    // remove existing route
    if (self.mapRoute) {
        [self.mapView removeMapObject:self.mapRoute];
    }

    // add the new route
    self.route = route;
    self.mapRoute = [NMAMapRoute mapRouteWithRoute:self.route];
    [self.mapView addMapObject:self.mapRoute];
}

- (void)navigationManagerDidReachDestination:(NMANavigationManager*)navigationManager {
    DBG_CALLED

    self.distanceLabel.text = @"Reached your destination";
    self.instructionLabel.text = @"";
    self.roadLabel.text = @"";

    // no longer cancelling
    [self.cancelButton setTitle:@"Close" forState:UIControlStateNormal];
}

#pragma mark - NMAAudioManagerDelegate

- (BOOL)audioManager:(NMAAudioManager *)audioManager shouldPlayOutput:(NMAAudioOutput *)output {
    return YES;
}

#pragma mark - NMAVoiceCatalogDelegate

-(void)voiceCatalog:(NMAVoiceCatalog *)voiceCatalog didUpdateWithError:(NSError *)error {
    if (error) {
        DBG("Failed to update the voice catalog! %@", [error description])
    } else {
        NSArray *voicePackages = [NMAVoiceCatalog sharedVoiceCatalog].installedVoicePackages;

        DBG("%@", voicePackages)

        NMATTSAudioOutput *output = [NMATTSAudioOutput audioOutputWithText:@"Updated the voice catalog"];

        output.speechRate = AVSpeechUtteranceDefaultSpeechRate / 4.0f;
        [[NMAAudioManager sharedAudioManager] playOutput:output];
    }
}

@end
