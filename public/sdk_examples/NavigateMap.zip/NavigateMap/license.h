/*
 * Copyright © 2016 HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//
// important: update the strings below
//            for your application!
//
// see https://developer.here.com/
//
// steps to run this app:
// 1 - register or sign in there
// 2 - create an app and get the strings
//     specific for your app
// 3 - update the project settings: set the bundle
//     id specifc for your app
//

#define APP_ID         @""

#define APP_CODE       @""

#define LICENSE_KEY    @""
