/*
 * Copyright © 2016 HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */ 

#import <UIKit/UIKit.h>

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//
// super class for providing the alerts
//
@interface CMNViewController : UIViewController

- (void)alertForNotOnline;

- (void)alertForUnknownPosition;

- (void)alertForNavigationFailure;

- (void)alertForUpdateFailure;

- (void)alertForSuggestionFailure;

- (void)alertForEmailConfiguration;

- (void)alertForEmailFailure;

- (void)alertForRouteFailure;

@end
