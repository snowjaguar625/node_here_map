/*
 * Copyright © 2016 HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//
// available only in debug builds!
//
#ifdef DEBUG
    #define DBG(format, ...)                   NSLog(@"%d,%s,"format,__LINE__,__FUNCTION__,##__VA_ARGS__);
    #define DBG_CALLED                         DBG("called")
    #define STRINGIZE_BOOL(BOOL)               (BOOL ? @"TRUE" : @"FALSE")
#else
    #define DBG(format, ...)
    #define DBG_CALLED
    #define STRINGIZE_BOOL(BOOL)
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//
// available both in debug and release builds!
//

#define ASSERT(condition, desc)                NSAssert(condition, desc);

#define ERROR(format, ...)                     NSLog(@"StrollWithHere ERROR: "format,##__VA_ARGS__);

#define WARNING(format, ...)                   NSLog(@"StrollWithHere WARNING: "format,##__VA_ARGS__);

#define INFO(format, ...)                      NSLog(@"StrollWithHere INFO: "format,##__VA_ARGS__);

#define UNUSED(var)                            (void)(var);
