/*
 * Copyright © 2016 HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */ 

#import "CMNHudViewController.h"
#import "CMNDownloadViewController.h"
#import "dbg.h"

#import <NMAKit/NMAKit.h>

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@interface CMNHudViewController ()

- (void)close;

@property (nonatomic) BOOL isCancelled;

@property (nonatomic) BOOL hasProgressedWhenCancelled;

@property (nonatomic) BOOL closeDirectly;

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property (weak, nonatomic) IBOutlet UILabel *detailsLabel;

@property (weak, nonatomic) IBOutlet UIProgressView *progressBar;

@property (weak, nonatomic) IBOutlet UIButton *cancelButton;

@property (weak, nonatomic) IBOutlet UIView *buttonView;

@end

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@implementation CMNHudViewController

#pragma mark - Public methods

- (void)reset {
    DBG_CALLED

    self.view.hidden = FALSE;
    self.progressBar.progress = 0.0f;
    self.isCancelled = FALSE;
    self.hasProgressedWhenCancelled = FALSE;
    self.closeDirectly = FALSE;
    self.buttonView.hidden = FALSE;
    [self.cancelButton setTitle:@"Cancel" forState:UIControlStateNormal];
}

- (void)setTitle:(NSString *)title {
    self.titleLabel.text = title;
}

- (void)setDetails:(NSString *)details {
    self.detailsLabel.text = details;
}

- (void)setProgress:(CGFloat)progress {
    DBG("progress:|%.0f%%|", progress * 100.0f)

    if (self.isCancelled) {
        // trick: if cancelled and progressed,
        //        cancel only once!
        if (!self.hasProgressedWhenCancelled) {
            self.hasProgressedWhenCancelled = [[NMAMapLoader sharedMapLoader] cancelCurrentOperation];
        }
    } else {
        self.progressBar.progress = progress;
    }
}

- (void)hideCancelButton:(BOOL)show {
    self.buttonView.hidden = show;
}

- (void)needCloseButton {
    DBG_CALLED

    // no longer cancelling
    [self.cancelButton setTitle:@"Close" forState:UIControlStateNormal];

    self.closeDirectly = TRUE;
}

#pragma mark - Private methods

- (void)close {
    DBG_CALLED

    // get the parent view controller
    CMNDownloadViewController *vc = (CMNDownloadViewController *)self.parentViewController;

    // call the parent to hide the hud
    [vc hideHud];
}

#pragma mark - IBAction methods

- (IBAction)onCancel:(UIButton *)sender {
    DBG("progress:|%.0f%%|", self.progressBar.progress * 100.0f)

    // trick: if closing is requested or there
    //        is no progress, close!
    if (self.closeDirectly ||
        self.progressBar.progress == 0.0f) {
        [self close];
    } else {
        // cancelling
        self.detailsLabel.text = @"Cancelling...";

        // trick: the user no longer should tap
        //        the cancel button!
        [self hideCancelButton:TRUE];

        // trick: turn on the cancel flag: in case progress
        //        happens, cancel there!
        self.isCancelled = TRUE;

        // cancel the operation
        [[NMAMapLoader sharedMapLoader] cancelCurrentOperation];
    }
}

@end
