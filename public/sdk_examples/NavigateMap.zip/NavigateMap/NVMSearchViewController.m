/*
 * Copyright © 2016 HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */

#import "NVMSearchViewController.h"
#import "NVMMapViewController.h"
#import "NVMAddressCell.h"
#import "dbg.h"

#import <NMAKit/NMAKit.h>

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static NSString *CELL_IDENTIFIER = @"AddressCell";

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@interface NVMSearchViewController () <UISearchBarDelegate>

- (void)setup;

- (void)backHandler;

@property (strong, nonatomic) NMADiscoveryRequest *request;

@property (strong, nonatomic) NSArray *links;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *backButton;

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@implementation NVMSearchViewController

#pragma mark - Public methods

- (void)viewDidLoad {
    DBG_CALLED

    [super viewDidLoad];

    [self setup];
}

- (BOOL)prefersStatusBarHidden {
    return NO;
}

#pragma mark - Private methods

- (void)setup {
    DBG_CALLED
}

- (void)backHandler {
    DBG_CALLED

    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - IBAction methods

- (IBAction)onBack:(UIBarButtonItem *)sender {
    DBG_CALLED

    [self backHandler];
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    DBG_CALLED

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger count = self.links.count;

    DBG("count:|%ld|", (long)count)

    return count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NVMAddressCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER
                                                           forIndexPath:indexPath];
    NMAPlaceLink *link = self.links[indexPath.row];

    // configure the cell
    cell.nameLabel.text = link.name;
    cell.vicinitylabel.text = link.vicinityDescription;

    DBG("\n"
        "....row:|%ld|\n"
        "....name:|%@|\n"
        "....vicinity:|%@|\n",
        (long)indexPath.row,
        cell.nameLabel.text,
        cell.vicinitylabel.text)

    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NMAPlaceLink *link = self.links[indexPath.row];

    DBG("\n"
        "....row:|%ld|\n"
        "....name:|%@|\n"
        "....vicinity:|%@|\n",
        (long)indexPath.row,
        link.name,
        link.vicinityDescription)

    // get the presenting view controller
    NVMMapViewController *vc = (NVMMapViewController *)self.presentingViewController;

    // pass the link
    vc.searchedLink = link;

    // return back
    [self backHandler];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 52.0f;
}

#pragma mark - UISearchBarDelegate

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    DBG("text:|%@|", searchText)

    if (searchText.length) {
        NMAGeoPosition *position = [NMAPositioningManager sharedPositioningManager].currentPosition;

        // do we know the current postion?
        if (position) {
            self.request = [[NMAPlaces sharedPlaces] createSearchRequestWithLocation:position.coordinates
                                                                               query:searchText];
            self.request.collectionSize = 10;

            NSError *err = [self.request startWithBlock:^(NMARequest *request, id data, NSError *error) {
                // any error?
                if (error &&
                    error.code != NMARequestErrorNone){
                    ERROR("unable to suggest:|%ld -> %@|",
                          (long)error.code,
                          error.localizedDescription)

                    [self alertForSuggestionFailure];
                } else if (![data isKindOfClass:[NMADiscoveryPage class]]){
                    ERROR("invalid suggestion data returned");

                    [self alertForSuggestionFailure];
                } else{
                    NMADiscoveryPage *page = (NMADiscoveryPage*)data;
                    NSMutableArray *links = [NSMutableArray array];

                    // one-by-check the discovery results
                    for (id entry in page.discoveryResults){
                        if ([entry isKindOfClass:[NMAPlaceLink class]])
                            [links addObject:entry];
                    }

                    self.links = links;
                    [self.tableView reloadData];
                }

                self.request = nil;
            }];

            // any error?
            if (err &&
                err.code != NMARequestErrorNone) {
                ERROR("unable to suggest:|%ld -> %@|",
                      (long)err.code,
                      err.localizedDescription)

                self.request = nil;
            }
        } else {
            [self alertForUnknownPosition];
        }
    }
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    DBG_CALLED
}

@end
