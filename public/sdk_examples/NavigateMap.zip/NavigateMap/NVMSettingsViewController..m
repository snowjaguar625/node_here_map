/*
 * Copyright © 2016 HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */

#import "NVMSettingsViewController.h"
#import "NVMMapViewController.h"
#import "dbg.h"

#import <NMAKit/NMAKit.h>

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@interface NVMSettingsViewController ()

- (void)setup;

@property (weak, nonatomic) NVMMapViewController *parent;

@property (weak, nonatomic) IBOutlet UISegmentedControl *mapSchemeControl;

@property (weak, nonatomic) IBOutlet UISegmentedControl *transportControl;

@end

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

@implementation NVMSettingsViewController

#pragma mark - Public methods

- (void)viewWillAppear:(BOOL)animated {
    DBG_CALLED

    [super viewWillAppear:animated];

    [self setup];
}

- (BOOL)prefersStatusBarHidden {
    return NO;
}

#pragma mark - Private methods

- (void)setup {
    self.parent = (NVMMapViewController *)self.presentingViewController;

    // reflect the current settings on the controls
    [self.mapSchemeControl setSelectedSegmentIndex:self.parent.mapScheme];
    [self.transportControl setSelectedSegmentIndex:self.parent.transportMode];

    DBG("\n"
        "....map scheme:|%ld|\n"
        "....transport mode:|%ld|\n",
        (long)self.parent.mapScheme,
        (long)self.parent.transportMode)
}

#pragma mark - IBAction methods

- (IBAction)onBack:(UIBarButtonItem *)sender {
    DBG_CALLED

    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)onMapSCheme:(UISegmentedControl *)sender {
    MapScheme mapScheme = (MapScheme)sender.selectedSegmentIndex;

    DBG("map scheme:|%ld|", (long)mapScheme)

    self.parent.mapScheme = mapScheme;
}

- (IBAction)onTransport:(UISegmentedControl *)sender {
    TransportMode transportMode = (TransportMode)sender.selectedSegmentIndex;

    DBG("transport mode:|%ld|", (long)transportMode)

    self.parent.transportMode = transportMode;
}

@end
