//
//  AppDelegate.h
//  UrbanMobilityRoutingTest
//
//  Created by Lee, Ian on 08/08/2017.
//  Copyright © 2017 Lee, Ian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

