//
//  ViewController.m
//  UrbanMobilityRoutingTest
//
//  Created by Lee, Ian on 08/08/2017.
//  Copyright © 2017 Lee, Ian. All rights reserved.
//

#import "ViewController.h"

@import NMAKit;

@interface ViewController ()
@property (weak, nonatomic) IBOutlet NMAMapView *mapView;
@property (weak, nonatomic) IBOutlet UIButton *createRouteButton;
@property (nonatomic) NMAUrbanMobilityRouter* router;
@property (nonatomic) NMAMapRoute* mapRoute;
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // create geo coordinate
    NMAGeoCoordinates* geoCoordCenter =
    // [[NMAGeoCoordinates alloc] initWithLatitude:49.260327 longitude:-123.115025];
    [[NMAGeoCoordinates alloc] initWithLatitude:41.882736 longitude:-87.622004];
    // set map view with geo center
    [self.mapView setGeoCenter:geoCoordCenter withAnimation:NMAMapAnimationNone];
    // set zoom level
    self.mapView.zoomLevel = 13.2;
    self.createRouteButton.titleLabel.adjustsFontSizeToFitWidth = YES;
}

- (void)didReceiveMemoryWarning { [super didReceiveMemoryWarning]; }

- (void)createRoute
{
    NSMutableArray* stops = [[NSMutableArray alloc] initWithCapacity:4];
    
    NMAGeoCoordinates *coordsStart = [NMAGeoCoordinates geoCoordinatesWithLatitude:49.261789 longitude:-122.999591];
    NMAGeoCoordinates *coordsEnd = [NMAGeoCoordinates geoCoordinatesWithLatitude:49.254150 longitude:-123.016819];
    
    NMAWaypoint *waypointStart = [NMAWaypoint new];
    waypointStart.originalPosition = coordsStart;
    waypointStart.navigablePosition = coordsStart;
    
    NMAWaypoint *waypointEnd = [NMAWaypoint new];
    waypointEnd.originalPosition = coordsEnd;
    waypointEnd.navigablePosition = coordsEnd;
    
    [stops addObject:waypointStart];
    [stops addObject:waypointEnd];
    
    // Create an NMARoutingMode, then set it to find the fastest car route without going on Highway.
    NMARoutingMode* routingMode = [[NMARoutingMode alloc] init];
    routingMode.transportMode = NMATransportModeUrbanMobility;
    routingMode.resultLimit = 1;
    
    // Initialize the NMACoreRouter
    if ( !self.router )
    {
        self.router = [[NMAUrbanMobilityRouter alloc] init];
    }
    
    void (^completeBlock)(NMAUrbanMobilityRouteResult *, NMAUrbanMobilityError) =
    ^(NMAUrbanMobilityRouteResult *routeResult, NMAUrbanMobilityError error) {
        // completion block logic
        // access to NMAUrbanMobilityRouteResult or error
        // If the route was calculated successfully
        if(!error && routeResult.routes && routeResult.routes.count > 0)
        {
            NMARoute* route = [routeResult.routes objectAtIndex:0];
            NSArray* sections = route.sections;
            
            NSLog(@"the number of route results: %lu", routeResult.routes.count);
            NSLog(@"route results: %@", routeResult.routes);
            
            NSLog(@"the number of sections: %lu", sections.count);
            NSLog(@"section results in current route: %@", sections);
            for(NSUInteger index=0; index < route.sections.count; index++){
                //NSLog(@"%lu: %@", index, route.sections[index]);
                NMAUrbanMobilityRouteSection* section = [sections objectAtIndex:index];
                NMAUrbanMobilityRouteSection* nextSection = nil;
                if (index + 1 < sections.count){
                    nextSection = [sections objectAtIndex:index+1];
                }
                
                NSArray* alerts = section.alerts;
                if(alerts.count > 0){
                    NSLog(@"[Alert Information of Section %lu]", index);
                    for(NSUInteger aIndex = 0; aIndex < alerts.count; aIndex++){
                        NMAUrbanMobilityAlert* alert = [alerts objectAtIndex:aIndex];
                        NSLog(@"Image Caption: %@", alert.imageCaption);
                        NSLog(@"Image Url: %@", alert.imageUrl);
                        NSLog(@"Information: %@", alert.info);
                    }
                }
                
                //NSLog(@"Arrival: %@", section.arrival);
                //NSLog(@"Departure: %@", section.departure);

                if (section.transportType < NMAUrbanMobilityTransportTypeUnknown) {
                    NMAUrbanMobilityManeuver* nextManeuver = nil;
                    NMAUrbanMobilityIntermediateStop *depatureStop = nil, *arrivalStop = nil;
                    
                    if(section.intermediateStops.count > 0){
                        depatureStop = [section.intermediateStops objectAtIndex:0];
                        arrivalStop = [section.intermediateStops objectAtIndex:section.intermediateStops.count - 1];
                    } else {
                        NSLog(@"No intermediateStops information!!!");
                        continue;
                    }
                    
                    if(nextSection.transportType == NMAUrbanMobilityTransportTypeWalk &&
                       nextSection.maneuvers){
                        nextManeuver = [nextSection.maneuvers objectAtIndex:0];
                    }
                    
                    NMAUrbanMobilityDeparture* departure = section.departure;
                    NMAUrbanMobilityArrival* arrival = section.arrival;
                    // Add info to help end-users locate access point of the metro/train platform
                    if ((section.transportType==NMAUrbanMobilityTransportTypeMonorail ||
                         section.transportType==NMAUrbanMobilityTransportTypeTram ||
                         section.transportType==NMAUrbanMobilityTransportTypeSubway||
                         section.transportType==NMAUrbanMobilityTransportTypeRegionalTrain ||
                         section.transportType==NMAUrbanMobilityTransportTypeHighspeedTrain ||
                         section.transportType==NMAUrbanMobilityTransportTypeIntercityTrain ||
                         section.transportType==NMAUrbanMobilityTransportTypeCityTrain) &&
                        nextManeuver &&
                        nextManeuver.nextRoadName)
                    {
                        // If this maneuver is transit and the next maneuver is walking
                        NSLog(@"Take %@ at %@ towards %@ and get off at %@ after %lu stops then head towards %@ exit",
                              departure.transport.name, departure.station.address.name,
                              departure.transport.direction, arrival.station.address.name,
                              section.intermediateStops.count, nextManeuver.nextRoadName);
                    } else {
                        // Otherwise, present the transit info normally
                        NSLog(@"Take %@ at %@ towards %@ and get off at %@ after %lu stops",
                              departure.transport.name, departure.station.address.name,
                              departure.transport.direction, arrival.station.address.name,
                              section.intermediateStops.count);
                    }
                } else {
                    NSArray* maneuvers = section.maneuvers;
                    
                    if(maneuvers){
                        NSUInteger mCount = maneuvers.count;
                        if(nextSection)
                            mCount--;   // To prevent print arrive message of each section for walk.
                        for(NSUInteger mIndex=0;mIndex<mCount;mIndex++){
                            NMAUrbanMobilityManeuver* maneuver = [maneuvers objectAtIndex:mIndex];
                            NSLog(@"%@", maneuver.instruction);
                        }
                    } else {
                        NSLog(@"Walk %lu meters", (unsigned long)section.distance);
                    }
                }
            }
            
            self.mapRoute = [NMAMapRoute mapRouteWithRoute:route];
            [self.mapView addMapObject:self.mapRoute];
            
            // sets the map scheme to include transit.
            [self.mapView setMapScheme:NMAMapSchemeNormalDayTransit];
            // zoom to display the entire route
            [self.mapView setBoundingBox:route.boundingBox withAnimation:NMAMapAnimationBow];
        } else if(error) {
            // Display a message indicating route calculation failed
            NSLog( @"Error: route calculation returned error code %d", (int)error);
        }
    };
    
    // Trigger the route calculation
    __block NSProgress *progress;
    progress = [(NMAUrbanMobilityRouter *) self.router calculateRouteWithStops: stops
                                                                   routingMode:routingMode
                                                               completionBlock:completeBlock];
}

- (IBAction)buttonDidClicked:(id)sender
{
    // Clear map if previous results are still on map, otherwise proceed to creating route
    if ( self.mapRoute )
    {
        [self.mapView removeMapObject:self.mapRoute];
        self.mapRoute = nil;
    }
    else
    {
        [self createRoute];
    }
}

@end
