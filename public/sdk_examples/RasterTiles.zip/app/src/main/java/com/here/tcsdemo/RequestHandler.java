package com.here.tcsdemo;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;


/**
 * Created by krishnan on 08-Aug-17.
 */

public class RequestHandler {
    private static RequestHandler instance;

    private AsyncHttpClient client;

    private RequestHandler(){
        client = new AsyncHttpClient();
    }

    public static RequestHandler getInstance(){
        if(instance == null){
            instance = new RequestHandler();
        }
        return instance;
    }

    // You can add more parameters if you need here.
    public void makeRequest(final String url, final RequestListener listener){
        client.get(url, new AsyncHttpResponseHandler() {

            @Override
            public boolean getUseSynchronousMode() {
                return false;
            }

            @Override
            public void onStart() {
                // called before request is started
                //Some debugging code here
            }

            @Override
            public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody) {
                listener.onSuccess(statusCode,headers,responseBody,url);
            }

            @Override
            public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody, Throwable error) {

            }



            @Override
            public void onRetry(int retryNo) {


            }
        });
    }
}

