package com.here.tcsdemo;

import cz.msebera.android.httpclient.Header;

/**
 * Created by krishnan on 08-Aug-17.
 */

public interface RequestListener {
    public void onSuccess(int statusCode, Header[] headers, byte[] response,String url);
}
