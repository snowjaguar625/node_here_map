package com.here.tcsdemo;

import android.Manifest;
import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.PointF;
import android.os.Bundle;
import android.util.Log;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import com.here.android.mpa.common.GeoCoordinate;
import com.here.android.mpa.common.IconCategory;
import com.here.android.mpa.common.OnEngineInitListener;

import com.here.android.mpa.common.ViewObject;

import com.here.android.mpa.guidance.NavigationManager;

import com.here.android.mpa.mapping.Map;
import com.here.android.mpa.mapping.MapFragment;
import com.here.android.mpa.mapping.MapGesture;
import com.here.android.mpa.mapping.MapOverlayType;
import com.here.android.mpa.mapping.MapRasterTileSource;


import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;

public class MainActivity extends Activity {

    private static final String TAG = "MainActivity";

    // map embedded in the map fragment
    private Map map = null;
    // map fragment embedded in this activity
    private MapFragment mapFragment = null;
    // UI controls
    private Switch mapRasterTile;
    private boolean useRasterTile;

    private TileSourceBase tileSourceBase;
    private UrlTileSource urlTileSourceBase;

    private String mapRasterSource =  "https://{s}.base.maps.api.here.com/maptile/2.1/maptile/newest/normal.day/{z}/{x}/{y}/256/png8?style=fleet";
    private String urlRasterSource =  "http://tile.openstreetmap.com/{z}/{x}/{y}.png";

    private final static int REQUEST_CODE_ASK_PERMISSIONS = 1;

    private static final String[] REQUIRED_SDK_PERMISSIONS = new String[] {
            Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.WRITE_EXTERNAL_STORAGE};
    protected void checkPermissions() {
        final List<String> missingPermissions = new ArrayList<String>();
        // check all required dynamic permissions
        for (final String permission : REQUIRED_SDK_PERMISSIONS) {
            final int result = ContextCompat.checkSelfPermission(this, permission);
            if (result != PackageManager.PERMISSION_GRANTED) {
                missingPermissions.add(permission);
            }
        }
        if (!missingPermissions.isEmpty()) {
            // request all missing permissions
            final String[] permissions = missingPermissions
                    .toArray(new String[missingPermissions.size()]);
            ActivityCompat.requestPermissions(this, permissions, REQUEST_CODE_ASK_PERMISSIONS);
        } else {
            final int[] grantResults = new int[REQUIRED_SDK_PERMISSIONS.length];
            Arrays.fill(grantResults, PackageManager.PERMISSION_GRANTED);
            onRequestPermissionsResult(REQUEST_CODE_ASK_PERMISSIONS, REQUIRED_SDK_PERMISSIONS,
                    grantResults);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,  String permissions[],
                                           int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_ASK_PERMISSIONS:
                for (int index = permissions.length - 1; index >= 0; --index) {
                    if (grantResults[index] != PackageManager.PERMISSION_GRANTED) {
                        // exit the app if one permission is not granted
                        Toast.makeText(this, "Required permission '" + permissions[index]
                                + "' not granted, exiting", Toast.LENGTH_LONG).show();
                        finish();
                        return;
                    }
                }
                // all permissions were granted
                initialize();
                break;
        }
    }



    private void initialize(){
        // Search for the map fragment to finish setup by calling init().
        mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.mapfragment);

        mapRasterTile = (Switch) findViewById(R.id.tile_selector);
        mapRasterTile.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                useRasterTile = isChecked;
                addRasterTile(isChecked);

            }
        });

        mapFragment.init(new OnEngineInitListener() {
            @Override
            public void onEngineInitializationCompleted(Error error) {
                if (error == Error.NONE) {
                    map = mapFragment.getMap();
                    map.setProjectionMode(Map.Projection.MERCATOR);
                    map.setCenter(new GeoCoordinate(52.51534,13.37703), Map.Animation.NONE);
                    map.setZoomLevel(17);
                    // add appid appcode for here map tile api
                    mapRasterSource=mapRasterSource+getAppIdAppCode();
                    addRasterTile(useRasterTile);
                } else {
                    Log.e(TAG, "ERROR: Cannot initialize Map Fragment " + error.name());
                    Log.e(TAG, error.getDetails());
                    Log.e(TAG, error.getStackTrace());
                }
            }
        });
    }


    private void addRasterTile(boolean addRasterTile){
        if(tileSourceBase !=null){
            map.removeRasterTileSource(tileSourceBase);
        }
        if(urlTileSourceBase !=null){
            map.removeRasterTileSource(urlTileSourceBase);
        }
        if(addRasterTile){
            tileSourceBase = TileSourceBase.getInstance(getApplicationContext());
            tileSourceBase.setUrl(mapRasterSource);
            tileSourceBase.setMinZoomLevel(16);
            map.addRasterTileSource(tileSourceBase);
        }else{
            urlTileSourceBase = new UrlTileSource();
            urlTileSourceBase.setUrl(urlRasterSource);
            map.addRasterTileSource(urlTileSourceBase);

        }
    }

    private String getAppIdAppCode(){
        String returnValue="";
        try {
            ApplicationInfo ai = getPackageManager().getApplicationInfo(this.getPackageName(), PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;
            String appId = bundle.getString("com.here.android.maps.appid");
            String appCode = bundle.getString("com.here.android.maps.apptoken");
            returnValue = "&app_id="+appId+"&app_code="+appCode;
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(TAG, "Failed to load meta-data, NameNotFound: " + e.getMessage());
        } catch (NullPointerException e) {
            Log.e(TAG, "Failed to load meta-data, NullPointer: " + e.getMessage());
        }
        return  returnValue;
    };


      @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkPermissions();


    }






}
