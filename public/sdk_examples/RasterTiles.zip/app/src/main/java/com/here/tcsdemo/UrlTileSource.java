package com.here.tcsdemo;

import com.here.android.mpa.mapping.MapOverlayType;
import com.here.android.mpa.mapping.UrlMapRasterTileSourceBase;

/**
 * Created by krishnan on 08-Aug-17.
 */

public class UrlTileSource extends UrlMapRasterTileSourceBase {

    private String url = "";

    public UrlTileSource()
    {
        // We want the tiles placed over everything else
        setOverlayType(MapOverlayType.FOREGROUND_OVERLAY);

        // We don't want the map visible beneath the tiles
        setTransparency(Transparency.OFF);

        setTileSize(256);

        hideAtZoomRange(1,15);
        showAtZoomRange(16,20);

    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public String getUrl(int x, int y, int zoomLevel)
    {
        String ret = this.url;


        ret = ret.replace("{z}", "" + zoomLevel);
        ret = ret.replace("{x}", "" + x);
        ret = ret.replace("{y}", "" + y);

        return ret;
    }
}
