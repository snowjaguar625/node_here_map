package com.here.tcsdemo;

/**
 * Created by krishnan on 20-Jul-17.
 */


import com.here.android.mpa.mapping.MapOverlayType;
import com.here.android.mpa.mapping.MapRasterTileSource;



import android.content.Context;
import android.util.Log;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import java.util.HashMap;


import cz.msebera.android.httpclient.Header;

public class TileSourceBase extends MapRasterTileSource {

    private String url = "";
    private Context contex;

    private static TileSourceBase mInstance;
    private int minZoomLevel = 16;
   private HashMap<String,String> urlReuested;
    private int server=0;


    public TileSourceBase(Context context){
        // for creading/writing objects
        this.contex=context;

        // We want the tiles placed over everything else
        setOverlayType(MapOverlayType.FOREGROUND_OVERLAY);
        setTransparency(Transparency.OFF);

        setTileSize(256);

        // to avoid duplicate requests
        urlReuested= new HashMap<String,String>();
   }

    /**
     * To set minimum zoom level from which raster tiles are visible
     * @param minZoomLevel
     */
    public void setMinZoomLevel(int minZoomLevel){
        hideAtZoomRange(0,minZoomLevel-1);
        showAtZoomRange(minZoomLevel,20);
        this.minZoomLevel=minZoomLevel;
    }

    /**
     * To get Tile Srouce Base instance
     * @param context
     * @return
     */
    public static synchronized TileSourceBase getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new TileSourceBase(context);
        }
        return mInstance;
    }


    /**
     * For setting the base url for raster tiles
     * @param url
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * To check if tile has to be requested
     * @param x
     * @param y
     * @param zoomLevel
     * @return
     */
    @Override
    public boolean hasTile(int x, int y, int zoomLevel) {
        boolean returnValue=false;
        // to avoid uncessary return only true for rquired zoom levels
        if(zoomLevel>=minZoomLevel) {
            returnValue = true;
        }

        return returnValue;
    }

    @Override
    public TileResult getTileWithError (int x, int y, int zoomLevel){
        TileResult  result=null;
        String url=getUrl(x,y,zoomLevel);
        String key = getKey(url);

        // check if object is available in file storage
        Object readRsult=readObject(contex,key);
        if(readRsult!=null){
                byte[] map=(byte[])readRsult;
                result= new TileResult(TileResult.Error.NONE, map);

       }else{
            // if not availabel in file stores, return a not ready flag
            // and initiate an async call
            result= new TileResult(TileResult.Error.NOT_READY, null);
            // check if the request might already have been sent
            if(urlReuested.get(key)==null){
                // make async call
                RequestHandler handler = RequestHandler.getInstance();
                handler.makeRequest(url, new RequestListener(){
                         @Override
                         public void onSuccess(int statusCode, Header[] headers, byte[] response,String url) {
                            // write the image returned to file storage
                             try {
                                 writeObject(contex,getKey(url),response);

                             }catch (Exception e){
                                 Log.e("getTileWithError","Error writing file tiles");
                             }
                         }
                     });
                urlReuested.put(key,"requested");
            }
        }
        return result;

    }

    /**
     * Get the key  Z_X_Y from the url
     * @param url
     * @return
     */
    private String getKey(String url){
        String[] part= url.split("https://[1-4].base.maps.api.here.com/maptile/2.1/maptile/newest/normal.day/")[1].split("/");
        String key="undefined";
        if(part.length>3){
             key= part[0]+"_"+ part[1]+"_"+ part[2];
        }
        return key;
    };


    /**
     * Write the image into file storage
     * @param context
     * @param key
     * @param object
     */

    public static void writeObject(Context context, String key, Object object)  {
        FileOutputStream fos=null;
        ObjectOutputStream oos = null;
        try{

         fos = context.openFileOutput(key, Context.MODE_PRIVATE);
         oos = new ObjectOutputStream(fos);
        oos.writeObject(object);
        }catch(Exception e){
            Log.e("getTileWithError","Error readinfg tiles"+e.getMessage());
        }finally {
            try {
                if(oos!=null)
                    oos.close();
                if(fos!=null)
                    fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Get image from file storage
     * @param context
     * @param key
     * @return
     */
    public static Object readObject(Context context, String key)  {
        FileInputStream fis=null;
        ObjectInputStream ois=null;
        Object object=null;
        try{

            fis= context.openFileInput(key);
            ois = new ObjectInputStream(fis);
            object = ois.readObject();
         }catch(Exception e){

            object=null;
        }finally {
            try {
                if(ois!=null)
                ois.close();
                if(fis!=null)
                fis.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
         }
        return object;
    }

    /**
     * Update x,y,z values in the url
     * @param x
     * @param y
     * @param zoomLevel
     * @return
     */
    private  String getUrl(int x, int y, int zoomLevel)
    {
        String ret = this.url;
        server++;
        if(server>4){
            server=1;
        }
        ret = ret.replace("{s}", "" + server);
        ret = ret.replace("{z}", "" + zoomLevel);
        ret = ret.replace("{x}", "" + x);
        ret = ret.replace("{y}", "" + y);

        return ret;
    }







}