package com.here.tcsdemo;

import android.app.Activity;
import android.graphics.PointF;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.here.android.mpa.common.GeoCoordinate;
import com.here.android.mpa.common.IconCategory;
import com.here.android.mpa.common.OnEngineInitListener;
import com.here.android.mpa.common.ViewObject;
import com.here.android.mpa.mapping.Map;
import com.here.android.mpa.mapping.MapGesture;
import com.here.android.mpa.venues3d.DeselectionSource;
import com.here.android.mpa.venues3d.Level;
import com.here.android.mpa.venues3d.Space;
import com.here.android.mpa.venues3d.Venue;
import com.here.android.mpa.venues3d.VenueController;
import com.here.android.mpa.venues3d.VenueMapFragment;
import com.here.android.mpa.venues3d.VenueService;

import java.util.EnumSet;
import java.util.List;

public class MainActivity extends Activity {
    private static final String TAG = MainActivity.class.getSimpleName();

    private VenueMapFragment m_venueMapFragment;
    private Map m_map;
    private ListView m_floorSwitcher;
    private AdapterView.OnItemClickListener floorSwitchHandler = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            view.setSelected(true);
            VenueController controller = m_venueMapFragment.getVenueController(m_venueMapFragment.getSelectedVenue());
            if (controller != null) {
                Level level = controller.getVenue().getLevels().get(controller.getVenue().getLevels().size() - 1 - position);
                controller.selectLevel(level);
            }
        }
    };
    private VenueMapFragment.VenueListener venueHandler = new VenueMapFragment.VenueListener() {
        @Override
        public void onVenueTapped(Venue venue, float x, float y) {
            Log.i(TAG, "onVenueTapped: " + venue.getContent().getName());
            m_venueMapFragment.selectVenue(venue);
        }

        @Override
        public void onVenueSelected(Venue venue) {
            Log.i(TAG, "onVenueSelected : " + venue.getContent().getName() + " / " + venue.getId());

            m_floorSwitcher.setAdapter(new VenueFloorAdapter(getApplication(), venue.getLevels()));
            m_floorSwitcher.setVisibility(View.VISIBLE);

            updateSelectedLevel();
        }

        @Override
        public void onVenueDeselected(Venue venue, DeselectionSource source) {
            Log.i(TAG, "onVenueDeselected");
            m_floorSwitcher.setAdapter(null);
            m_floorSwitcher.setVisibility(View.INVISIBLE);
        }

        @Override
        public void onSpaceSelected(Venue venue, Space space) {
            Log.i(TAG, "onSpaceSelected");
        }

        @Override
        public void onSpaceDeselected(Venue venue, Space space) {
            Log.i(TAG, "onSpaceDeselected");
        }

        @Override
        public void onFloorChanged(Venue venue, Level oldLevel, Level newLevel) {
            Log.i(TAG, "onFloorChanged");
        }

        @Override
        public void onVenueVisibleInViewport(Venue venue, boolean visible) {
            Log.i(TAG, "onVenueVisibleInViewport");
        }
    };
    private VenueService.VenueServiceListener venueServiceHandler = new VenueService.VenueServiceListener() {
        @Override
        public void onInitializationCompleted(VenueService.InitStatus result) {
            if (result == VenueService.InitStatus.ONLINE_SUCCESS || result == VenueService.InitStatus.OFFLINE_SUCCESS) {
                Log.e(TAG, "VenueService initialized");
            } else {
                Log.e(TAG, "Could not initialize VenueService");
            }
        }

        @Override
        public void onGetVenueCompleted(Venue venue) {
            Log.i(TAG, "VenueService: onGetVenueCompleted");
        }
    };
    // gesture and click handler
    private MapGesture.OnGestureListener gestureHandler = new MapGesture.OnGestureListener.OnGestureListenerAdapter() {
        @Override
        public boolean onMapObjectsSelected(List<ViewObject> viewObjects) {
            Log.i(TAG, "onMapObjectsSelected");
            return false;
        }

        @Override
        public boolean onLongPressEvent(PointF p) {
            Log.i(TAG, "onLongPressEvent");
            return false;
        }
    };
    private OnEngineInitListener engineInitHandler = new OnEngineInitListener() {
        @Override
        public void onEngineInitializationCompleted(OnEngineInitListener.Error error) {
            if (error != Error.NONE) {
                Log.e(TAG, "ERROR: Cannot initialize VenueMapFragment" + error.toString());
                return;
            }

            Log.i(TAG, "SUCCESS: Map fragment initialized without issues.");

            // get map instance
            m_map = m_venueMapFragment.getMap();

            // center position
            GeoCoordinate cc = new GeoCoordinate(52.51885, 13.41611);
            m_map.setCenter(cc, Map.Animation.NONE);
            m_map.setZoomLevel(18);

            m_map.setMapScheme(Map.Scheme.PEDESTRIAN_DAY);
            m_map.setProjectionMode(Map.Projection.GLOBE);
            m_map.setExtrudedBuildingsVisible(false);
            m_map.setLandmarksVisible(false);
            m_map.setCartoMarkersVisible(IconCategory.ALL, true);
            m_map.setPedestrianFeaturesVisible(EnumSet.of(Map.PedestrianFeature.BRIDGE, Map.PedestrianFeature.CROSSWALK, Map.PedestrianFeature.ELEVATOR, Map.PedestrianFeature.ESCALATOR, Map.PedestrianFeature.STAIRS, Map.PedestrianFeature.TUNNEL));

            // set gesture handler
            m_venueMapFragment.getMapGesture().addOnGestureListener(gestureHandler);

            // setup venue maps
            m_venueMapFragment.setFloorChangingAnimation(true);
            m_venueMapFragment.setVenueEnteringAnimation(true);
            m_venueMapFragment.setVenuesInViewportCallback(true);

            m_venueMapFragment.getVenueService().addListener(venueServiceHandler);

            m_floorSwitcher = (ListView) findViewById(R.id.floorListView);
            m_floorSwitcher.setOnItemClickListener(floorSwitchHandler);

            m_venueMapFragment.addListener(venueHandler);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        m_venueMapFragment = (VenueMapFragment) getFragmentManager().findFragmentById(R.id.venuemap_fragment);
        m_venueMapFragment.init(engineInitHandler);
    }

    private void updateSelectedLevel() {
        Level selectedLevel = m_venueMapFragment.getVenueController(m_venueMapFragment.getSelectedVenue()).getSelectedLevel();
        if (selectedLevel != null) {
            int pos = ((VenueFloorAdapter) m_floorSwitcher.getAdapter()).getLevelIndex(selectedLevel);
            if (pos != -1) {
                m_floorSwitcher.setSelection(pos);
                m_floorSwitcher.smoothScrollToPosition(pos);
                m_floorSwitcher.setItemChecked(pos, true);
            }
        }
    }

}
