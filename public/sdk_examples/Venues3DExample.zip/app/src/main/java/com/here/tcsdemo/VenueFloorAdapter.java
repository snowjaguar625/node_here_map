package com.here.tcsdemo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.here.android.mpa.venues3d.Level;

import java.util.List;

public class VenueFloorAdapter extends BaseAdapter {

    Level[] m_floors;

    private LayoutInflater m_inflater = null;

    public VenueFloorAdapter(Context context, List<Level> levels) {
        this.m_floors = new Level[levels.size()];

        for (int i = 0; i < levels.size(); i++) {
            this.m_floors[levels.size() - i - 1] = levels.get(i);
        }

        m_inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return m_floors.length;
    }

    @Override
    public Object getItem(int position) {
        return m_floors[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;

        if (v == null)
            v = m_inflater.inflate(R.layout.floor_item, null);

        TextView text = (TextView) v.findViewById(R.id.floorName);
        text.setText(m_floors[position].getFloorSynonym());

        // update text size, based on the number of digits
        updateFont(text);

        // if this is ground floor, but there are basement floors, then show small separation
        int showSep = m_floors[position].getFloorNumber() == 0 && position != m_floors.length - 1 ? View.VISIBLE : View.INVISIBLE;
        View separator = v.findViewById(R.id.floorGroundSep);
        separator.setVisibility(showSep);

        return v;
    }

    public int getLevelIndex(Level level) {
        for (int i = 0; i < m_floors.length; i++) {
            if (m_floors[i].getFloorNumber() == level.getFloorNumber()) {
                return i;
            }
        }

        return -1;
    }

    public void updateFont(TextView text) {
        int size = text.getText().length();
        switch (size) {
            case 1:
                text.setTextSize(24);
                break;
            case 2:
                text.setTextSize(21);
                break;
            case 3:
                text.setTextSize(28);
                break;
            case 4:
                text.setTextSize(15);
                break;
            default:
                text.setTextSize(16);
                break;
        }
    }

}