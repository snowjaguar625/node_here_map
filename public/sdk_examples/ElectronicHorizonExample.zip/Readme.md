To import project into Android Studio select **Import project** and specify path to the folder with sources.

Electronic Horizon requires the HERE SDK Premium flavor. To make it work do the next 3 things:
1) Put **HERE-sdk.aar** file into **<app_folder>/app/libs**
2) Add your HERE SDK credentials to **AndroidManifest.xml**
3) Adapt package name and applicationId according to your requested package name on developer.here.com

Congratulations! Now you can build and run your app.

More information on how to set up HERE SDK to work with your app can be found here: https://developer.here.com/documentation/android-premium/topics/credentials.html

----

Copyright (c) 2018 HERE Global B.V.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

----
