/*
 * Copyright (c) 2011-2017 HERE Europe B.V.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.here.tcsdemo;

import android.app.Activity;
import android.graphics.PointF;
import android.view.View;
import android.widget.Button;

import com.here.android.mpa.common.GeoCoordinate;
import com.here.android.mpa.common.GeoPosition;
import com.here.android.mpa.common.PositioningManager;
import com.here.android.mpa.common.PositioningManager.OnPositionChangedListener;
import com.here.android.mpa.guidance.NavigationManager;
import com.here.android.mpa.guidance.NavigationManager.NavigationManagerEventListener;
import com.here.android.mpa.mapping.Map;
import com.here.android.mpa.mapping.MapFragment;
import com.here.android.mpa.mapping.MapGesture.OnGestureListener;
import com.here.android.mpa.routing.Route;

import java.lang.ref.WeakReference;

/**
 * This class is a helper class that allows guidance, positioning, routing
 * and electronic horizon to work with each other.
 */
class NavigationHelper {
    private final Map m_map;
    private final Activity m_activity;
    private final ErrorAlertDialog m_errorAlertDialog;
    private NavigationManager m_navigationManager;
    private final ElectronicHorizonHelper m_electronicHorizonHelper;
    private final RouteHelper m_routeHelper;
    private GeoCoordinate m_lastPosition;
    private boolean m_isSimulating;
    private Button m_btnSimulate;

    private final OnGestureListener m_gestureListener =
            new OnGestureListener.OnGestureListenerAdapter() {
                @Override
                public boolean onLongPressEvent(PointF point) {
                    GeoCoordinate selectedLocation = m_map.pixelToGeo(point);
                    m_routeHelper.calculateRoute(m_lastPosition, selectedLocation);
                    return true;
                }
            };

    private final OnPositionChangedListener m_positionListener = new OnPositionChangedListener() {

        @Override
        public void onPositionUpdated(PositioningManager.LocationMethod method,
                                      GeoPosition position, boolean isMapMatched) {
            if (m_lastPosition == null) {
                m_map.setCenter(position.getCoordinate(), Map.Animation.NONE);
            }
            m_lastPosition = position.getCoordinate();
        }

        @Override
        public void onPositionFixChanged(PositioningManager.LocationMethod method,
                                         PositioningManager.LocationStatus status) {
        }
    };


    private final NavigationManagerEventListener m_navigationManagerEventListener =
            new NavigationManagerEventListener() {
        @Override
        public void onEnded(final NavigationManager.NavigationMode mode) {
            stopNavigation();
        }
    };

    private final RouteHelper.Listener m_routeHelperListener = new RouteHelper.Listener() {
        @Override
        public void calculated(boolean success, Route route) {
            if (success) {
                routeCalculated(route);
            }
        }
    };

    NavigationHelper(MapFragment mapFragment, Activity activity,
                     ElectronicHorizonHelper electronicHorizonHelper) {
        m_map = mapFragment.getMap();
        m_activity = activity;
        m_electronicHorizonHelper = electronicHorizonHelper;
        m_errorAlertDialog = new ErrorAlertDialog(activity);
        m_routeHelper = new RouteHelper(m_errorAlertDialog, m_map, m_routeHelperListener);
        m_lastPosition = null;
        m_isSimulating = false;
        initPositioningManager();
        m_map.setZoomLevel(15);
        mapFragment.getPositionIndicator().setVisible(true);
        mapFragment.getMapGesture().addOnGestureListener(m_gestureListener, 1, true);
        initNavigationManager();
        initBtnSimulate();
    }

    private void initPositioningManager() {
        PositioningManager positioningManager = PositioningManager.getInstance();
        positioningManager.addListener(new WeakReference<>(m_positionListener));
        positioningManager.start(PositioningManager.LocationMethod.GPS_NETWORK);
    }

    private void initNavigationManager() {
        m_navigationManager = NavigationManager.getInstance();
        m_navigationManager.setMap(m_map);
        m_navigationManager.addNavigationManagerEventListener(
                new WeakReference<>(m_navigationManagerEventListener));
        m_navigationManager.setMapUpdateMode(NavigationManager.MapUpdateMode.ROADVIEW_NOZOOM);
    }

    private void routeCalculated(Route route) {
        m_routeHelper.addMapRoute(route);
        m_electronicHorizonHelper.setRoute(route);
    }

    void stopNavigation() {
        m_isSimulating = false;
        m_btnSimulate.setText(R.string.simulate);
        m_navigationManager.stop();
        m_map.setZoomLevel(15);
        m_map.setTilt(0);
    }

    private void startNavigation() {
        Route route = m_routeHelper.getRoute();
        if (route == null) {
            m_errorAlertDialog.showErrorDialog(R.string.no_route_error_title, R.string.no_route_error_hint);
            return;
        }

        m_map.setZoomLevel(18);
        m_map.setTilt(60);

        NavigationManager.Error error = m_navigationManager.simulate(route, 14);
        if (error != NavigationManager.Error.NONE) {
            stopNavigation();
            m_errorAlertDialog.showErrorDialog(R.string.guidance_error_title, R.string.guidance_error);
            return;
        }
        m_isSimulating = true;
        m_btnSimulate.setText(R.string.stop);
    }

    private void initBtnSimulate() {
        m_btnSimulate = m_activity.findViewById(R.id.btnSimulate);
        m_btnSimulate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (m_isSimulating) {
                    stopNavigation();
                } else {
                    startNavigation();
                }
            }
        });
    }
}
