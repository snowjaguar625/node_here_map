/*
 * Copyright (c) 2011-2017 HERE Europe B.V.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.here.tcsdemo;

import java.io.File;
import java.util.ArrayList;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.here.android.mpa.common.MapSettings;
import com.here.android.mpa.common.OnEngineInitListener;
import com.here.android.mpa.mapping.MapFragment;

/**
 * Main activity. It requires the permissions, initializes application.
 */
public class MainActivity extends AppCompatActivity {

    private static final String ISOLATED_MAP_SERVICE_INTENT =
            "com.here.android.mpa.service.MapService.ElectronicHorizon.isolated";
    private final static int REQUEST_CODE_ASK_PERMISSIONS = 1;

    private NavigationHelper m_navigationHelper = null;
    private ElectronicHorizonHelper m_electronicHorizonHelper = null;
    private SettingsData m_settingsData = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String diskCacheRoot = getApplicationContext().getFilesDir().getPath()
                + File.separator + ".here-maps";
        boolean success = MapSettings.setIsolatedDiskCacheRootPath(
                diskCacheRoot, ISOLATED_MAP_SERVICE_INTENT);
        if (success) {
            requirePermissions();
        }
    }

    @Override
    public void onDestroy() {
        if (m_electronicHorizonHelper != null) {
            m_electronicHorizonHelper.stop();
        }

        if (m_navigationHelper != null) {
            m_navigationHelper.stopNavigation();
        }
        super.onDestroy();
    }

    private void requirePermissions() {
        String[] missingPermissions = getPermissionsToRequest();
        if (missingPermissions.length == 0) {
            initMapFragment();
        }
        else {
            ActivityCompat.requestPermissions(this, missingPermissions,
                    REQUEST_CODE_ASK_PERMISSIONS);
        }
    }

    private String[] getPermissionsToRequest() {
        ArrayList<String> permissionList = new ArrayList<>();
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(),
                    PackageManager.GET_PERMISSIONS);
            if (info.requestedPermissions != null) {
                for (String permission : info.requestedPermissions) {
                    if (ContextCompat.checkSelfPermission(this, permission)
                            != PackageManager.PERMISSION_GRANTED ) {
                        permissionList.add(permission);
                    }
                }
            }
        }
        catch ( Exception e ) {
            e.printStackTrace();
        }
        return permissionList.toArray(new String[permissionList.size()]);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_ASK_PERMISSIONS: {
                for (int index = 0; index < permissions.length; index++) {
                    if (grantResults[index] != PackageManager.PERMISSION_GRANTED) {
                        /*
                         * If the user turned down the permission request in the past and chose the
                         * Don't ask again option in the permission request system dialog.
                         */
                        if (!ActivityCompat.shouldShowRequestPermissionRationale(this,
                                permissions[index])) {
                            Toast.makeText(this,
                                    "Required permission " + permissions[index] + " not granted. "
                                            + "Please go to settings and turn on for sample app",
                                    Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(this,
                                    "Required permission " + permissions[index] + " not granted",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                }
                /*
                 * All permission requests are being handled.Create map fragment view.Please note
                 * the HERE SDK requires all permissions defined above to operate properly.
                 */
                initMapFragment();
                break;
            }
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    private void initMapFragment() {
        /* Locate the mapFragment UI element */
        final MapFragment mapFragment = (MapFragment) getFragmentManager()
                .findFragmentById(R.id.mapfragment);

        if (mapFragment != null) {
            /* Initialize the MapFragment, results will be given via the called back. */
            mapFragment.init(new OnEngineInitListener() {
                @Override
                public void onEngineInitializationCompleted(OnEngineInitListener.Error error) {

                    if (error == Error.NONE) {
                        /*
                         * If no error returned from map fragment initialization, the map will be
                         * rendered on screen at this moment.Further actions on map can be provided
                         * by calling Map APIs.
                         */
                        initialize(mapFragment);
                    }
                }
            });
        }
    }

    private void initBtnSettings() {
        Button btnSettings = findViewById(R.id.btnSettings);
        btnSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnSettingsClicked();
            }
        });
    }

    private void btnSettingsClicked() {
        SettingsDialog dialog = new SettingsDialog(this, m_settingsData,
                new SettingsDialog.Listener() {
                    @Override
                    public void callback(SettingsData data) {
                        m_settingsData = data;
                        m_electronicHorizonHelper.setSettingsData(data);
                        m_electronicHorizonHelper.updateTree();
                        Toast.makeText(MainActivity.this,
                                "Changes may require a new position to receive an updated PathTree.",
                                Toast.LENGTH_LONG).show();
                    }
                });
        dialog.show();
    }

    private void initialize(MapFragment mapFragment) {
        m_settingsData = SettingsData.createDefault();
        initBtnSettings();
        m_electronicHorizonHelper = new ElectronicHorizonHelper(mapFragment.getMap(), this);
        m_electronicHorizonHelper.setSettingsData(m_settingsData);
        m_electronicHorizonHelper.start();
        m_navigationHelper = new NavigationHelper(mapFragment, this, m_electronicHorizonHelper);

    }
}
