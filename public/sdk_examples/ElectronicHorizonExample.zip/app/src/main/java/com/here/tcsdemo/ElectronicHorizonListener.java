/*
 * Copyright (c) 2011-2017 HERE Europe B.V.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.here.tcsdemo;

import com.here.android.mpa.electronic_horizon.ElectronicHorizon;
import com.here.android.mpa.electronic_horizon.Link;
import com.here.android.mpa.electronic_horizon.PathTree;
import com.here.android.mpa.electronic_horizon.Position;

/**
 * This class is listening to the electronic horizon events and forwards them to the renderer.
 */
class ElectronicHorizonListener implements ElectronicHorizon.Listener {

    private final ElectronicHorizonView m_electronicHorizonView;

    ElectronicHorizonListener(ElectronicHorizonView electronicHorizonView) {
        m_electronicHorizonView = electronicHorizonView;
    }

    @Override
    public void onNewPosition(Position position) {
        m_electronicHorizonView.updatePosition(position);
    }

    @Override
    public void onTreeReset() {
        m_electronicHorizonView.reset();
    }

    @Override
    public void onLinkAdded(PathTree path, Link link) {
        m_electronicHorizonView.addLink(path, link);
    }

    @Override
    public void onLinkRemoved(PathTree path, Link link) {
        m_electronicHorizonView.removeLink(path, link);
    }

    @Override
    public void onPathAdded(PathTree path) {
    }

    @Override
    public void onPathRemoved(PathTree path) {
        for (Link link : path.getLinks()) {
            m_electronicHorizonView.removeLink(path, link);
        }

        for (PathTree child : path.getChildren()) {
            onPathRemoved(child);
        }
    }

    @Override
    public void onChildDetached(PathTree parent, PathTree child) {
    }
}

