/*
 * Copyright (c) 2011-2017 HERE Europe B.V.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.here.tcsdemo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;

/**
 * This class is responsible for showing error dialogs.
 */
class ErrorAlertDialog {

    private final Activity m_activity;

    ErrorAlertDialog(Activity activity) {
        m_activity = activity;
    }

    void showErrorDialog(final int titleId, final int messageId) {
        m_activity.runOnUiThread(new Runnable(){
            @Override
            public void run() {
                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(m_activity);
                dialogBuilder.setTitle(titleId);
                dialogBuilder.setMessage(messageId);
                dialogBuilder.setCancelable(false);
                dialogBuilder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                dialogBuilder.create().show();
            }
        });
    }

}
