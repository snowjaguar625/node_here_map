/*
 * Copyright (c) 2011-2017 HERE Europe B.V.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.here.tcsdemo;

import android.annotation.SuppressLint;

import com.here.android.mpa.electronic_horizon.Link;
import com.here.android.mpa.electronic_horizon.PathTree;
import com.here.android.mpa.electronic_horizon.Position;
import com.here.android.mpa.mapping.Map;
import com.here.android.mpa.mapping.MapContainer;
import com.here.android.mpa.mapping.MapMarker;
import com.here.android.mpa.mapping.MapObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

/**
 * This class adds MapObjects to the map.
 */
abstract class AbstractImageDrawingLayer implements IDrawingLayer {

    private class LinkMarkerObject extends UseCounter {
        final MapMarker m_mapMarker;

        LinkMarkerObject(MapMarker mapMarker) {
            m_mapMarker = mapMarker;
        }

        MapObject getMapMarker() {
            return m_mapMarker;
        }
    }

    private final MapContainer m_imageContainer;
    final HashMap<Link, LinkDataObject> m_links;
    final HashMap<PathTree, ArrayList<Link>> m_paths;
    private final HashMap<Long, LinkMarkerObject> m_drawableLinks;
    private final HashSet<PathTree> m_changedPaths;
    private final Map m_map;

    @SuppressLint("UseSparseArrays")
    AbstractImageDrawingLayer(Map map, HashMap<Link, LinkDataObject> links) {
        m_map = map;
        m_imageContainer = new MapContainer();
        map.addMapObject(m_imageContainer);
        m_links = links;
        m_paths = new HashMap<>();
        m_drawableLinks = new HashMap<>();
        m_changedPaths = new HashSet<>();
    }

    abstract void processPath(PathTree path);
    abstract MapMarker getMapMarker(LinkDataObject linkDataObject);

    @Override
    public void updatePosition(Position position) {
        for (PathTree path : m_changedPaths) {
            processPath(path);
        }
        m_changedPaths.clear();
    }

    @Override
    public void addPathTree(PathTree path) {
        m_changedPaths.add(path);
    }

    @Override
    public void removeLink(PathTree path, Link link) {
        Long linkId = link.getId();
        LinkMarkerObject linkMarker = m_drawableLinks.get(linkId);
        if (linkMarker != null) {
            ArrayList<Link> links = m_paths.get(path);
            if (links != null && links.contains(link)) {
                links.remove(link);
                linkMarker.decrement();
                if (linkMarker.getUseCount() == 0) {
                    m_imageContainer.removeMapObject(linkMarker.getMapMarker());
                    m_drawableLinks.remove(linkId);
                }
                if (links.isEmpty()) {
                    m_paths.remove(path);
                    m_changedPaths.remove(path);
                } else {
                    m_changedPaths.add(path);
                }
            }
        }
    }

    void addImageToRenderingContainer(PathTree path, Link link, LinkDataObject linkDataObject) {
        Long linkId = link.getId();
        LinkMarkerObject drawableLink = m_drawableLinks.get(linkId);
        if (drawableLink == null) {
            // Map marker is centered between link start and end coordinates
            MapMarker mapMarker = getMapMarker(linkDataObject);
            m_imageContainer.addMapObject(mapMarker);
            drawableLink = new LinkMarkerObject(mapMarker);
            m_drawableLinks.put(linkId, drawableLink);
        } else {
            drawableLink.increment();
        }

        ArrayList<Link> links = m_paths.get(path);
        if (links == null) {
            links = new ArrayList<>();
            m_paths.put(path, links);
        }
        links.add(link);
    }

    @Override
    public void setVisible(boolean visible) {
        m_imageContainer.setVisible(visible);
    }

    @Override
    public void removeFromMapView() {
        clear();
        m_map.removeMapObject(m_imageContainer);
    }

    @Override
    public void clear() {
        m_imageContainer.removeAllMapObjects();
        m_paths.clear();
        m_drawableLinks.clear();
        m_changedPaths.clear();
    }

}
