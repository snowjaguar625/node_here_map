/*
 * Copyright (c) 2011-2017 HERE Europe B.V.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.here.tcsdemo;

import java.util.Collections;
import java.util.List;

/**
 * This class stores the properties that are used to configure the application.
 */
class SettingsData {
    private final int m_trailingDistance;
    private final List<Integer> m_lookAheadDistances;
    private final boolean m_visualizeTree;
    private final boolean m_visualizeSpeedLimits;
    private final boolean m_visualizeTunnels;

    static SettingsData createDefault() {
        return new SettingsData(100, Collections.singletonList(1000), true, true, false);
    }

    SettingsData(int trailingDistance, List<Integer> lookAheadDistances,
                 boolean visualizeTree, boolean visualizeSpeedLimits, boolean visualizeTunnels) {
        m_trailingDistance = trailingDistance;
        m_lookAheadDistances = lookAheadDistances;
        m_visualizeTree = visualizeTree;
        m_visualizeSpeedLimits = visualizeSpeedLimits;
        m_visualizeTunnels = visualizeTunnels;
    }

    int getTrailingDistance() {
        return m_trailingDistance;
    }

    boolean isTreeVisible() {
        return m_visualizeTree;
    }

    boolean isSpeedLimitsVisible() {
        return m_visualizeSpeedLimits;
    }

    boolean isTunnelsVisible() {
        return m_visualizeTunnels;
    }

    List<Integer> getLookAheadDistances() {
        return m_lookAheadDistances;
    }
}
