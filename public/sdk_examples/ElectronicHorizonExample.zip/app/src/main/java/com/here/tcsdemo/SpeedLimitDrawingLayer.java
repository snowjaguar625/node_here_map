/*
 * Copyright (c) 2011-2017 HERE Europe B.V.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.here.tcsdemo;

import android.app.Activity;

import com.here.android.mpa.electronic_horizon.Link;
import com.here.android.mpa.electronic_horizon.PathTree;
import com.here.android.mpa.mapping.Map;
import com.here.android.mpa.mapping.MapMarker;

import java.util.HashMap;

/**
 * This class draws the speed limits on the map.
 */
class SpeedLimitDrawingLayer extends AbstractImageDrawingLayer {

    private final MapMarkerFactory m_mapMarkerFactory;

    SpeedLimitDrawingLayer(Map map, Activity activity, HashMap<Link, LinkDataObject> links) {
        super(map, links);
        m_mapMarkerFactory = new MapMarkerFactory(activity);
    }

    @Override
    void processPath(PathTree path) {
        int previousSpeedLimit = 0;
        for (Link link : path.getLinks()) {
            LinkDataObject obj = m_links.get(link);
            if (obj != null) {
                // Speed limit is valid for the entire Link
                double speedLimitMetersPerSecond = obj.getLinkInformation().getSpeedLimitMetersPerSecond();
                int speedLimit = (int)Math.round(speedLimitMetersPerSecond * 3.6);
                if (speedLimit != previousSpeedLimit) {
                    boolean isAlreadyAdded = m_paths.containsKey(path) &&
                            m_paths.get(path).contains(link);
                    if (!isAlreadyAdded) {
                        addImageToRenderingContainer(path, link, obj);
                    }
                }
                previousSpeedLimit = speedLimit;
            } else {
                break;
            }
        }
    }

    @Override
    MapMarker getMapMarker(LinkDataObject linkDataObject) {
        return m_mapMarkerFactory.createSpeedLimit(linkDataObject);
    }
}
