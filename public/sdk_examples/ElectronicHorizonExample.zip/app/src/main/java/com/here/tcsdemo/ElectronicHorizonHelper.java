/*
 * Copyright (c) 2011-2017 HERE Europe B.V.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.here.tcsdemo;

import android.app.Activity;

import com.here.android.mpa.electronic_horizon.ElectronicHorizon;
import com.here.android.mpa.mapping.Map;
import com.here.android.mpa.routing.Route;

import java.util.List;

/**
 * This class encapsulates the properties and functionality of the electronic horizon.
 */
class ElectronicHorizonHelper {

    private final ElectronicHorizonView m_electronicHorizonView;
    private final ElectronicHorizonThread m_electronicHorizonThread;

    ElectronicHorizonHelper(Map map, Activity activity) {
        ElectronicHorizon electronicHorizon = new ElectronicHorizon();
        m_electronicHorizonThread = new ElectronicHorizonThread(electronicHorizon);
        m_electronicHorizonView = new ElectronicHorizonView(map, activity,
                electronicHorizon.getMapAccessor());
        ElectronicHorizonListener listener = new ElectronicHorizonListener(m_electronicHorizonView);
        electronicHorizon.setListener(listener);
    }

    void setSettingsData(SettingsData settingsData) {
        List<Integer> lookAheadDistances = settingsData.getLookAheadDistances();
        int[] lookAheadDistancesCm = new int[lookAheadDistances.size()];
        for (int i = 0; i < lookAheadDistances.size(); ++i) {
            lookAheadDistancesCm[i] = lookAheadDistances.get(i) * 100;
        }
        int trailingDistanceCm = settingsData.getTrailingDistance() * 100;
        m_electronicHorizonThread.setHorizonSettings(lookAheadDistancesCm, trailingDistanceCm);
        m_electronicHorizonView.setTreeVisible(settingsData.isTreeVisible());
        m_electronicHorizonView.setSpeedLimitsVisible(settingsData.isSpeedLimitsVisible());
        m_electronicHorizonView.setTunnelsVisible(settingsData.isTunnelsVisible());
    }

    void updateTree() {
        m_electronicHorizonThread.updatePosition();
    }

    void setRoute(Route route) {
        m_electronicHorizonThread.setRoute(route);
        m_electronicHorizonThread.updatePosition();
    }

    void start() {
        m_electronicHorizonThread.start();
    }

    void stop() {
        m_electronicHorizonThread.stop();
        m_electronicHorizonView.removeFromMapView();
    }

}
