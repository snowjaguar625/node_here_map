/*
 * Copyright (c) 2011-2017 HERE Europe B.V.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.here.tcsdemo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * This class shows the settings dialog with editable properties.
 * It is used to configure the application.
 */
class SettingsDialog {

    private final Activity m_activity;
    private final SettingsData m_settingsData;
    private final Listener m_listener;

    private void showToast(int resId) {
        Toast.makeText(m_activity, resId, Toast.LENGTH_SHORT).show();
    }

    interface Listener {
        void callback(SettingsData data);
    }

    SettingsDialog(Activity activity, SettingsData data, Listener listener) {
        m_activity = activity;
        m_settingsData = data;
        m_listener = listener;
    }

    private void initializeDialog(View dialogView) {
        setCheckBoxState(dialogView, R.id.visualizeTree, m_settingsData.isTreeVisible());
        setCheckBoxState(dialogView, R.id.visualizeSpeedLimits, m_settingsData.isSpeedLimitsVisible());
        setCheckBoxState(dialogView, R.id.visualizeTunnels, m_settingsData.isTunnelsVisible());
        setEditTextValue(dialogView, R.id.trailingDistance, m_settingsData.getTrailingDistance());

        List<Integer> lookAheadDistances = m_settingsData.getLookAheadDistances();
        setEditTextValue(dialogView, R.id.mainPath, lookAheadDistances.get(0));

        if (lookAheadDistances.size() > 1) {
            setEditTextValue(dialogView, R.id.firstLevelSubPath, lookAheadDistances.get(1));
        }

        if (lookAheadDistances.size() > 2) {
            setEditTextValue(dialogView, R.id.secondLevelSubPath, lookAheadDistances.get(2));
        }
    }

    void show() {
        final View dialogView = LayoutInflater.from(m_activity).inflate(R.layout.dialog_settings, null);
        initializeDialog(dialogView);

        m_activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                DialogInterface.OnClickListener positiveButtonListener =
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int ignore) {
                                onClickCallback(dialogView);
                            }
                        };
                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(m_activity);
                dialogBuilder.setView(dialogView);
                dialogBuilder.setTitle(R.string.dialog_settings_title);
                dialogBuilder.setPositiveButton(R.string.apply, positiveButtonListener);
                dialogBuilder.create().show();
            }
        });
    }

    private void onClickCallback(View dialogView) {
        String trailingDistanceStr = getEditTextValue(dialogView, R.id.trailingDistance);
        if (isNumberInvalid(trailingDistanceStr)) {
            showToast(R.string.invalid_trailing_distance_error);
            show();
            return;
        }

        ArrayList<Integer> lookAheadDistances = new ArrayList<>();
        String mainPathStr = getEditTextValue(dialogView, R.id.mainPath);
        if (isNumberInvalid(mainPathStr)) {
            showToast(R.string.invalid_look_ahead_distance_main_path_error);
            show();
            return;
        }
        lookAheadDistances.add(Integer.parseInt(mainPathStr));

        String firstLevelSubPathStr = getEditTextValue(dialogView, R.id.firstLevelSubPath);
        String secondLevelSubPathStr = getEditTextValue(dialogView, R.id.secondLevelSubPath);

        if (!firstLevelSubPathStr.isEmpty() || !secondLevelSubPathStr.isEmpty()) {
            if (isNumberInvalid(firstLevelSubPathStr)) {
                showToast(R.string.invalid_look_ahead_distance_first_level_sub_path_error);
                show();
                return;
            } else if (!secondLevelSubPathStr.isEmpty() && isNumberInvalid(secondLevelSubPathStr)) {
                showToast(R.string.invalid_look_ahead_distance_second_level_sub_path_error);
                show();
                return;
            }
        }

        if (!isNumberInvalid(firstLevelSubPathStr)) {
            lookAheadDistances.add(Integer.parseInt(firstLevelSubPathStr));
        }

        if (!isNumberInvalid(secondLevelSubPathStr)) {
            lookAheadDistances.add(Integer.parseInt(secondLevelSubPathStr));
        }

        int trailingDistance = Integer.parseInt(trailingDistanceStr);
        boolean visualizeTree = getCheckBoxState(dialogView, R.id.visualizeTree);
        boolean visualizeSpeedLimit = getCheckBoxState(dialogView, R.id.visualizeSpeedLimits);
        boolean visualizeTunnels = getCheckBoxState(dialogView, R.id.visualizeTunnels);

        m_listener.callback(new SettingsData(trailingDistance,
                lookAheadDistances, visualizeTree, visualizeSpeedLimit, visualizeTunnels));
    }

    private boolean isNumberInvalid(String numberStr) {
        return numberStr.isEmpty() || Integer.parseInt(numberStr) == 0;
    }

    private void setCheckBoxState(View dialogView, int id, boolean checked) {
        CheckBox checkBox = dialogView.findViewById(id);
        checkBox.setChecked(checked);
    }

    private boolean getCheckBoxState(View dialogView, int id) {
        CheckBox checkBox = dialogView.findViewById(id);
        return checkBox.isChecked();
    }

    private void setEditTextValue(View dialogView, int id, int value) {
        EditText editText = dialogView.findViewById(id);
        editText.setText(String.valueOf(value));
    }

    private String getEditTextValue(View dialogView, int id) {
        EditText editText = dialogView.findViewById(id);
        return editText.getText().toString();
    }
}
