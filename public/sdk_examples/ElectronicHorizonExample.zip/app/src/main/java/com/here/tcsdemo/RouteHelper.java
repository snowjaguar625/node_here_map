/*
 * Copyright (c) 2011-2017 HERE Europe B.V.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.here.tcsdemo;

import com.here.android.mpa.common.GeoBoundingBox;
import com.here.android.mpa.common.GeoCoordinate;
import com.here.android.mpa.mapping.Map;
import com.here.android.mpa.mapping.MapRoute;
import com.here.android.mpa.routing.CoreRouter;
import com.here.android.mpa.routing.Route;
import com.here.android.mpa.routing.RouteOptions;
import com.here.android.mpa.routing.RoutePlan;
import com.here.android.mpa.routing.RouteResult;
import com.here.android.mpa.routing.RouteWaypoint;
import com.here.android.mpa.routing.Router;
import com.here.android.mpa.routing.RoutingError;

import java.util.List;

/**
 * This class is responsible for calculating and rendering the route.
 */
class RouteHelper {

    interface Listener {
        void calculated(boolean success, Route route);
    }

    private final ErrorAlertDialog m_errorAlertDialog;
    private final Map m_map;
    private final Listener m_listener;
    private MapRoute m_mapRoute;
    private Route m_route;

    RouteHelper(ErrorAlertDialog errorAlertDialog, Map map, Listener listener) {
        m_errorAlertDialog = errorAlertDialog;
        m_map = map;
        m_listener = listener;
        m_mapRoute = null;
        m_route = null;
    }

    private void showErrorDialog(final int messageId) {
        m_errorAlertDialog.showErrorDialog(R.string.routing_error_title, messageId);
        m_listener.calculated(false, null);
    }

    void calculateRoute(GeoCoordinate startCoordinate, GeoCoordinate endCoordinate) {
        if (endCoordinate == null) {
            showErrorDialog(R.string.invalid_destination_location_error);
            return;
        }

        if (startCoordinate == null) {
            showErrorDialog(R.string.invalid_current_location_error);
            return;
        }

        CoreRouter coreRouter = new CoreRouter();
        RoutePlan routePlan = createRoutePlan(startCoordinate, endCoordinate);

        coreRouter.calculateRoute(routePlan, new Router.Listener<List<RouteResult>, RoutingError>() {

            @Override
            public void onProgress(int i) {
            }

            @Override
            public void onCalculateRouteFinished(List<RouteResult> routeResults,
                                                 RoutingError routingError) {
                if (routingError == RoutingError.NONE) {
                    if (routeResults.get(0).getRoute() != null) {
                        Route route = routeResults.get(0).getRoute();
                        m_listener.calculated(true, route);
                    } else {
                        showErrorDialog(R.string.invalid_route_error);
                    }
                } else {
                    showErrorDialog(R.string.route_calculation_error);
                }
            }
        });
    }

    private RoutePlan createRoutePlan(GeoCoordinate startCoordinate, GeoCoordinate endCoordinate) {
        RoutePlan routePlan = new RoutePlan();
        RouteOptions routeOptions = new RouteOptions();
        routeOptions.setTransportMode(RouteOptions.TransportMode.CAR);
        routeOptions.setRouteType(RouteOptions.Type.FASTEST);
        routeOptions.setRouteCount(1);
        routePlan.setRouteOptions(routeOptions);

        RouteWaypoint start = new RouteWaypoint(startCoordinate);
        RouteWaypoint destination = new RouteWaypoint(endCoordinate);
        routePlan.addWaypoint(start);
        routePlan.addWaypoint(destination);
        return routePlan;
    }

    void addMapRoute(Route route) {
        removeMapRoute();
        m_route = route;
        m_mapRoute = new MapRoute(route);
        /* Show the maneuver number on top of the route */
        m_mapRoute.setManeuverNumberVisible(true);
        m_map.addMapObject(m_mapRoute);
        GeoBoundingBox geoBoundingBox = route.getBoundingBox();
        m_map.zoomTo(geoBoundingBox, Map.Animation.NONE, Map.MOVE_PRESERVE_ORIENTATION);
    }

    Route getRoute() {
        return m_route;
    }

    private void removeMapRoute() {
        if (m_mapRoute != null) {
            m_map.removeMapObject(m_mapRoute);
            m_mapRoute = null;
            m_route = null;
        }
    }

}
