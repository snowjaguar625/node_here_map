/*
 * Copyright (c) 2011-2017 HERE Europe B.V.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.here.tcsdemo;

import com.here.android.mpa.common.GeoPosition;
import com.here.android.mpa.common.PositioningManager;
import com.here.android.mpa.common.PositioningManager.OnPositionChangedListener;
import com.here.android.mpa.common.PositioningManager.LocationMethod;
import com.here.android.mpa.common.PositioningManager.LocationStatus;
import com.here.android.mpa.electronic_horizon.ElectronicHorizon;
import com.here.android.mpa.routing.Route;

import java.lang.ref.WeakReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * This class allows to run electronic horizon on the separate thread.
 * It encapsulates the multithreading logic and updates electronic horizon
 * when the user location is updated.
 */
class ElectronicHorizonThread {

    private final ElectronicHorizon m_electronicHorizon;
    private boolean m_stopped;
    private boolean m_available;
    private final Lock m_lock;
    private final Condition m_condVar;
    private final PositioningManager m_positioningManager;
    private Thread m_mainThread;
    private Thread m_updateThread;

    private final OnPositionChangedListener m_onPositionChangedListener =
            new OnPositionChangedListener() {
                @Override
                public void onPositionUpdated(LocationMethod method, GeoPosition position,
                                              boolean isMapMatched) {
                    updatePosition();
                }

                @Override
                public void onPositionFixChanged(LocationMethod method, LocationStatus status) {
                }
            };

    ElectronicHorizonThread(ElectronicHorizon electronicHorizon) {
        m_electronicHorizon = electronicHorizon;
        m_stopped = false;
        m_available = false;
        m_mainThread = null;
        m_updateThread = null;
        m_lock = new ReentrantLock();
        m_condVar = m_lock.newCondition();
        m_positioningManager = PositioningManager.getInstance();
    }

    void start() {
        m_positioningManager.addListener(new WeakReference<>(m_onPositionChangedListener));
        m_mainThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (!m_stopped) {
                    m_lock.lock();
                    try {
                        while (!m_available && !m_stopped) {
                            try {
                                m_condVar.await();
                            } catch (InterruptedException e) {
                                /* Interruption exception was thrown. */
                            }
                        }
                        m_available = false;
                        if (!m_stopped) {
                            m_electronicHorizon.update();
                        }
                    } finally {
                        m_lock.unlock();
                    }
                }
            }
        });
        m_mainThread.start();
    }

    void stop() {
        m_lock.lock();
        try {
            m_stopped = true;
            m_positioningManager.removeListener(m_onPositionChangedListener);
            m_condVar.signal();
        } finally {
            m_lock.unlock();
        }
        try {
            m_mainThread.join();
        } catch (InterruptedException e) {
            /* Interruption exception was thrown. */
        }
    }

    void updatePosition() {
        if (m_updateThread == null) {
            m_updateThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    m_lock.lock();
                    try {
                        m_available = true;
                        m_condVar.signal();
                    } finally {
                        m_lock.unlock();
                        m_updateThread = null;
                    }
                }
            });
            m_updateThread.start();
        }
    }

    void setRoute(Route route) {
        m_lock.lock();
        try {
            m_electronicHorizon.setRoute(route);
        } finally {
            m_lock.unlock();
        }
    }

    void setHorizonSettings(int[] lookAheadDistances, int trailingDistance) {
        m_lock.lock();
        try {
            m_electronicHorizon.setLookAheadDistancesInCentimeters(lookAheadDistances);
            m_electronicHorizon.setTrailingDistanceInCentimeters(trailingDistance);
        } finally {
            m_lock.unlock();
        }
    }
}