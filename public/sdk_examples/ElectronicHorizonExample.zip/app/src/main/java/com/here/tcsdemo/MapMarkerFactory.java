/*
 * Copyright (c) 2011-2017 HERE Europe B.V.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.here.tcsdemo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.here.android.mpa.common.GeoCoordinate;
import com.here.android.mpa.common.Image;
import com.here.android.mpa.mapping.MapMarker;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

/**
 * This class creates map markers for the links.
 */
class MapMarkerFactory {

    @SuppressLint("UseSparseArrays")
    private final HashMap<Integer, Image> m_speedLimitCachedImages = new HashMap<>();
    private final Activity m_activity;

    MapMarkerFactory(Activity activity) {
        m_activity = activity;
    }

    private Image getImage(int speedLimit) {

        if (m_speedLimitCachedImages.containsKey(speedLimit)) {
            return m_speedLimitCachedImages.get(speedLimit);
        }

        View speedLimitView = LayoutInflater.from(m_activity.getApplicationContext()).inflate(
                R.layout.speed_limit_view, null);
        TextView label = speedLimitView.findViewById(R.id.limit_label);
        label.setText(String.format("%s", speedLimit));

        speedLimitView.setDrawingCacheEnabled(true);
        speedLimitView.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        speedLimitView.layout(0, 0, speedLimitView.getMeasuredWidth(),
                speedLimitView.getMeasuredHeight());
        speedLimitView.buildDrawingCache(true);
        Bitmap bitmap = Bitmap.createBitmap(speedLimitView.getDrawingCache());
        speedLimitView.setDrawingCacheEnabled(false);

        Image image = new Image();
        image.setBitmap(bitmap);

        m_speedLimitCachedImages.put(speedLimit, image);

        return image;
    }

    private GeoCoordinate getLinkCenter(LinkDataObject linkDataObject) {
        List<GeoCoordinate> geoCoordinates = linkDataObject.getPolyline().getAllPoints();
        GeoCoordinate firstCoordinate = geoCoordinates.get(0);
        GeoCoordinate lastCoordinate = geoCoordinates.get(geoCoordinates.size() - 1);
        double centerLat = (firstCoordinate.getLatitude() + lastCoordinate.getLatitude()) / 2.0;
        double centerLong = (firstCoordinate.getLongitude() + lastCoordinate.getLongitude()) / 2.0;
        return new GeoCoordinate(centerLat, centerLong);
    }

    /**
     * This function creates an image of speed limit and wraps it into map marker.
     * In addition it also caches the images so they might be reused.
     */
    MapMarker createSpeedLimit(LinkDataObject linkDataObject) {
        GeoCoordinate centerCoordinate = getLinkCenter(linkDataObject);

        //Convert m/s into km/h
        double speedLimitMs = linkDataObject.getLinkInformation().getSpeedLimitMetersPerSecond();
        int speedLimit = (int)Math.round(speedLimitMs * 3.6);
        Image image = getImage(speedLimit);

        return new MapMarker(centerCoordinate, image);
    }

    /**
     * This function creates map marker for tunnel.
     */
    MapMarker createTunnel(LinkDataObject linkDataObject) {
        GeoCoordinate centerCoordinate = getLinkCenter(linkDataObject);

        Image image = new Image();
        try {
            image.setImageResource(R.drawable.tunnel);
        } catch (IOException ignore) {
            /* Failed to load the image */
        }

        return new MapMarker(centerCoordinate, image);

    }
}
