/*
 * Copyright (c) 2011-2017 HERE Europe B.V.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.here.tcsdemo;

import android.app.Activity;
import android.util.Pair;

import com.here.android.mpa.common.GeoPolyline;
import com.here.android.mpa.electronic_horizon.DataNotReadyException;
import com.here.android.mpa.electronic_horizon.Link;
import com.here.android.mpa.electronic_horizon.LinkInformation;
import com.here.android.mpa.electronic_horizon.MapAccessor;
import com.here.android.mpa.electronic_horizon.PathTree;
import com.here.android.mpa.electronic_horizon.Position;
import com.here.android.mpa.mapping.Map;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class encapsulates the drawing layers.
 * It allows to load and cache the link data for the drawing layers.
 */
class ElectronicHorizonView {

    private final MapAccessor m_mapAccessor;
    private final HashMap<Link, LinkDataObject> m_links;
    private final ArrayList<Pair<PathTree, Link>> m_linksWaitingForData;
    private final ArrayList<IDrawingLayer> m_drawingLayers;
    private final TreeDrawingLayer m_treeDrawingLayer;
    private final SpeedLimitDrawingLayer m_speedLimitDrawingLayer;
    private final TunnelDrawingLayer m_tunnelDrawingLayer;

    ElectronicHorizonView(Map map, Activity activity, MapAccessor mapAccessor) {
        m_mapAccessor = mapAccessor;
        m_links = new HashMap<>();
        m_linksWaitingForData = new ArrayList<>();
        m_drawingLayers = new ArrayList<>();
        m_treeDrawingLayer = new TreeDrawingLayer(map, m_links);
        m_speedLimitDrawingLayer = new SpeedLimitDrawingLayer(map, activity, m_links);
        m_tunnelDrawingLayer = new TunnelDrawingLayer(map, activity, m_links);
        m_drawingLayers.add(m_treeDrawingLayer);
        m_drawingLayers.add(m_speedLimitDrawingLayer);
        m_drawingLayers.add(m_tunnelDrawingLayer);
    }

    void updatePosition(Position position) {
        for (IDrawingLayer layer : m_drawingLayers) {
            layer.updatePosition(position);
        }
    }

    void addLink(PathTree path, Link link) {
        processWaitingLinks();

        /* Ignore paths that are already part of the parent */
        PathTree parentPath = path.getParent();
        if (parentPath != null) {
            Link firstLink = path.getLinks().iterator().next();
            for (Link tempLink : path.getParent().getLinks()) {
                if (tempLink.getId() == firstLink.getId()) {
                    return;
                }
            }
        }

        LinkDataObject value = m_links.get(link);
        if (value != null) {
            value.increment();
            for (IDrawingLayer layer : m_drawingLayers) {
                layer.addPathTree(path);
            }
        } else {
            try {
                GeoPolyline polyline = m_mapAccessor.getLinkPolyline(link);
                LinkInformation linkInformation = m_mapAccessor.getLinkInformation(link);
                if (polyline != null && linkInformation != null) {
                    value = new LinkDataObject(polyline, linkInformation);
                    m_links.put(link, value);
                    for (IDrawingLayer layer : m_drawingLayers) {
                        layer.addPathTree(path);
                    }
                }
            } catch (DataNotReadyException e) {
                /* Failed to load the data. Map data is not ready. Will try to load next time. */
                m_linksWaitingForData.add(new Pair<>(path, link));
            }
        }
    }

    /* Fetch and cache the information for links */
    private void processWaitingLinks() {
        ArrayList<Pair<PathTree, Link>> removable = new ArrayList<>();
        for (Pair<PathTree, Link> pair : m_linksWaitingForData) {
            try {
                Link link = pair.second;
                GeoPolyline polyline = m_mapAccessor.getLinkPolyline(link);
                LinkInformation linkInformation = m_mapAccessor.getLinkInformation(link);
                if (polyline != null) {
                    LinkDataObject value = new LinkDataObject(polyline, linkInformation);
                    m_links.put(link, value);
                    for (IDrawingLayer layer : m_drawingLayers) {
                        layer.addPathTree(pair.first);
                    }
                    removable.add(pair);
                }
            } catch (DataNotReadyException ignore) {
            }
        }
        m_linksWaitingForData.removeAll(removable);
    }

    void removeLink(PathTree path, Link link) {
        if (m_linksWaitingForData.contains(new Pair<>(path, link))) {
            m_linksWaitingForData.remove(new Pair<>(path, link));
        } else {
            LinkDataObject value = m_links.get(link);
            if (value != null) {
                for (IDrawingLayer layer : m_drawingLayers) {
                    layer.removeLink(path, link);
                }
                if (value.getUseCount() == 1) {
                    m_links.remove(link);
                } else {
                    value.decrement();
                }
            }
        }
    }

    void setTreeVisible(boolean visible) {
        m_treeDrawingLayer.setVisible(visible);
    }

    void setSpeedLimitsVisible(boolean visible) {
        m_speedLimitDrawingLayer.setVisible(visible);
    }

    void setTunnelsVisible(boolean visible) {
        m_tunnelDrawingLayer.setVisible(visible);
    }

    void removeFromMapView() {
        for (IDrawingLayer layer : m_drawingLayers) {
            layer.removeFromMapView();
        }
        reset();
    }

    void reset() {
        for (IDrawingLayer layer : m_drawingLayers) {
            layer.clear();
        }
        m_linksWaitingForData.clear();
        m_links.clear();
    }
}
