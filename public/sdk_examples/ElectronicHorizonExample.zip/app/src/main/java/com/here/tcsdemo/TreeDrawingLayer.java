/*
 * Copyright (c) 2011-2017 HERE Europe B.V.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.here.tcsdemo;

import android.annotation.SuppressLint;
import android.graphics.Color;

import com.here.android.mpa.common.GeoPolyline;
import com.here.android.mpa.electronic_horizon.Link;
import com.here.android.mpa.electronic_horizon.PathTree;
import com.here.android.mpa.electronic_horizon.Position;
import com.here.android.mpa.mapping.Map;
import com.here.android.mpa.mapping.MapContainer;
import com.here.android.mpa.mapping.MapPolyline;

import java.util.HashMap;
import java.util.HashSet;

/**
 * This class draws the paths on the map. The main path is drawn in red,
 * the first level side-paths in green and the second level side-paths in yellow color.
 */
class TreeDrawingLayer implements IDrawingLayer {

    private static final int m_currentPathColor = Color.RED;
    private static final int m_firstLevelSidePathColor = Color.GREEN;
    private static final int m_secondLevelSidePathColor = Color.YELLOW;
    private static final int m_unknownPathColor = Color.GRAY;
    private final MapContainer m_renderingContainer;
    private final Map m_map;
    private final HashMap<Link, LinkDataObject> m_links;
    private final HashMap<PathTree, MapPolyline> m_drawablePaths;
    private final HashSet<PathTree> m_changedPaths;

    @SuppressLint("UseSparseArrays")
    TreeDrawingLayer(Map map, HashMap<Link, LinkDataObject> links) {
        m_map = map;
        m_links = links;
        m_renderingContainer = new MapContainer();
        m_renderingContainer.setVisible(true);
        m_map.addMapObject(m_renderingContainer);
        m_drawablePaths = new HashMap<>();
        m_changedPaths = new HashSet<>();
    }

    @Override
    public void addPathTree(PathTree path) {
        m_changedPaths.add(path);
    }

    @Override
    public void removeLink(PathTree path, Link link) {
        if (m_drawablePaths.containsKey(path)) {
            m_changedPaths.add(path);
        }
    }

    @Override
    public void setVisible(boolean visible) {
        m_renderingContainer.setVisible(visible);
    }

    @Override
    public void removeFromMapView() {
        clear();
        m_map.removeMapObject(m_renderingContainer);
    }

    @Override
    public void clear() {
        m_renderingContainer.removeAllMapObjects();
        m_drawablePaths.clear();
        m_changedPaths.clear();
    }

    @Override
    public void updatePosition(Position position) {
        updatePath();
        PathTree currentPath = position.getPathTree();
        if (currentPath != null) {
            colorPaths(currentPath);
        }
    }

    private void updatePath() {
        for (PathTree path : m_changedPaths) {
            MapPolyline oldMapPolyline = m_drawablePaths.get(path);
            if (oldMapPolyline != null) {
                m_drawablePaths.remove(path);
            }
            GeoPolyline polyline = null;
            for (Link link : path.getLinks()) {
                LinkDataObject obj = m_links.get(link);
                if (obj != null) {
                    polyline = addPolyline(polyline, obj.getPolyline());
                } else {
                    break;
                }
            }
            if (polyline != null) {
                addPolylineToRenderingContainer(path, polyline);
            }
            if (oldMapPolyline != null) {
                m_renderingContainer.removeMapObject(oldMapPolyline);
            }
        }
        m_changedPaths.clear();
    }

    private void addPolylineToRenderingContainer(PathTree path, GeoPolyline polyline) {
        MapPolyline mapPolyline = new MapPolyline(polyline);
        mapPolyline.setLineColor(m_unknownPathColor);
        mapPolyline.setLineWidth(10);
        mapPolyline.setZIndex(0);
        m_renderingContainer.addMapObject(mapPolyline);
        m_drawablePaths.put(path, mapPolyline);
    }

    private GeoPolyline addPolyline(GeoPolyline polyline, GeoPolyline polylineToAdd) {
        if (polyline == null) {
            polyline = new GeoPolyline();
        }
        polyline.add(polylineToAdd.getAllPoints());
        return polyline;
    }

    private void colorPath(PathTree path, int zIndex, int color) {
        MapPolyline mapPolyline = m_drawablePaths.get(path);
        if (mapPolyline != null) {
            mapPolyline.setZIndex(zIndex);
            mapPolyline.setLineColor(color);
        }
    }

    private void colorPaths(PathTree currentPath) {
        colorPath(currentPath, 3, m_currentPathColor);
        for (PathTree firstLevelSubPath : currentPath.getChildren()) {
            colorPath(firstLevelSubPath, 2, m_firstLevelSidePathColor);
            for (PathTree secondLevelSubPath : firstLevelSubPath.getChildren()) {
                colorPath(secondLevelSubPath, 1, m_secondLevelSidePathColor);
            }
        }
    }

}
