/*
 * Copyright (c) 2011-2017 HERE Global B.V. and its affiliate(s).
 * All rights reserved.
 * The use of this software is conditional upon having a separate agreement
 * with a HERE company for the use or utilization of this software. In the
 * absence of such agreement, the use of the software is not allowed.
 */
package com.here.android.tutorial;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.Menu;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;


import com.here.android.mpa.common.GeoCoordinate;
import com.here.android.mpa.common.OnEngineInitListener;
import com.here.android.mpa.mapping.Map;
import com.here.android.mpa.mapping.MapFragment;
import com.here.android.mpa.mapping.MapRoute;
import com.here.android.mpa.mapping.MapTrafficLayer;
import com.here.android.mpa.routing.CoreRouter;
import com.here.android.mpa.routing.DynamicPenalty;
import com.here.android.mpa.routing.Route;
import com.here.android.mpa.routing.RouteOptions;
import com.here.android.mpa.routing.RoutePlan;
import com.here.android.mpa.routing.RouteResult;
import com.here.android.mpa.routing.RouteWaypoint;
import com.here.android.mpa.routing.Router;
import com.here.android.mpa.routing.RoutingError;
import com.here.msdkui.routing.CustomRecyclerView;
import com.here.msdkui.routing.ManeuverDescriptionList;
import com.here.msdkui.routing.RouteDescriptionItem;
import com.here.msdkui.routing.RouteDescriptionList;
import com.here.msdkui.routing.RouteTypeOptionsPanel;
import com.here.msdkui.routing.TabView;
import com.here.msdkui.routing.ToolkitButton;
import com.here.msdkui.routing.TrafficOptionsPanel;
import com.here.msdkui.routing.TransportModePanel;
import com.here.msdkui.routing.TruckOptionsPanel;
import com.here.msdkui.routing.WaypointEntry;
import com.here.msdkui.routing.WaypointList;


public class BasicMapActivity extends Activity {

    // permissions request code
    private final static int REQUEST_CODE_ASK_PERMISSIONS = 1;

    /**
     * Permissions that need to be explicitly requested from end user.
     */
    private static final String[] REQUIRED_SDK_PERMISSIONS = new String[]{
            Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.WRITE_EXTERNAL_STORAGE};

    // map embedded in the map fragment
    private Map map = null;

    // map fragment embedded in this activity
    private MapFragment mapFragment = null;

    private WaypointList wpl;

    private TransportModePanel tp;

    private CoreRouter cr;
    private RoutePlan rp;
    private RouteOptions ro;
    private RouteTypeOptionsPanel myRouteOptionsPanel;
    private MapRoute mapRoute = null;

    private RouteDescriptionList routeDescpList;
    private ManeuverDescriptionList manDescpList;

    private LinearLayout determinateBar;
    private LinearLayout optionPanel;
    private ProgressBar progressBar;

    private TrafficOptionsPanel trafficOption;
    private TruckOptionsPanel truckOption;

    private ToolkitButton options;

    // add two coordinates for routing
    private GeoCoordinate berlin;
    private GeoCoordinate potsdam ;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        checkPermissions();
    }

    private void initialize() {
        setContentView(R.layout.activity_main);


        initMap();

        // options button
        options = (ToolkitButton) findViewById(R.id.options);
        options.setType(ToolkitButton.Type.OPTIONS);
        options.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ro != null && optionPanel != null && optionPanel.getVisibility() == View.GONE) {

                    optionPanel.setVisibility(View.VISIBLE);
                    if (tp.getSelected() == 1) { // truck
                        truckOption.setVisibility(View.VISIBLE);
                    } else {
                        truckOption.setVisibility(View.GONE);
                    }
                    if (manDescpList != null) {
                        manDescpList.setVisibility(View.GONE);
                    }

                    if (routeDescpList != null) {
                        routeDescpList.setVisibility(View.GONE);
                    }
                    mapFragment.getView().setVisibility(View.GONE);
                } else {
                    optionPanel.setVisibility(View.GONE);
                    mapFragment.getView().setVisibility(View.VISIBLE);
                    calculateRoute();
                }

            }
        });

        // waypoints list component
        wpl = (WaypointList) findViewById(R.id.waypointlist);

        // truck option component
        truckOption = (TruckOptionsPanel) findViewById(R.id.truckOption);


        // option panel
        optionPanel = (LinearLayout) findViewById(R.id.optionPanel);

        // routing panel
        myRouteOptionsPanel = (RouteTypeOptionsPanel) findViewById(R.id.routeTypePanel);

        myRouteOptionsPanel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mapFragment.getView().setVisibility(View.VISIBLE);
                optionPanel.setVisibility(View.GONE);

            }
        });

        //traffic option
        trafficOption = (TrafficOptionsPanel) findViewById(R.id.trafficOption);

         // Transport mode component
        tp = (TransportModePanel) findViewById(R.id.transportmode);
        tp.setOnSelectedListener(new TransportModePanel.OnSelectedListener() {
            @Override
            public void onSelected(int i, TabView tabView) {
                switch (i) {
                    case 0:
                        map.setMapScheme(Map.Scheme.CARNAV_DAY);
                        break;
                    case 1:
                        map.setMapScheme(Map.Scheme.TRUCK_DAY);
                        break;
                    case 2:
                        map.setMapScheme(Map.Scheme.PEDESTRIAN_DAY);
                        break;
                    default:
                        map.setMapScheme(Map.Scheme.NORMAL_DAY);
                        break;

                }
                // calculate route
                calculateRoute();
            }

            @Override
            public void onUnselected(int i, TabView tabView) {

            }

            @Override
            public void onReselected(int i, TabView tabView) {

            }
        });

        // maneuver description component
        manDescpList = (ManeuverDescriptionList) findViewById(R.id.maneuverList);

        //progress bar
        determinateBar = (LinearLayout) findViewById(R.id.determinateBar);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

    }


    // init the map
    private void initMap() {
        // Search for the map fragment to finish setup by calling init().
        mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.mapfragment);
        mapFragment.init(new OnEngineInitListener() {
            @Override
            public void onEngineInitializationCompleted(OnEngineInitListener.Error error) {
                if (error == OnEngineInitListener.Error.NONE) {
                    // retrieve a reference of the map from the map fragment
                    map = mapFragment.getMap();
                    // Set the map center to the Vancouver region (no animation)
                    map.setCenter(new GeoCoordinate(52.53852, 13.42506, 0.0),
                            Map.Animation.NONE);
                    // Set the zoom level to the average between min and max
                    map.setZoomLevel((map.getMaxZoomLevel() + map.getMinZoomLevel()) / 2);

                    // router init
                    cr = new CoreRouter();

                    ro = new RouteOptions();
                    truckOption.setRouteOptions(ro);
                    myRouteOptionsPanel.setRouteOptions(ro);

                    DynamicPenalty dp=new DynamicPenalty();
                    dp.setTrafficPenaltyMode(Route.TrafficPenaltyMode.DISABLED);
                    trafficOption.setDynamicPenalty(dp);

                    berlin = new GeoCoordinate(52.53852, 13.42506);
                    potsdam = new GeoCoordinate(52.40008, 13.05892);


                    wpl.addEntry(new WaypointEntry("Berlin").setRouteWaypoint((new RouteWaypoint(berlin))));
                    wpl.addEntry(new WaypointEntry("Postdam").setRouteWaypoint((new RouteWaypoint(potsdam))));
                    // switch to map if clicked on way point component
                    wpl.setListener(new WaypointList.Listener() {

                        public void onEntryClicked(int var1, WaypointEntry var2) {
                            if (manDescpList != null) {
                                manDescpList.setVisibility(View.GONE);
                            }

                            if (routeDescpList != null) {
                                routeDescpList.setVisibility(View.GONE);
                            }

                            mapFragment.getView().setVisibility(View.VISIBLE);
                        }


                        public void onEntryAdded(int var1, WaypointEntry var2) {

                        }

                        public void onEntryUpdated(int var1, WaypointEntry var2) {

                        }

                        public void onEntryRemoved(int var1, WaypointEntry var2) {

                        }

                        public void onEntryDragged(int var1, int var2) {

                        }


                    });

                } else {
                    System.out.println("ERROR: Cannot initialize Map Fragment");
                }
            }
        });
    }


    private void clear() {
        if (manDescpList != null) {
            manDescpList.setVisibility(View.GONE);
        }

        if (routeDescpList != null) {
            routeDescpList.setVisibility(View.GONE);
        }

        if (mapRoute != null) {
            map.removeMapObject(mapRoute);  // remove old one
        }

        if (optionPanel != null) {
            optionPanel.setVisibility(View.GONE);

        }


        mapFragment.getView().setVisibility(View.VISIBLE);

    }


    // Calculate route
    private void calculateRoute() {

        clear();
        rp = new RoutePlan();
        rp.addWaypoint(new RouteWaypoint(berlin));
        rp.addWaypoint(new RouteWaypoint(potsdam));
        if (tp.getSelected() == 1) { // truck
            ro = truckOption.getRouteOptions();
        }

        ro.setTransportMode(tp.getSelectedTransportMode());
        rp.setRouteOptions(ro);


        if (trafficOption.getDynamicPenalty()!=null){
           if(   trafficOption.getDynamicPenalty().getTrafficPenaltyMode().equals(Route.TrafficPenaltyMode.DISABLED)) {
                map.setTrafficInfoVisible(false);

            } else {
                map.setTrafficInfoVisible(true);
                MapTrafficLayer mtl = map.getMapTrafficLayer();
                mtl.setEnabled(MapTrafficLayer.RenderLayer.FLOW, true);
                mtl.setEnabled(MapTrafficLayer.RenderLayer.ONROUTE, true);
                mtl.setEnabled(MapTrafficLayer.RenderLayer.INCIDENT, true);
               routeDescpList.setTrafficEnabled(true);
            }

            cr.setDynamicPenalty(trafficOption.getDynamicPenalty());
        }

        cr.calculateRoute(rp, new Router.Listener<List<RouteResult>, RoutingError>() {
            @Override
            public void onProgress(int i) {
                if (progressBar != null) {
                    progressBar.setProgress(i);
                }
            }

            @Override
            public void onCalculateRouteFinished(List<RouteResult> routeResults, RoutingError routingError) {
                determinateBar.setVisibility(View.GONE);
                if (routingError == RoutingError.NONE) {
                    mapFragment.getView().setVisibility(View.GONE);


                    routeDescpList = (RouteDescriptionList) findViewById(R.id.routeDescription);
                    routeDescpList.setRoutesResult(routeResults);
                    routeDescpList.setVisibility(View.VISIBLE);

                    routeDescpList.setOnItemClickedListener(new CustomRecyclerView.OnItemClickedListener() {
                        @Override
                        public void onItemClicked(int i, View view) {
                            // retieve the route to be added to the map
                            RouteDescriptionItem item = (RouteDescriptionItem) view;
                            mapRoute = new MapRoute(item.getRoute());
                            map.addMapObject(mapRoute);

                            // hide route details and show the map
                            routeDescpList.setVisibility(View.GONE);
                            mapFragment.getView().setVisibility(View.VISIBLE);

                            // Zoom and scale to the new route
                            map.zoomTo(item.getRoute().getBoundingBox(), Map.Animation.BOW, 1);

                        }

                        @Override
                        public void onItemLongClicked(int i, View view) {
                            // show maneuver details on long click
                            RouteDescriptionItem item = (RouteDescriptionItem) view;
                            routeDescpList.setVisibility(View.GONE);
                            manDescpList.setRoute(item.getRoute());
                            manDescpList.setVisibility(View.VISIBLE);

                        }
                    });
                } else {
                    System.out.println(routingError.toString());
                }
            }
        });


        determinateBar.setVisibility(View.VISIBLE);



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }


    /**
     * Checks the dynamically controlled permissions and requests missing permissions from end user.
     */
    protected void checkPermissions() {
        final List<String> missingPermissions = new ArrayList<String>();
        // check all required dynamic permissions
        for (final String permission : REQUIRED_SDK_PERMISSIONS) {
            final int result = ContextCompat.checkSelfPermission(this, permission);
            if (result != PackageManager.PERMISSION_GRANTED) {
                missingPermissions.add(permission);
            }
        }
        if (!missingPermissions.isEmpty()) {
            // request all missing permissions
            final String[] permissions = missingPermissions
                    .toArray(new String[missingPermissions.size()]);
            ActivityCompat.requestPermissions(this, permissions, REQUEST_CODE_ASK_PERMISSIONS);
        } else {
            final int[] grantResults = new int[REQUIRED_SDK_PERMISSIONS.length];
            Arrays.fill(grantResults, PackageManager.PERMISSION_GRANTED);
            onRequestPermissionsResult(REQUEST_CODE_ASK_PERMISSIONS, REQUIRED_SDK_PERMISSIONS,
                    grantResults);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[],
                                           @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_ASK_PERMISSIONS:
                for (int index = permissions.length - 1; index >= 0; --index) {
                    if (grantResults[index] != PackageManager.PERMISSION_GRANTED) {
                        // exit the app if one permission is not granted
                        Toast.makeText(this, "Required permission '" + permissions[index]
                                + "' not granted, exiting", Toast.LENGTH_LONG).show();
                        finish();
                        return;
                    }
                }
                // all permissions were granted
                initialize();
                break;
        }
    }
}
