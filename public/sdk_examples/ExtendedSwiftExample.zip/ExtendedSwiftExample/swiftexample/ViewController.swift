import UIKit

class ViewController: UIViewController, NMANavigationManagerDelegate, NMAMapDataPrefetcherListener {

    
    // Simluation mode !! Set to false for real positioning.
    let SIMULATION_MODE = true;  // helper for activating guidance simulation - switch to false if you want to use real positioning

    @IBOutlet weak var mapView: NMAMapView!
    @IBOutlet weak var guidanceBar: UIStackView!
    
    var firstUpdate = true;
    
    var mapRoute: NMAMapRoute!;
    var cr: NMACoreRouter!;
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        // decide if navigation should be able to run in the background
        NMANavigationManager.sharedInstance().backgroundNavigationEnabled = true;
        NMANavigationManager.sharedInstance().backgroundNavigationStartEnabled = true;
        
        // start positioning
        NMAPositioningManager.sharedInstance().startPositioning();
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // To ensure position updates in background are not disabled
        CLLocationManager.init().requestAlwaysAuthorization()
        
        // set some basic values for mapview
        mapView.set(geoCenter: NMAGeoCoordinates(latitude:41.350949, longitude:-74.18209), animation: NMAMapAnimation.bow);
        mapView.zoomLevel = 18.0;
        mapView.tilt = 0.0;

        // show the HERe copyright top-middle instead of bottom, since we have the naviagtions buttons on the buttom in this example
        mapView.copyrightLogoPosition = NMALayoutPosition.topCenter;

        // show 3D Landmarks / 3D POI models for famous POIs
        mapView.landmarksVisible = true;
        
        // show extruded buildings on closer zoomlevels
        mapView.extrudedBuildingsVisible = true;

        // disable all embedded POIs on the map to reduce clutter
        mapView.setVisibility(false, for: NMAMapPoiCategory.all );
        
        // activate traffic - needs plan with traffic included
        mapView.isTrafficVisible = true;

        // display speed camera icons on the map
        mapView.safetySpotsVisible = true;
        
        // activate positioning indicator
        mapView.positionIndicator.isVisible = true;
        mapView.positionIndicator.isAccuracyIndicatorVisible = true;
    
        // link mapview instance with guidance for visual updates (otherwise tracking and automatic map updates while guidance won't work)
        NMANavigationManager.sharedInstance().map = mapView;
        
        
        // start positioning
        NMAPositioningManager.sharedInstance().startPositioning();

        // listen for position updates
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.positionDidUpdate), name: NSNotification.Name.NMAPositioningManagerDidUpdatePosition, object: NMAPositioningManager.sharedInstance());
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.didLosePosition), name: NSNotification.Name.NMAPositioningManagerDidLosePosition, object: NMAPositioningManager.sharedInstance());
        
        // init Map data pre-fetcher
        
        NMAMapDataPrefetcher.sharedInstance().addListener(self)
    }
    
    func prefetcher(_ prefetcher: NMAMapDataPrefetcher, didUpdateProgress progress: Float, forRequestId requestId: Int) {
         print("Prefecthing data before starting navigation \(progress) %" );
    }
    
    func prefetcher(_ prefetcher: NMAMapDataPrefetcher, didUpdateStatus status: NMAPrefetchStatus, forRequestId requestId: Int) {
        
        if status == NMAPrefetchStatus.success {
             print("Prefecthing Completed" );
             self.guidanceBar.isHidden = false
        }else{
             print("ERROR: Prefecthing Failed" );
        }
       
    }
   
    
    func positionDidUpdate(){        
        if(firstUpdate){
            let p = NMAPositioningManager.sharedInstance().currentPosition;
            //print("Position update received to \(p)");
           
            if p != nil {
                print("Position update received");
                firstUpdate = false;
                mapView.set(geoCenter: (p?.coordinates)!, animation: NMAMapAnimation.bow);
                calculateRoute();
            }
            
        }
    }

    func didLosePosition(){
        print("Position lost");
    }

    
    override func viewWillDisappear(_ animated: Bool){
        NMAPositioningManager.sharedInstance().stopPositioning();
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.NMAPositioningManagerDidUpdatePosition, object: NMAPositioningManager.sharedInstance());
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.NMAPositioningManagerDidLosePosition, object: NMAPositioningManager.sharedInstance());
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func onStartGuidanceButtonClicked(_ sender: AnyObject) {
        if mapRoute != nil && NMAPositioningManager.sharedInstance().currentPosition != nil {
            
            // tilt map to 45 degree for getting 2.5D feeling
            mapView.tilt = 45.0;
            
            // set drive specific map scheme
            mapView.mapScheme = NMAMapSchemeCarNavigationDay;
            
            // focus and zoom to start position
            mapView.set(geoCenter: (NMAPositioningManager.sharedInstance().currentPosition?.coordinates!)!, zoomLevel: 19.0, animation: NMAMapAnimation.bow);
            
            // !! Simulation mode only !!
            // In this case we will use the route as our source and update our mocked position every second !!!!
            if( SIMULATION_MODE ) {
                    
                // stop positioning as we will update the data source
                NMAPositioningManager.sharedInstance().stopPositioning();
                
                let r = mapRoute.route;
                let routeSource:NMARoutePositionSource = NMARoutePositionSource(route: r);
                    
                // configure the route
                routeSource.updateInterval = 1.0; // every second which is the default
                routeSource.stationary = false; // move along which is the default
                routeSource.movementSpeed = 10.0;  // m/s
                    
                // set the route as our source
                NMAPositioningManager.sharedInstance().dataSource = routeSource;
                    
                // re-start the positioning with our new source setup
                NMAPositioningManager.sharedInstance().startPositioning();
            }
            
            // set the delegate and catch the callbacks in this class
            NMANavigationManager.sharedInstance().delegate = self;
            
            // follow your position during guidance
            NMANavigationManager.sharedInstance().mapTrackingEnabled = true;
            
            // heads up orientation while guidance
            NMANavigationManager.sharedInstance().mapTrackingOrientation = NMAMapTrackingOrientation.dynamic;
            
            // zoom to proper zoomlevel during guidance automatically controlled by SDK
            NMANavigationManager.sharedInstance().mapTrackingAutoZoomEnabled = false;

            // disableextruded buildings, since it's often disturbing during navigation and occludes information
            mapView.extrudedBuildingsVisible = false;
            
            // decide if navigation should be able to run in the background
            NMANavigationManager.sharedInstance().backgroundNavigationEnabled = true;
            NMANavigationManager.sharedInstance().backgroundNavigationStartEnabled = true;
            
            
            // start guidance
            NMANavigationManager.sharedInstance().startTurnByTurnNavigation(mapRoute.route);
        }
    }
    
     // implement from the navigationmanager delegate
    func navigationManagerDidReachDestination(_ navigationManager: NMANavigationManager!) {
        onStopGuidanceButtonClicked(self);  // in this example, we assume the same behaviour when reached destination than clicked on stop button
    }
    
    // implement from the navigationmanager delegate
    @objc(navigationManager:hasCurrentManeuver:nextManeuver:) func navigationManager(_ navigationManager: NMANavigationManager!, didUpdateManeuvers maneuver: NMAManeuver!, _ nextManeuver: NMAManeuver!) {
        print("Next maneuver:\n Action: \(nextManeuver.action.rawValue) - Turn: \(nextManeuver.turn.rawValue) - In \(nextManeuver.distanceToNextManeuver) m - from \(nextManeuver.roadName) onto \(nextManeuver.nextRoadName) - \(nextManeuver.nextRoadNumber)")
    }
    
    
    @IBAction func onStopGuidanceButtonClicked(_ sender: AnyObject) {

        // stop guidance
        NMANavigationManager.sharedInstance().stop();
        
        // switch back data source
        NMAPositioningManager.sharedInstance().stopPositioning();
        NMAPositioningManager.sharedInstance().dataSource = nil;
        NMAPositioningManager.sharedInstance().startPositioning();
        
        // set general map scheme
        mapView.mapScheme = NMAMapSchemeNormalDay;

        // reactivate building footprints
        mapView.extrudedBuildingsVisible = true;

        // set top view
        mapView.tilt = 0.0;
        
        // jump back to route overview
        mapView.set(boundingBox: mapRoute.route.boundingBox!, animation: NMAMapAnimation.bow);
    }
    
    
    func calculateRoute() -> Void {
        // calculate a route
        print("Calculating new route...");
        
        let start = NMAPositioningManager.sharedInstance().currentPosition;
        let p = NMAPositioningManager.sharedInstance().currentPosition;
        let end = NMAGeoCoordinates(latitude: (p?.coordinates?.latitude)!+0.2, longitude: (p?.coordinates?.longitude)!+0.2); // just take a destination nearby
        let waypoints = [start?.coordinates, end];
       
 
        // set routing options - avoid some streets explicitly
        let ro = NMARoutingOption.avoidTollRoad.rawValue | NMARoutingOption.avoidCarpool.rawValue | NMARoutingOption.avoidBoatFerry.rawValue | NMARoutingOption.avoidDirtRoad.rawValue;
         
        // setup routing mode for transport type and mode, taking routing options into account
        let rm = NMARoutingMode(routingType: NMARoutingType.shortest, transportMode: NMATransportMode.car, routingOptions: NMARoutingOption(rawValue: ro));

        //  routing penalties - in this case we want traffic aware routing
        let dp = NMADynamicPenalty();
        dp.trafficPenaltyMode = NMATrafficPenaltyMode.optimal;

        // create a instance of NMACoreRouter -- should be used for Car, Truck or Pedestrian routes.
        cr = NMACoreRouter();
        cr.dynamicPenalty = dp;
        
        print("Calculating route from \(start) to \(end)");
        
        // start route calculation
        cr.calculateRoute(withStops: waypoints, routingMode: rm, { routeResult,error in
            if ( (error == NMARoutingError.none || error == NMARoutingError.violatesOptions) && (routeResult?.routes?.count)! > 0)
            {
                if let r = routeResult?.routes![0]
                {
                    print("New route received");
                    
                    // when the route options were too restrictive for the route, we still get a route back, but with violated options
                    if error == NMARoutingError.violatesOptions {
                        // use NMARoutingViolatedOption in NMARouteResult to get the violated options
                        print("Violated \(routeResult?.violatedOptions?.count) route options");
                    }
                    
                    self.mapRoute = NMAMapRoute(r)
                    self.mapView.add(mapObject: self.mapRoute)
                    self.mapView.set(boundingBox: r.boundingBox!, animation: NMAMapAnimation.bow);
                
                    // Pre-fetching the map data around the route
                    // to ensure background navigation can continue
                    var prefetchError : NMAPrefetchRequestError = .none;
                    NMAMapDataPrefetcher.sharedInstance().fetchMapDataForRoute(r, radius: 500, error: &prefetchError)
                    
                    if prefetchError != .none {
                        print("Error : Prefetching data failed");
                    }
                    
                }
            }
            else
            {
                print("ERROR: failed calculatig route: \(error.rawValue)");
            }
        });
    }
    
}

