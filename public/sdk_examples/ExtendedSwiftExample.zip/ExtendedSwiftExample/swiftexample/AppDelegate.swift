import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    
    let appID = "7vNEpmDnoeXKkSYDG8Fo";
    let token = "XtZtjXi5PfzUQHAsJURnpA";
    let licenseKey = "gDMPViayDrL0DTmeBiwGb0p/mODazNcpV0B9I8Plv+Vt7AA7INp9mrm6ZnsstwCN7MXnSOtBrqar360gYzxxUuhF2tICa6GKcXiNY20k7w1jMr55BEdRnZoy0ILUIxTDMkLeIhmfLEunwBH3gaNFFpe1UL28i0GbrYwTXLDdr37DfOcr2J4LeyTYYQpsHp+sQ3SwtXt5bv2obbe4+FCiVn6zWFIFoz55r6zVNgc+0dZSzLNa0gGuCQw/hMkCfhl9mOp4g/xFOYS+4uZi57MlLY0TTVkDxvZ4+grELTGtsD8TX/OEW5z9GDAnVfKFb8saPgqzO953EcrGPGWIAxtWCRkrt2uDfMdGWfkBuoUgzzjEvD0/yuzs0/UfhMHPse2ePL5zs7apmEd41zsDwFGy4xYifYZh9dOvoAIuQRneC+9y0u+OyYvm8ke6JgHsYCIP8qUJthqgC49TVy3Olejw8KdQLePfjkNEFLarEIv4uTJ5E75I0ZrzjdpZ77LW9l2cQTa1UFb+SVxxAl4BycS0NJWWA4BnbFouxGV/zUlH76hvTY7r7PUQE+zqo+KH527zGrOFtTbkX3L7iwRJ96lIUKiXVvrZp1OdZha3t1rMG/vYhH4IhK+l1b9VFXzWY6KuXbm+2aptcHRzLhu7cHUYmxxXIxdAur0j1ZB9+MTIfP8=";


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        NMAApplicationContext.setAppId(appID, appCode: token, licenseKey: licenseKey);
        return true;
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        
        // This is required to ensure navigtion when app goes to background
        NMAPositioningManager.sharedInstance().dataSource?.setBackgroundUpdatesEnabled!(true);
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

