package com.here.tcsdemo;

import com.here.android.mpa.mapping.Map;
import com.here.android.mpa.mapping.MapRoute;

public interface FleetConnectivityFragmentBridge {
    void onEngineInitialized(Map map);

    Map getMap();

    JobsManager getJobsManager();

    void showJobs();

    void showJobDetails(String jobId);

    void updateJobMarker(String jobId, JobMarkerType type);

    void setActiveRoute(MapRoute route);

    void setFollowPosition(boolean follow);

    boolean isSimulationEnabled();

    void setSimulationEnabled(boolean enabled);

    boolean isTrafficEnabled();

    void setTrafficEnabled(boolean enabled);

    void setTruckRestrictionsEnabled(boolean enabled);

    boolean areTruckRestrictionsEnabled();
}
