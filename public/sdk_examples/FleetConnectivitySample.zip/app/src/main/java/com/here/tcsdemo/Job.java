package com.here.tcsdemo;

import com.here.android.mpa.common.GeoCoordinate;

import org.joda.time.DateTime;

/**
 * Job model class used by {@link JobsManager}.
 */
public class Job {
    private final String mJobId;
    private long mEtaThreshold;
    private GeoCoordinate mGeoCoordinate;
    private String mMessage;
    private DateTime mJobTime;

    public Job(String jobId) {
        mJobId = jobId;
    }

    public String getJobId() {
        return mJobId;
    }

    public long getEtaThreshold() {
        return mEtaThreshold;
    }

    public void setEtaThreshold(long etaThreshold) {
        mEtaThreshold = etaThreshold;
    }

    public GeoCoordinate getGeoCoordinate() {
        return mGeoCoordinate;
    }

    public void setGeoCoordinate(GeoCoordinate geoCoordinate) {
        mGeoCoordinate = geoCoordinate;
    }

    public String getMessage() {
        return mMessage;
    }

    public void setMessage(String message) {
        mMessage = message;
    }

    public DateTime getJobTime() {
        return mJobTime;
    }

    public void setJobTime(DateTime jobTime) {
        mJobTime = jobTime;
    }
}
