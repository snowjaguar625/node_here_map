package com.here.tcsdemo;

import com.here.android.mpa.common.GeoBoundingBox;
import com.here.android.mpa.common.GeoCoordinate;

/**
 * Simple class containing helper methods.
 */
public class Utils {
    /**
     * Expands the provided GeoBoundingBox vertically.
     *
     * @param box GeoBoundingBox instance that should be extend.
     */
    static void extendBoundingBox(GeoBoundingBox box) {
        GeoCoordinate topLeft = box.getTopLeft();
        GeoCoordinate bottomRight = box.getBottomRight();
        box.setBottomRight(new GeoCoordinate(bottomRight.getLatitude() - 1.1 * (topLeft.getLatitude() - bottomRight.getLatitude()), bottomRight.getLongitude()));
    }
}
