package com.here.tcsdemo;

/**
 * Simple enum representing MapMarker state.
 */
public enum JobMarkerType {
    /**
     * Normal marker for Job in idle state.
     */
    NORMAL,
    /**
     * Marker for job currently in focus.
     */
    ACTIVE
}
