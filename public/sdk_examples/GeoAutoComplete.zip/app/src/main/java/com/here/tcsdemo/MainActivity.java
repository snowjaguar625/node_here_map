package com.here.tcsdemo;

import android.app.ActionBar;
import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.content.Context;
import android.graphics.PointF;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;

import com.here.android.mpa.common.GeoCoordinate;
import com.here.android.mpa.common.GeoPosition;
import com.here.android.mpa.common.Image;
import com.here.android.mpa.common.OnEngineInitListener;
import com.here.android.mpa.common.PositioningManager;
import com.here.android.mpa.common.PositioningManager.LocationMethod;
import com.here.android.mpa.common.PositioningManager.LocationStatus;
import com.here.android.mpa.common.PositioningManager.OnPositionChangedListener;
import com.here.android.mpa.mapping.Map;
import com.here.android.mpa.mapping.Map.Animation;
import com.here.android.mpa.mapping.Map.Projection;
import com.here.android.mpa.mapping.MapFragment;
import com.here.android.mpa.mapping.MapMarker;
import com.here.android.mpa.search.ErrorCode;
import com.here.android.mpa.search.GeocodeRequest;
import com.here.android.mpa.search.Location;
import com.here.android.mpa.search.ResultListener;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.List;

/**
 * MainActivity - Main class
 */
public class MainActivity extends Activity {

    private static final Integer THRESHOLD = 2;
    private CustomAutoCompleteTextView mGeoAutocomplete;
    private MapFragment mMapFragment;
    private Map mMap;
    private GeocompleteAdapter mGeoAutoCompleteAdapter;
    // Position Listener
    OnPositionChangedListener mPositionListener = new OnPositionChangedListener() {

        @Override
        public void onPositionUpdated(LocationMethod method, GeoPosition position,
                                      boolean isMapMatched) {
            if (position != null) {
                mGeoAutoCompleteAdapter.setPosition(position);
            }
        }

        @Override
        public void onPositionFixChanged(LocationMethod method, LocationStatus status) {

        }
    };
    private PositioningManager mPositionManager;
    private MapMarker mMarker;
    protected ResultListener<List<Location>> m_listener = new ResultListener<List<Location>>() {
        @Override
        public void onCompleted(List<Location> data, ErrorCode error) {
            if (error == ErrorCode.NONE) {
                if (data != null && data.size() > 0) {
                    addMarker(data.get(0).getCoordinate());
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_ACTION_BAR);
        setContentView(R.layout.activity_main);
        mMapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.mapfragment);
        mMapFragment.init(new OnEngineInitListener() {

            @Override
            public void onEngineInitializationCompleted(Error error) {
                if (error == Error.NONE) {
                    mMap = mMapFragment.getMap();
                    mMap.setProjectionMode(Projection.MERCATOR);
                    mMap.getPositionIndicator().setVisible(true);
                    mPositionManager = PositioningManager.getInstance();
                    mPositionManager
                            .addListener(new WeakReference<>(mPositionListener));
                    mPositionManager.start(LocationMethod.GPS_NETWORK);
                }
            }
        });

        // UI customization
        ActionBar actionBar = getActionBar();
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);
        actionBar.setIcon(android.R.color.transparent);
        LayoutInflater inflator = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v = inflator.inflate(R.layout.action_bar, null);
        LayoutParams layoutParams = new LayoutParams(LayoutParams.MATCH_PARENT,
                LayoutParams.WRAP_CONTENT);
        actionBar.setCustomView(v, layoutParams);

        mGeoAutocomplete = (CustomAutoCompleteTextView) v.findViewById(R.id.geo_autocomplete);
        mGeoAutocomplete.setThreshold(THRESHOLD);
        mGeoAutocomplete.setLoadingIndicator((android.widget.ProgressBar) v
                .findViewById(R.id.pb_loading_indicator));

        mGeoAutoCompleteAdapter = new GeocompleteAdapter(this);
        mGeoAutocomplete.setAdapter(mGeoAutoCompleteAdapter);

        mGeoAutocomplete.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                String result = (String) adapterView.getItemAtPosition(position);
                mGeoAutocomplete.setText(result);
                GeocodeRequest req = new GeocodeRequest(result);
                req.setSearchArea(mMap.getBoundingBox());
                req.execute(m_listener);
            }
        });

        mGeoAutocomplete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!"".equals(mGeoAutocomplete.getText().toString())) {
                    GeocodeRequest req = new GeocodeRequest(mGeoAutocomplete.getText().toString());
                    req.setSearchArea(mMap.getBoundingBox());
                    req.execute(m_listener);
                }
            }
        });
    }

    /**
     * Add marker on map.
     *
     * @param geoCoordinate GeoCoordinate for marker to be added.
     */
    private void addMarker(GeoCoordinate geoCoordinate) {
        if (mMarker == null) {
            Image image = new Image();
            try {
                image.setImageResource(R.drawable.pin);
            } catch (final IOException e) {
                e.printStackTrace();
            }
            mMarker = new MapMarker(geoCoordinate, image);
            mMarker.setAnchorPoint(new PointF(image.getWidth() / 2, image.getHeight()));
            mMap.addMapObject(mMarker);
        } else {
            mMarker.setCoordinate(geoCoordinate);
        }
        mMap.setCenter(geoCoordinate, Animation.BOW);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mPositionManager != null && !mPositionManager.isActive()) {
            mPositionManager
                    .addListener(new WeakReference<>(mPositionListener));
            mPositionManager.start(LocationMethod.GPS_NETWORK);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mPositionManager != null) {
            mPositionManager.removeListener(mPositionListener);
            mPositionManager.stop();
        }
    }
}
