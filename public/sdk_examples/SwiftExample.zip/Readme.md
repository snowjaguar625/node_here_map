How to setup HERE Maps with Swift:
==================================

- Follow the basic setup for iOS described in the Objective-C useguide: https://developer.here.com/mobile-sdks/documentation/ios-hybrid-plus/topics/app-simple.html
- Beside all dependencies mentioned in the userguide (framework and tbd files), also add libc++.tbd to the project
- Importing NMAView via bridging header (https://developer.apple.com/library/ios/documentation/Swift/Conceptual/BuildingCocoaApps/MixandMatch.html)
- Use Obj-C class via Swift interoperability (https://developer.apple.com/library/ios/documentation/Swift/Conceptual/BuildingCocoaApps/index.html)

Congratulations! Now you can build and run your app.

----

Copyright (c) 2015 HERE Global B.V.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

----