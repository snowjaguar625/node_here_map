import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var mapView: NMAMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set some basic values for mapview
        mapView.setGeoCenter(NMAGeoCoordinates(latitude: 52.53084, longitude: 13.38478), with: NMAMapAnimation.bow);
        mapView.copyrightLogoPosition = NMALayoutPosition.topCenter;
        mapView.zoomLevel = 17.0;
        mapView.tilt = 45.0;
        mapView.landmarksVisible = true;
        mapView.extrudedBuildingsVisible = true;

        // activate traffic - needs plan with traffic included
        mapView.isTrafficVisible = true;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

