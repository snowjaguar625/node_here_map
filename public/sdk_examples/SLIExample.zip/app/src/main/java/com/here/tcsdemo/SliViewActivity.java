package com.here.tcsdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.here.android.mpa.common.GeoCoordinate;
import com.here.android.mpa.common.OnEngineInitListener;
import com.here.android.mpa.streetlevel.StreetLevel;
import com.here.android.mpa.streetlevel.StreetLevelFragment;
import com.here.android.mpa.streetlevel.StreetLevelModel;

public class SliViewActivity extends Activity {

    private static final String TAG = "SliViewActivity";
    private StreetLevelFragment sliFragment = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sli);
        sliFragment = (StreetLevelFragment) getFragmentManager().findFragmentById(R.id.slifragment);

        Intent intent = getIntent();
        final double lat = intent.getDoubleExtra("example.latitude", 0);
        final double lon = intent.getDoubleExtra("example.longitude", 0);
        final float orientation = intent.getFloatExtra("example.orientation", 0);

        sliFragment.init(new OnEngineInitListener() {
            @Override
            public void onEngineInitializationCompleted(Error error) {
                if (error.equals(Error.NONE)) {
                    if (sliFragment.getStreetLevelModel() != null) {
                        // Enable arrows for navigation in street level images
                        sliFragment.getStreetLevelModel().setNavigationArrowVisible(true);
                        GeoCoordinate coordinate = new GeoCoordinate(lat, lon);
                        // Get street level meta data
                        sliFragment.getStreetLevelModel().getStreetLevel(
                                coordinate, new StreetLevelModel.OnRetrievalListener() {
                            @Override
                            public void onGetStreetLevelCompleted(StreetLevel streetLevel) {
                               if (streetLevel != null) {
                                   // Render street image
                                   sliFragment.getStreetLevelModel().moveTo(
                                           streetLevel, true, orientation, 0, 0.1F);
                               }
                            }
                        });
                    }
                } else {
                    Log.e(TAG, "ERROR: Can't initialize SLI fragment because of: " + error.name());
                }
            }
        });
    }

}
