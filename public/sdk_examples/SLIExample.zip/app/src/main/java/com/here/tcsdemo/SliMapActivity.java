package com.here.tcsdemo;

import android.app.Activity;
import android.content.Intent;
import android.graphics.PointF;
import android.os.Bundle;
import android.util.Log;

import com.here.android.mpa.common.GeoCoordinate;
import com.here.android.mpa.common.OnEngineInitListener;
import com.here.android.mpa.common.ViewObject;
import com.here.android.mpa.mapping.Map;
import com.here.android.mpa.mapping.MapFragment;
import com.here.android.mpa.mapping.MapGesture;

import java.util.List;

public class SliMapActivity extends Activity {

    private static final String TAG = "SliMapActivity";
    private MapFragment fragment = null;
    private Map map = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fragment = (MapFragment) getFragmentManager().findFragmentById(R.id.mapfragment);

        fragment.init(new OnEngineInitListener() {
            @Override
            public void onEngineInitializationCompleted(Error error) {
                if (error.equals(Error.NONE)) {
                    map = fragment.getMap();
                    // Set location to San Francisco
                    map.setCenter(new GeoCoordinate(37.7865046, -122.419287), Map.Animation.NONE);
                    // Set zoom level
                    map.setZoomLevel(12);
                    // Show SLI coverage on the map
                    map.setStreetLevelCoverageVisible(true);
                    // Add listener that shows SLI by long tap on the map
                    fragment.getMapGesture().addOnGestureListener(mapGestureListener);
                } else {
                    Log.e(TAG, "ERROR: Can't initialize map fragment because of: " + error.name());
                }
            }
        });

    }

    private MapGesture.OnGestureListener mapGestureListener = new MapGesture.OnGestureListener() {

        @Override
        public void onPanStart() {}

        @Override
        public void onPanEnd() {}

        @Override
        public void onMultiFingerManipulationStart() {}

        @Override
        public void onMultiFingerManipulationEnd() {}

        @Override
        public boolean onMapObjectsSelected(List<ViewObject> list) {
            return false;
        }

        @Override
        public boolean onTapEvent(final PointF pointF) {return false;}

        @Override
        public boolean onDoubleTapEvent(PointF pointF) {
            return false;
        }

        @Override
        public void onPinchLocked() {}

        @Override
        public boolean onPinchZoomEvent(float v, PointF pointF) {
            return false;
        }

        @Override
        public void onRotateLocked() {}

        @Override
        public boolean onRotateEvent(float v) {
            return false;
        }

        @Override
        public boolean onTiltEvent(float v) {
            return false;
        }

        @Override
        public boolean onLongPressEvent(PointF pointF) {
            GeoCoordinate coordinate = map.pixelToGeo(pointF);
            Intent intent = new Intent(getApplicationContext(), SliViewActivity.class);
            intent.putExtra("example.longitude", coordinate.getLongitude());
            intent.putExtra("example.latitude", coordinate.getLatitude());
            intent.putExtra("example.orientation", map.getOrientation());
            startActivity(intent);
            return false;
        }

        @Override
        public void onLongPressRelease() {}

        @Override
        public boolean onTwoFingerTapEvent(PointF pointF) {
            return false;
        }
    };

}


