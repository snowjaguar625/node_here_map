This demo app shows a complete and fully functional flow using the HERE Mobile SDK and the HERE UI Kit.

Please see the https://github.com/heremaps/msdkui-android guide for instructions on how to build and run this app.
