#import <UIKit/UIKit.h>
#import <NMAKit/NMAKit.h>
#import "ResultObjectTableViewCell.h"
#import "SharedMemory.h"
#import "SuggestionNetworkRequest.h"
#import "SuggestionTableViewCell.h"

@protocol ResultsViewControllerDelegate;

/**
 * Demo on how to make a search view controller with Here Maps API's
 *
 * It operates in two modes: suggestion search, or normal search.
 * As the user types, a suggestion search is performed. As soon as the
 * user either selects a suggestion, or returns from searchTextField, a
 * normal discovery search is performed and results are displayed.
 * When the user finally selects an place object in the row, the View is
 * dismissed and the respective selection is shown in the map.
 */
@interface ResultsViewController : UIViewController<NMAResultListener, SuggestionNetworkRequestDelegate, 
                                                    UITextFieldDelegate,
                                                    UITableViewDataSource,
                                                    UITableViewDelegate>
{
    SharedMemory * sharedMemory;
    SuggestionNetworkRequest * suggestionNetworkRequest;
}

//properties
@property (nonatomic) NSString * searchText;
@property (nonatomic) NSArray * discoveryResults;
@property(nonatomic,strong) NSArray* placeLinks;
@property(nonatomic,strong) NMADiscoveryRequest* discoveryRequest;
@property(nonatomic,strong) NSString* queryString;
@property (strong) NSMutableArray * latestSearchResultArray; //suggestion

//UI properties
@property (weak, nonatomic) IBOutlet UITextField *searchTextField;
@property (weak, nonatomic) NMAMapView * mapView;
@property (weak, nonatomic) IBOutlet UITableView *resultsTableView;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (weak, nonatomic) IBOutlet UIButton *cancelButton;

//Delegates
@property (nonatomic, weak) id<ResultsViewControllerDelegate> delegate;

//Actions
- (IBAction)cancelTouched:(id)sender;
- (IBAction)searchTextFieldEditingChanged:(id)sender;

@end

@protocol ResultsViewControllerDelegate <NSObject>

-(void)resultsVC:(ResultsViewController*)viewController didSelectViewInMapForSearch:(NSString*)queryString;
-(void)didCancelSearch;
-(void)didCompleteForSearch:(NSString*)queryString;

@end