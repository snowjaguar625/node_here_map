#import "AppDelegate.h"
#import <NMAKit/NMAKit.h>
#import "SharedMemory.h"


@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [NMAApplicationContext setAppId:kAppID appCode:kAppCode licenseKey:kLicenseKey];

    return YES;
}

-(void)applicationDidEnterBackground:(UIApplication *)application
{
    [[NMAPositioningManager sharedPositioningManager] stopPositioning];
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    if (![[NMAPositioningManager sharedPositioningManager] isActive])
    {
        [[NMAPositioningManager sharedPositioningManager] startPositioning];
    }
}

@end
