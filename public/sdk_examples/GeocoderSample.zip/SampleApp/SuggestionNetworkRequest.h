#import <Foundation/Foundation.h>

@protocol SuggestionNetworkRequestDelegate;

/**
 * This demo class encapsulates code responsible for getting suggestions via HERE's HTTP API
 *
 * The asynchronous network code completion can provide response either block-based and/or
 * via delegate (SuggestionNetworkRequestDelegate).
 */
@interface SuggestionNetworkRequest : NSObject
{
    NSURLComponents * baseURLComponents;
    BOOL useProximity;
}

//typedefs
typedef void (^suggestionCompletionBlock)(id results, NSError *error);

//properties
@property (strong) id latestSearchResult;

//delegates
@property (nonatomic, weak) id<SuggestionNetworkRequestDelegate> delegate;

//methods
-(void)requestSuggestionsForQueryString:(NSString*) queryString;
-(void)requestSuggestionsForQueryString:(NSString *)queryString
                        completionBlock:(suggestionCompletionBlock)completionBlock;
@end

@protocol SuggestionNetworkRequestDelegate <NSObject>

-(void)didCompleteWithResults:(NSDictionary*)suggestionJSON
               forQueryString:(NSString*) queryString;

@end

