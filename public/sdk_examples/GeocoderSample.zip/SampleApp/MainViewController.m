#import "MainViewController.h"
#import <NMAKit/NMAKit.h>

#define kNavigationTilt 70

@interface MainViewController ()

@property (weak, nonatomic) IBOutlet NMAMapView *mapView;
@end

@implementation MainViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self mapViewSetup];
    
    sharedMemory = [SharedMemory sharedInstance];
    [sharedMemory setMapView: self.mapView];
    
    self.searchTextField.delegate = self;
    
    //UI setup
    [self updateSearchFieldCancelButtonVisibility];
    self.myLocationButton.layer.cornerRadius = 8;
    self.myLocationButton.clipsToBounds = YES;
    
    [self centerTouched:self];
}


-(void)mapViewSetup
{
    //set geo center
    
    if(![[NMAPositioningManager sharedPositioningManager] startPositioning])
        NSLog(@"Warning: Could not start positioning..");
    else NSLog(@"Positioning started..");
    
    [self.mapView setGeoCenter:[SharedMemory getCurrentPosition] withAnimation:NMAMapAnimationNone];
    self.mapView.copyrightLogoPosition = NMALayoutPositionBottomCenter;
    
    self.mapView.projectionType = NMAProjectionTypeGlobe;
    self.mapView.delegate = self;
    
    [self.mapView setMapScheme:NMAMapSchemeCarNavigationDay];
    
    //set zoom level
    self.mapView.zoomLevel = 13.2;
    [self.mapView setVisibility:YES forPoiCategory:NMAMapPoiCategoryAll];
    
    self.mapView.positionIndicator.visible = YES;
}

-(void)viewDidAppear:(BOOL)animated
{
    [self setNeedsStatusBarAppearanceUpdate];
    
    [self updateSearchFieldCancelButtonVisibility];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(positionUpdate)
                                                 name:NMAPositioningManagerDidUpdatePositionNotification
                                               object:[NMAPositioningManager sharedPositioningManager]];
}

-(void)viewDidDisappear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NMAPositioningManagerDidUpdatePositionNotification object:[NMAPositioningManager sharedPositioningManager]];
}

-(void)positionUpdate
{
    if (navigationRunning) {
        
        //NMAGeoCoordinates *geoCoordCenter = nil;
        CGPoint screenCenter = CGPointMake(([UIScreen mainScreen].bounds.size.width)/2, ([UIScreen mainScreen].bounds.size.height)/2);
        
        NMAGeoPosition* pos = [[NMAPositioningManager sharedPositioningManager] currentPosition];
        if (pos)
        {
            //geoCoordCenter = pos.coordinates;
            NSLog(@"received position: %@", pos.coordinates);
        }
        else
        {
            NSLog(@"using mock position");
            pos = [NMAGeoPosition geoPositionWithCoordinates:[SharedMemory getCurrentPosition] speed:0.0 course:0.0 accuracy:1.0];
        }
        [self.mapView setGeoCoordinates:pos.coordinates toPoint:screenCenter withAnimation:NMAMapAnimationRocket zoomLevel:40 orientation: pos.course tilt:kNavigationTilt];
    }
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleDefault;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self performSegueWithIdentifier:@"mainToResultsSegue" sender:self];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    //[self.searchTextField resignFirstResponder];
    
    [self performSegueWithIdentifier:@"mainToResultsSegue" sender:self];
    
    return NO;
}

#pragma mark - MapView delegates

-(void)mapViewDidBeginAnimation:(NMAMapView *)mapView
{
    NSLog(@"didBeginAnimation");
}

-(void)mapViewDidEndAnimation:(NMAMapView *)mapView
{
    NSLog(@"didEndAnimation");
}

#pragma mark - user action handling

- (IBAction)centerTouched:(id)sender
{
    [self.mapView setGeoCenter:[SharedMemory getCurrentPosition] withAnimation:NMAMapAnimationLinear];
}

- (IBAction)cancelButtonTouched:(id)sender{
    
    [self.mapView removeMapObjects: sharedMemory.mapObjects];
    [sharedMemory.mapObjects removeAllObjects];
    
    [self.searchTextField setText:@""];
    [self updateSearchFieldCancelButtonVisibility];
    self.activeResultsVC = nil;
    
}

#pragma mark - ResultsViewController delegates

-(void)didCompleteForSearch:(NSString *)queryString
{
    [self.searchTextField setText:queryString];
}

-(void)resultsVC:(ResultsViewController *)viewController didSelectViewInMapForSearch:(NSString *)queryString
{
    self.activeResultsVC = viewController;
    [self.searchTextField setText:queryString];
    [self updateSearchFieldCancelButtonVisibility];
    
    //populate map with search results
    [sharedMemory.mapObjects addObjectsFromArray:sharedMemory.searchResultObjects];
    [self.mapView addMapObjects:sharedMemory.searchResultObjects];
}

-(void)didCancelSearch
{
    [self.searchTextField setText:@""];
    [self updateSearchFieldCancelButtonVisibility];
}

-(void)updateSearchFieldCancelButtonVisibility
{
    [self.view layoutIfNeeded];
    const float animationDuration = 0.5;
    
    if ([self.searchTextField.text isEqualToString:@""]) {
        [self.cancelButton setUserInteractionEnabled:FALSE];
        [UIView animateWithDuration:animationDuration animations:^{
            self.searchTextFieldRightConstraint.constant = 30.0;
            [self.cancelButton setHidden:TRUE];
            [self.view layoutIfNeeded];
        }];
    }
    else{
        [self.cancelButton setUserInteractionEnabled:TRUE];
        [UIView animateWithDuration:animationDuration animations:^{
            self.searchTextFieldRightConstraint.constant = 60.0;
            [self.cancelButton setHidden:FALSE];
            [self.view layoutIfNeeded];
        }];
    }
}

#pragma mark - segue's handling

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([[segue identifier] isEqualToString:@"mainToResultsSegue"])
    {
        ResultsViewController *vc = [segue destinationViewController];
        vc.delegate = self;
        [vc setSearchText:_searchTextField.text];
        [vc setMapView:_mapView];
    }
}

-(void)dealloc
{
    
}
@end

