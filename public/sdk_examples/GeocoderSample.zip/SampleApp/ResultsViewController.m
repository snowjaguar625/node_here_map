#import "ResultsViewController.h"

@interface ResultsViewController ()
    @property BOOL searchModeSuggestion ;
@end

@implementation ResultsViewController

@synthesize discoveryResults;
@synthesize searchText;
@synthesize delegate;
@synthesize searchModeSuggestion;
@synthesize latestSearchResultArray;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setNeedsStatusBarAppearanceUpdate];
    
    _searchTextField.text = searchText;
    _searchTextField.delegate = self;
    _resultsTableView.delegate = self;
    _resultsTableView.dataSource = self;
    
    searchModeSuggestion = TRUE;
    
    [_searchTextField becomeFirstResponder];
    
    sharedMemory = [SharedMemory sharedInstance];
    suggestionNetworkRequest = [[SuggestionNetworkRequest alloc] init];
    suggestionNetworkRequest.delegate = self;
    
    //auto sizing cells
    self.resultsTableView.rowHeight = UITableViewAutomaticDimension;
    self.resultsTableView.estimatedRowHeight = 55.0;

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

-(void)viewDidAppear:(BOOL)animated
{
    //[_searchTextField becomeFirstResponder];
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self performSearch];
    [textField resignFirstResponder];
    return YES;
}

-(void)performSearch
{
    searchModeSuggestion = FALSE;
    
    if (self.discoveryRequest)
        [self.discoveryRequest cancel];
    
    
    //if method createSearchRequestWithLocation is called with mapView = nil, it 'silently' fails.
    //perhaps make an assert on the parameter?
    assert(self.mapView);
    self.discoveryRequest = [[NMAPlaces sharedPlaces] createSearchRequestWithLocation:self.mapView.geoCenter query:_searchTextField.text];
    self.discoveryRequest.collectionSize = 15;
    
    //initiate search
    NSError* error = [self.discoveryRequest startWithListener:self];
    if (error.code != NMARequestErrorNone)
    {
        NSLog(@"discovery request error %@", error);
        self.discoveryRequest = nil;
    }
    else
    {
        NSLog(@"search initiated..");
        [self.activityIndicator startAnimating];
        [self.cancelButton setHidden:YES];
    }
}

-(void)request:(NMARequest *)request didCompleteWithData:(id)data error:(NSError *)error
{
    [self.activityIndicator stopAnimating];
    [self.cancelButton setHidden:NO];

    [sharedMemory.searchResultObjects removeAllObjects];
    
    NSLog(@"parse data %@ from request %@", data, request);
    if (error.code != NMARequestErrorNone)
    {
        NSLog(@"Discovery Request error %@", error);
        return;
    }
    if (![data isKindOfClass:[NMADiscoveryPage class]])
    {
        NSLog(@"Unhandled type: %@", data);
        return;
    }
    
    NMADiscoveryPage * page = (NMADiscoveryPage*)data;
    self.discoveryResults = page.discoveryResults;
    
    //determine smallest containing rect for all places
    double latitudeNorth = -DBL_MAX, latitudeSouth = DBL_MAX;
    double longitudeWest = DBL_MAX, longitudeEast = -DBL_MAX;
    
    //generate map markers from place link
    for (id elem in page.discoveryResults)
    {
        if ([elem isKindOfClass:[NMAPlaceLink class]])
        {
            NMAPlaceLink* place = (NMAPlaceLink*)elem;
            
            //determine minimum containing map rect
            if (place.position.latitude > latitudeNorth)
                latitudeNorth = place.position.latitude;
            if (place.position.latitude < latitudeSouth)
                latitudeSouth = place.position.latitude;
            if (place.position.longitude > longitudeEast)
                longitudeEast = place.position.longitude;
            if (place.position.longitude < longitudeWest)
                longitudeWest = place.position.longitude;
            
            //place a default marker on the map
            NMAImage* mapImage = [NMAImage imageWithUIImage:[UIImage imageNamed:@"PlaceDefault.png"]];
            NMAMapMarker *mapMarker = [NMAMapMarker mapMarkerWithGeoCoordinates:place.position icon:mapImage];
            mapMarker.anchorOffset = CGPointMake(0, -mapImage.size.height/2.0f);
            
            [sharedMemory.searchResultObjects addObject:mapMarker];
            //[self.mapView addMapObject:mapMarker]; //remove this line
            NSLog(@"marker added at (%f,%f)", place.position.latitude, place.position.longitude);
        }
    }
    
    //recenter map to the bounding box
    double offsetLat = 0.001, offsetLng = 0.002;
    NMAGeoCoordinates* topLeft = [NMAGeoCoordinates geoCoordinatesWithLatitude:latitudeNorth+offsetLat longitude:longitudeWest-offsetLng];
    NMAGeoCoordinates* bottomRight = [NMAGeoCoordinates geoCoordinatesWithLatitude:latitudeSouth-offsetLat longitude:longitudeEast+offsetLng];
    NMAGeoBoundingBox* visibleBox = [NMAGeoBoundingBox geoBoundingBoxWithTopLeft:topLeft bottomRight:bottomRight];
    [self.mapView setBoundingBox:visibleBox withAnimation:NMAMapAnimationBow];
    
    [_resultsTableView reloadData];
    
}

- (IBAction)cancelTouched:(id)sender {
    
    //first press clears the field, second closes window
    if (![self.searchTextField.text isEqualToString:@""]) {
        [self.searchTextField setText:@""];
        return;
    }
    
    [self.delegate didCancelSearch];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)searchTextFieldEditingChanged:(id)sender
{
    searchModeSuggestion = TRUE;
    
    [suggestionNetworkRequest requestSuggestionsForQueryString: self.searchTextField.text];
}

#pragma mark - Suggestion Request Delegates

-(void)didCompleteWithResults:(id)suggestionJSON forQueryString:(NSString *)queryString
{
    NSLog(@"didCompleteWithResults: %@", suggestionJSON);
    
    //ignore if input text field has already changed by user
    if (![queryString isEqualToString:self.searchTextField.text] || !searchModeSuggestion) {
        return;
    }
    
    latestSearchResultArray = nil;
    latestSearchResultArray = [NSMutableArray array];
    if ([suggestionJSON isKindOfClass:[NSDictionary class]]) {
        
        NSDictionary * resultsDict = [((NSDictionary*) suggestionJSON) valueForKey:@"suggestions"];
        
        for (id thisObject in resultsDict) {
            if ([thisObject isKindOfClass:[NSDictionary class]]) {
                //uncomment below to see other available suggestion fields
                //NSLog(@"%@", thisObject);
                NSString * labelString = (NSString*)[thisObject valueForKey:@"label"];
                [latestSearchResultArray addObject:labelString];
            }
        };
    }
    //reload table with new suggestions
    [self.resultsTableView reloadData];
}

#pragma mark - UITableView Delegates

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (searchModeSuggestion) {
        return [latestSearchResultArray count];
    }
    
    if(!self.discoveryResults) return 0;
    
    if([self.discoveryResults count] == 0) return 0;
    
    return [self.discoveryResults count] + 1;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //handle suggestions results
    if (searchModeSuggestion) {
        SuggestionTableViewCell * resultCell = [tableView dequeueReusableCellWithIdentifier:@"suggestionResultCellIdentifier"];

        [resultCell.suggestionLabel setText: [latestSearchResultArray objectAtIndex:indexPath.row]];
        return resultCell;
    }
    
    //handle search results
    if (indexPath.row == 0) {
        //Show all results in map button
        UITableViewCell * resultCell = [tableView dequeueReusableCellWithIdentifier:@"viewInMapIdentifier"];
        if(!resultCell)
            resultCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                                          reuseIdentifier:@"viewInMapIdentifier"];
        return resultCell;
    }
    
    int currentItem = (int)indexPath.row - 1; //consider fixed row above
    
    ResultObjectTableViewCell * resultCell = [tableView dequeueReusableCellWithIdentifier:@"resultObjectCellIdentifier"];
    if(!resultCell)
    {
        resultCell = [[ResultObjectTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                                      reuseIdentifier:@"resultObjectCellIdentifier"];
    }
    
    resultCell.tag = currentItem;
    
    [resultCell.ratingLabel setText:@"No ratings"];
    
    NMALink * nmaLink = [discoveryResults objectAtIndex:currentItem];
    
    if([nmaLink isKindOfClass:[NMADiscoveryLink class]])
    {
        [resultCell.typeLabel setText:[[NSString alloc] initWithFormat:@"%@", nmaLink.name]];
    }
    else if([nmaLink isKindOfClass:[NMAPlaceLink class]])
    {
        NMAPlaceLink * placeLink = (NMAPlaceLink*)nmaLink;
        __weak typeof(ResultObjectTableViewCell) *  weakCell = resultCell;
        
        [resultCell.typeLabel setText:[[NSString alloc] initWithFormat:@"%@", placeLink.category.name]];
        [resultCell.distanceLabel setText:[[NSString alloc] initWithFormat:@"%1.1f Km", (placeLink.distance / 1000.0)]];
        [resultCell.cellImage setImage:[UIImage imageNamed:@"media-no-image"]];
        [[placeLink detailsRequest] startWithBlock:^(NMARequest *request, id data, NSError *error) {
            if(error)
            {
                NSLog(@"ERROR: %@", error.description);
            }
            if ( ( [request isKindOfClass:[NMADiscoveryRequest class]])  &&
                ( error.code == NMARequestErrorNone ) )
            {
                NSLog(@"this should not happen? ");
            }
            else  if ( ( [request isKindOfClass:[NMAPlaceRequest class]]) &&
                      ( error.code == NMARequestErrorNone ) )
            {
                // Access to additional details about a place of interest.
                
                NMAPlace* place = (NMAPlace*)data;
                
                NSArray * collectionArray = [place.images mediaContents];
                BOOL imageFound = false;
                for (NMAMedia * thisMedia in collectionArray) {
                    NSLog(@"thisMedia.type: %lu", (unsigned long)thisMedia.type);
                    if(thisMedia.type == NMAMediaTypeImage)
                    {
                        //just use first image we find..
                        if (imageFound){continue;}
                        imageFound = true;
                        NMAMediaImage * theImage = (NMAMediaImage*)thisMedia;
                        
                        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                        dispatch_async(queue, ^(void) {
                            //consider using some caching mechanism to avoid re-downloading images..
                            NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:theImage.imageSource]];
                            UIImage* image = [[UIImage alloc] initWithData:imageData];
                            if (image) {
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    if(weakCell)
                                    {
                                        if (weakCell.tag == currentItem) {
                                            [weakCell.cellImage setImage: image];
                                            [weakCell setNeedsLayout];
                                        }
                                    }
                                });
                            }
                        });
                    }
                    else if(thisMedia.type == NMAMediaTypeRating)
                    {
                        NSLog(@"Found a rating..");
                        NMAMediaRating * thisRating = (NMAMediaRating*) thisMedia;
                        if(weakCell)
                        {
                            [weakCell.ratingLabel setText:[[NSString alloc] initWithFormat:@"%f", thisRating.average]];
                        }
                    }
                }
                if(!imageFound)
                {
                    //[resultCell.cellImage setImage: nil];
                }
                
                dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                dispatch_async(queue, ^(void) {
                    //consider using some caching mechanism to avoid re-downloading images..
                    NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:place.iconUrl]];
                    UIImage* image = [[UIImage alloc] initWithData:imageData];
                    if (image) {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            if(weakCell)
                            {
                                if (resultCell.tag == currentItem) {
                                    [resultCell.smallImage setImage: image];
                                    [resultCell setNeedsLayout];
                                }
                            }
                        });
                    }
                });
                
            } else {
                ;}
        }];
    }
    else NSLog(@"%@ object not supported yet..", nmaLink);
    
    [resultCell.itemNameLabel setText:nmaLink.name];
    
    return resultCell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //handle suggestion selection
    if (searchModeSuggestion) {
        searchModeSuggestion = FALSE;
        [self.searchTextField setText: [latestSearchResultArray objectAtIndex:indexPath.row]];
        [self performSearch];
        return;
    }
    
    //clear map
    [self.mapView removeMapObjects:sharedMemory.mapObjects];
    [sharedMemory.mapObjects removeAllObjects];
    
    if (indexPath.row == 0) {
        //selected show results in map
        [self.delegate resultsVC:self didSelectViewInMapForSearch:self.searchTextField.text];
        [self dismissViewControllerAnimated:YES completion:nil];
        return;
    }
    
    int currentItem = (int)indexPath.row - 1; //consider fixed row above
    
    NSLog(@"indexPath.row : %ldl", (long)indexPath.row);
    
    //update search bar
    NMAPlaceLink * nmaLink = [discoveryResults objectAtIndex:currentItem];
    assert([nmaLink isKindOfClass:[NMAPlaceLink class]]);
    [self.searchTextField setText:[[NSString alloc] initWithFormat:@"%@", nmaLink.name]];
    
    //move object to mapObjects array
    NMAMapMarker * selectedMarker = [sharedMemory.searchResultObjects objectAtIndex:currentItem];
    
    [sharedMemory.mapObjects addObject:selectedMarker];
    [sharedMemory.searchResultObjects removeObject:selectedMarker];
    
    //add the respective object to the mapView
    [self.mapView addMapObject:selectedMarker];
    
    //
    [self.activityIndicator stopAnimating];
    [self.cancelButton setHidden:NO];
    
    [self.delegate didCompleteForSearch:self.searchTextField.text];
    [self dismissViewControllerAnimated:YES completion:nil];
    
    
}


@end
