#import "SuggestionNetworkRequest.h"
//utility class
#import "SharedMemory.h"

#define kServerHost @"autocomplete.geocoder.api.here.com"
#define kServerAPIPath @"/6.2/suggest.json"
#define kMaxSuggestionResults @"10"
#define kRequestTimeout 400

#define kMinimumNumberOfCharactersForSuggestion 3

@implementation SuggestionNetworkRequest

@synthesize latestSearchResult;

- (id)init {
    if (self = [super init]) {
        //Setup
        baseURLComponents = [[NSURLComponents alloc] init];
        [baseURLComponents setScheme:@"http"];
        [baseURLComponents setHost:kServerHost];
        [baseURLComponents setPath:kServerAPIPath];
        
        // TODO: ENTER YOUR CREDENTIALS FOR GEOCODING API HERE!
        NSURLQueryItem * appID = [NSURLQueryItem queryItemWithName:@"app_id" value:kAppID];
        NSURLQueryItem * appCode = [NSURLQueryItem queryItemWithName:@"app_code" value:kAppCode];
        
        //Optional API parameters example (see API documentation for all parameters available)
        NSURLQueryItem * maxResults = [NSURLQueryItem queryItemWithName:@"maxresults" value:kMaxSuggestionResults];
        
        //Change flag 'useProximity' below to activate/deactivate use of proximity parameter
        useProximity = TRUE;
        
        baseURLComponents.queryItems = @[ appID, appCode, maxResults ];
    }
    return self;
}

-(void)requestSuggestionsForQueryString:(NSString*) queryString
{
    [self requestSuggestionsForQueryString: queryString completionBlock:nil];
}

-(void)requestSuggestionsForQueryString:(NSString*) queryString
                        completionBlock:(suggestionCompletionBlock)completionBlock
{
    if([queryString length] < kMinimumNumberOfCharactersForSuggestion){
        return;
    }
    
    //load common configuraiton
    NSURLComponents * urlComponents = [baseURLComponents copy];

    //add query parameter to urlComponents
    NSMutableArray * queryItemsArray = [baseURLComponents.queryItems mutableCopy];
    [queryItemsArray addObject:[NSURLQueryItem queryItemWithName:@"query" value:queryString]];
    if (useProximity) {
        //The prox parameter is a spatial filter lat/lon. A single geo-coordinate pair and
        //optionally a radius (in meters) is used to define the filter criterion.
        //This may be derived from a positioning of the user’s device. E.g.: @"37.86946,-122.26811,10000".
        float latitude = [[SharedMemory getCurrentPosition] latitude];
        float longitude = [[SharedMemory getCurrentPosition] longitude];
        NSString * proximityParameter = [NSString stringWithFormat:@"%f,%f", latitude, longitude];
        [queryItemsArray addObject:[NSURLQueryItem queryItemWithName:@"prox" value:proximityParameter]];
    }
    
    [urlComponents setQueryItems:queryItemsArray];
    
    NSMutableURLRequest * serverMutableURLRequest = [NSMutableURLRequest requestWithURL: urlComponents.URL];
    
    [serverMutableURLRequest setHTTPMethod:@"GET"];
    [serverMutableURLRequest addValue:@"text/plain; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [serverMutableURLRequest addValue:@"Accept" forHTTPHeaderField:@"*/*"];
    [serverMutableURLRequest setTimeoutInterval: kRequestTimeout];

    NSLog(@"%@",serverMutableURLRequest.URL);
    
    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithRequest:serverMutableURLRequest completionHandler:
      ^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
          
          //Handle connection errors
          if (error) {
              NSLog(@"Error: %@", error);
              if (completionBlock) {
                  dispatch_async(dispatch_get_main_queue(), ^{
                      completionBlock(nil, error);
                  });
              }
              return;
          }
          
          //Handle HTTP errors
          if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
              NSInteger statusCode = [(NSHTTPURLResponse *) response statusCode];
              if (statusCode == 400) {
                  NSLog(@"Suggest API: Bad Request");
                  if (completionBlock) {
                      dispatch_async(dispatch_get_main_queue(), ^{
                          completionBlock(response, error);
                      });
                  }
                  return;
              }
              else if(statusCode == 401){
                  NSLog(@"Suggest API: Unauthorized");
                  if (completionBlock) {
                      dispatch_async(dispatch_get_main_queue(), ^{
                          completionBlock(response, error);
                      });
                  }
                  return;
              }
          }
          
          NSError *jsonError;
          
          latestSearchResult = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error: &jsonError];
          
          //call delegate if assigned
          if(!jsonError && self.delegate){
              dispatch_async(dispatch_get_main_queue(), ^{
                  [self.delegate didCompleteWithResults:latestSearchResult forQueryString:queryString];
              });
          }
          
          //call completion block if required
          if(completionBlock)
          {
              NSError * returnError;
              
              if(error){
                  returnError = error; //http error
              }
              else{
                  returnError = jsonError;
              }
              if (completionBlock) {
                  dispatch_async(dispatch_get_main_queue(), ^{
                      completionBlock(latestSearchResult, returnError);
                  });
              }
          }
          
    }] resume];
}

@end
