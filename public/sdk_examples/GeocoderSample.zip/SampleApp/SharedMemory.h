#import <Foundation/Foundation.h>
#import <NMAKit/NMAKit.h>

// TODO: ENTER YOUR APPLICATION CREDENTIALS HERE!

#define kAppID @""
#define kAppCode @""
#define kLicenseKey @""

/**
 * Singleton class with global-app states and utility methods
 */
@interface SharedMemory : NSObject
{
    //variables below are used to save/restore mapView properties
    NMAGeoCoordinates *geoCenter;
    float mapZoomLevel;
    float mapTilt;
    float orientation;
}

@property(nonatomic,strong) NSMutableArray* mapObjects;
@property(nonatomic,strong) NSMutableArray* searchResultObjects;
@property (weak, nonatomic) NMAMapView * mapView;

+ (id)sharedInstance;
+(NMAGeoCoordinates*)getCurrentPosition;

-(void)saveCurrentMapViewState;
-(void)loadPreviousMapViewState;

@end
