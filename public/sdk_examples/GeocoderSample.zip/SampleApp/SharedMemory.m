#import "SharedMemory.h"

@implementation SharedMemory

@synthesize mapObjects, searchResultObjects, mapView;

+ (id)sharedInstance {
    static SharedMemory *sharedMemory = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedMemory = [[self alloc] init];
    });
    return sharedMemory;
}

- (id)init {
    if (self = [super init]) {
        mapObjects = [NSMutableArray array]; //all objects that currently added to mapView
        searchResultObjects = [NSMutableArray array]; //temporary search result map objects
    }
    return self;
}

+(NMAGeoCoordinates*)getCurrentPosition
{
    NMAGeoCoordinates *geoCoordCenter = nil;
    NMAGeoPosition* pos = [[NMAPositioningManager sharedPositioningManager] currentPosition];
    NSLog(@"is active? %i", [[NMAPositioningManager sharedPositioningManager] isActive]);
    if (pos)
    {
        NSLog(@"Using current position..");
        geoCoordCenter = pos.coordinates;
    }
    else //default
    {
        NSLog(@"Using mock position..");
        geoCoordCenter = [[NMAGeoCoordinates alloc] initWithLatitude:52.530421 longitude:13.385141];
    }
    return geoCoordCenter;
}

-(void)saveCurrentMapViewState
{
    assert(mapView);
    geoCenter = [self.mapView geoCenter];
    mapZoomLevel = [self.mapView zoomLevel];
    mapTilt = [self.mapView tilt];
    orientation = [self.mapView orientation];
}

-(void)loadPreviousMapViewState
{
    assert(mapView);
    CGPoint screenCenter = CGPointMake(([UIScreen mainScreen].bounds.size.width)/2, ([UIScreen mainScreen].bounds.size.height)/2);
    [self.mapView setGeoCoordinates: geoCenter
                            toPoint: screenCenter
                      withAnimation:NMAMapAnimationRocket
                          zoomLevel:mapZoomLevel orientation: orientation tilt:mapTilt];
}

@end
