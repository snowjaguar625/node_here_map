#import <UIKit/UIKit.h>
#import <NMAKit/NMAKit.h>
#import "ResultsViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface MainViewController : UIViewController<NMAMapViewDelegate,
                                                 NMAMapGestureDelegate,
                                                 UITextFieldDelegate,
                                                 ResultsViewControllerDelegate,
                                                 NMANavigationManagerDelegate>
{
    SharedMemory * sharedMemory;
    BOOL navigationRunning;
    NMANavigationManager * navigationManager;
}

//properties
@property(nonatomic,strong) NSArray* placeLinks;

//UI properties
@property (weak, nonatomic) IBOutlet UITextField *searchTextField;
@property (weak, nonatomic) IBOutlet UIButton *cancelButton;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *searchTextFieldRightConstraint;
@property (weak, nonatomic) IBOutlet UIButton *myLocationButton;

@property (nonatomic, strong) ResultsViewController * activeResultsVC;

- (IBAction)centerTouched:(id)sender;
- (IBAction)cancelButtonTouched:(id)sender;


@end
