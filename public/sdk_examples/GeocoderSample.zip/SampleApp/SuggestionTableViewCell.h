#import <UIKit/UIKit.h>

@interface SuggestionTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *suggestionLabel;

@end
