/**
 * Copyright (c) 2014 HERE. All rights reserved.
 * This software is the confidential and proprietary information of HERE.
 * You shall not disclose such confidential information and shall use it only in
 * accordance with the terms of the license agreement you entered into with HERE.
 */
package com.here.platform.examples.RME_PDE_Java_Example;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.HttpContext;

public class LinkAttributeLookup {

  private Set<String> loadedTiles; // Remember which tiles we already loaded. Key = FC|Layer|Level|tileX|tileY
  private Map<Integer,String[]> linkRoadAttributes; // Extracted and cached from loaded tiles: Key = LinkID, Value = [IsoCountryCode,Urban,RouteTypes]
  List<String> linkRoadAttrColumnNames; // populated during first call
  private Map<Integer,String[]> linkSpeedLimits; // Extracted and cached from loaded tiles: Key = LinkID, Value = [SpeedLimitKph]
  List<String> linkSpeedColumnNames; // populated during first call
  private CloseableHttpClient httpClient;
  private HttpContext httpClientContext;
  private String baseUrl;
  private String appId;
  private String appCode;
  private String mapVersion;
  public int numTilesRead = 0;
  public int totalWaitTime = 0;

  public LinkAttributeLookup(String baseUrl, String appId, String appCode, String mapVersion) throws Exception {
    this.baseUrl = baseUrl;
    this.appId = appId;
    this.appCode = appCode;
    this.mapVersion = mapVersion;
    loadedTiles = new HashSet<String>(); // Remember which tiles we already loaded. Key = FC|Layer|Level|tileX|tileY
    linkRoadAttributes = new HashMap<Integer,String[]>();
    linkRoadAttrColumnNames = new ArrayList<String>();
    linkSpeedLimits    = new HashMap<Integer,String[]>();
    linkSpeedColumnNames = new ArrayList<String>();
    httpClient = HttpClients.createDefault();
    httpClientContext = HttpClientContext.create();
  }

  /**
   * 
   * @param linkId
   * @param shapeCoordsLatLon
   * @param functionalClass
   * @return List of attribute values
   * @throws Exception
   */
  public String[] getLinkRoadAttributes(int linkId, double shapeCoordsLatLon[], byte functionalClass) throws Exception {
    loadAndCacheTile(mapVersion, shapeCoordsLatLon, functionalClass, "LINK_ATTRIBUTE_FC", linkRoadAttributes, linkRoadAttrColumnNames);
    String attrs[] = linkRoadAttributes.get(Math.abs(linkId));
    if (attrs == null)
      throw new Exception("Cannot find link " + linkId + " in the road attribute tiles");
    return attrs;
  }

  /**
   * 
   * @param linkId
   * @param shapeCoordsLatLon
   * @param functionalClass
   * @return List of attribute values
   * @throws Exception
   */
  public String[] getLinkSpeedAttributes(int linkId, double shapeCoordsLatLon[], byte functionalClass) throws Exception {
    loadAndCacheTile(mapVersion, shapeCoordsLatLon, functionalClass, "SPEED_LIMITS_FC", linkSpeedLimits, linkSpeedColumnNames);
    String attrs[] = linkSpeedLimits.get(Math.abs(linkId));
    return attrs;
  }

  private void loadAndCacheTile(String mapVersion, double shapeCoordsLatLon[], int fc, String layerName, Map<Integer,String[]> attributes, List<String> columnNames) throws Exception {
    double lat = shapeCoordsLatLon[0];
    double lon = shapeCoordsLatLon[1];
    int level = fc + 8; // different zoom level for each functional class
    double tileSizeDegree = 180.0 / (1 << level);
    int tileY = (int)Math.floor((lat +  90.0) / tileSizeDegree);
    int tileX = (int)Math.floor((lon + 180.0) / tileSizeDegree);
    String tileCacheKey = fc + "|" + layerName + fc + "|" + level + "|" + tileX + "|" + tileY;
    if (loadedTiles.contains(tileCacheKey))
      return;
    long startTime = System.currentTimeMillis();
    String url = "http://" + baseUrl + "/1/tile.txt?release=" + mapVersion + "&layer=" + layerName + fc +
                 "&level=" + level + "&tilex=" + tileX + "&tiley=" + tileY + "&app_id=" + appId + "&app_code=" + appCode;
    HttpRequestBase httpReq = new HttpGet(url);
    System.out.println(url);
    HttpResponse response = httpClient.execute(httpReq, httpClientContext);
    int statusCode = response.getStatusLine().getStatusCode();
    if (statusCode != HttpStatus.SC_OK) { // read response body for error information
      String errorContent;
      try (InputStream is = response.getEntity().getContent())
      {
        try (OutputStream os = new ByteArrayOutputStream())
        {
          byte buf[] = new byte[4096];
          while (true)
          {
            int n = is.read(buf);
            if (n <= 0) break;
            os.write(buf, 0, n);
          }
          errorContent = os.toString();
        }
      }
      String reason = response.getStatusLine().getReasonPhrase();
      httpReq.abort();
      throw new Exception("HTTP request (" + url + ") failed: Status " + statusCode + " - " + reason + ", response content: " + errorContent);
    }
    try (BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()))) {
      String line = br.readLine();
      if (line == null) throw new Exception("Empty ressponse without header line");
      int columnLinkId = -1;
      if (columnNames.isEmpty())
        for (String n : line.split("\t", -1))
          columnNames.add(n);
      for (int i = 0; columnLinkId == -1 && i < columnNames.size(); i++)
        if (columnNames.get(i).equalsIgnoreCase("LINK_ID"))
            columnLinkId = i;
      if (columnLinkId == -1) throw new Exception("LINK_ID missing in the result");
      while (true) {
        line = br.readLine();
        if (line == null) break;
        String attrs[] = line.split("\t", -1);
        attributes.put(Integer.parseInt(attrs[columnLinkId]), attrs);
      }
    }
    loadedTiles.add(tileCacheKey);
    numTilesRead++;
    totalWaitTime += System.currentTimeMillis() - startTime;
  }
}
