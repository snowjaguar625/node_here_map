1. Extract the ZIP archive on your local disk.
2. Store your trace files into the "example_routes" folder.
3. You can remove the other example traces from there.
4. run_test.bat
5. For each trace file, 2 additional files _route.txt and _matched.txt are generated.
6. ResultVisualizer.html
7. In the file chooser, select both the _route.txt and _matched.txt files (control key).
8. The route is drawn, and the raw (gray) trace points and matched (green/red) trace points on top.
