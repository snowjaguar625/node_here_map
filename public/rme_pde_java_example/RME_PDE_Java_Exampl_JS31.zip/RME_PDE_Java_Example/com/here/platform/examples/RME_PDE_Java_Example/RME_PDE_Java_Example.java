/**
 * Copyright (c) 2014 - 2015 HERE. All rights reserved.
 * This software is the confidential and proprietary information of HERE.
 * You shall not disclose such confidential information and shall use it only in
 * accordance with the terms of the license agreement you entered into with HERE.
 */
package com.here.platform.examples.RME_PDE_Java_Example;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.FileEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.HttpContext;

public class RME_PDE_Java_Example {

  private CloseableHttpClient httpClient;
  private HttpContext httpClientContext;
  private LinkAttributeLookup linkAttributeLookup;
  private String appId;
  private String appCode;
  private long routeMatchWaitTime;

  public static void main ( String args[] ) {
    try {
      String routeMatchBaseUrl = null;
      String smapBaseUrl       = null;
      String routesDir         = null;
      String appId             = null;
      String appCode           = null;
      
      for (int a = 0; a < args.length; a++) {
        switch (args[a]) {
          case "-routeMatchBaseUrl": routeMatchBaseUrl = args[++a]; break;
          case "-smapBaseUrl"      : smapBaseUrl       = args[++a]; break;
          case "-routesDir"        : routesDir         = args[++a]; break;
          case "-appId"            : appId             = args[++a]; break;
          case "-appCode"          : appCode           = args[++a]; break;
          default: printUsage(); throw new Exception("Unknown command line argument '" + args[a] + "'");
        }
      }
      if (routeMatchBaseUrl == null || smapBaseUrl == null || routesDir == null || appId == null || appCode == null) {
        printUsage();
        throw new Exception("Missing command line argument");
      }
      
      List<File> searchFilesToDo = new ArrayList<File>();
      searchFilesToDo.add(new File(routesDir));
      while (!searchFilesToDo.isEmpty()) {
        File f = searchFilesToDo.remove(0);
    	if (f.isDirectory()) {
    	  for (File ff : f.listFiles())
    		searchFilesToDo.add(ff);
    	} else {
    	  String n = f.getName().toLowerCase();
    	  if (n.endsWith(".gpx") || n.endsWith(".nmea") || n.endsWith(".csv"))
    		new RME_PDE_Java_Example(routeMatchBaseUrl, smapBaseUrl, f, appId, appCode);
    	}
      }
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  private static void printUsage()
  {
    System.out.println("Command line arguments:\n\n");
    System.out.println("  -routeMatchBaseUrl <host/resource prefix> mandatory, e.g. rme.cit.api.here.com/\n\n");
    System.out.println("  -smapBaseUrl <host/resource prefix> mandatory, e.g. pde.cit.api.here.com/\n\n");
    System.out.println("  -routesDir <file path> mandatory\n\n");
    System.out.println("             All CSV, GPX, NMEA files from this directory and subdirectories are matched.\n\n");
    System.out.println("  -appId <app_id> mandatory\n\n");
    System.out.println("  -appCode <app_code> mandatory\n\n");
}

  private RME_PDE_Java_Example(String routeMatchBaseUrl, String smapBaseUrl, File routesFileOrDir, String appId, String appCode) throws Exception {
    this.appId = appId;
    this.appCode = appCode;
    this.httpClient = HttpClients.createDefault();
    this.httpClientContext = HttpClientContext.create();
    long timeStart = System.currentTimeMillis();
    double routeLength = matchAndAttributeTraceFiles(routesFileOrDir, smapBaseUrl, routeMatchBaseUrl);
    System.out.println("  Elapsed time total " + (System.currentTimeMillis() - timeStart)/1000 + " sec for " + Math.round(routeLength / 1000.0) + "km, " +
                       "RME time " + routeMatchWaitTime /1000 + " sec, PDE time " + linkAttributeLookup.totalWaitTime / 1000 + " sec.");
  }

  private double matchAndAttributeTraceFiles(File routesFileOrDir, String smapBaseUrl, String routeMatchBaseUrl) throws Exception
  {
    if (!routesFileOrDir.exists())
      throw new Exception("File or Directory '" + routesFileOrDir + "' does not exist");
    List<TracePoint> tracePoints = new ArrayList<>();
    List<RouteLink> routeLinks = new ArrayList<>();

    // Match the points into a route

    String mapVersion = sendRouteRequestAndAddRouteLinks(routesFileOrDir, tracePoints, routeLinks, routeMatchBaseUrl);
    if (linkAttributeLookup == null)
      linkAttributeLookup = new LinkAttributeLookup(smapBaseUrl, appId, appCode, mapVersion); // we can initialize it now, because we know router's map version

    // Write the results into files

    File routeFile = new File(routesFileOrDir.getPath().replace(".csv", "").replace(".gpx", "").replace(".nmea", "") + "_route.txt");
    try (BufferedWriter w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(routeFile)))) {
    	w.write("seq_num,link_id,iso_country_code,functional_class,urban,route_types,speed_limit_mps,shape_length,shape\r\n");
    	int linkSeqNum = 0;
    	for (RouteLink rl : routeLinks) {

    		// lookup road attributes

    		String attrs[] = linkAttributeLookup.getLinkRoadAttributes(rl.linkId, rl.shapeCoordsLatLon, rl.functionalClass);
    		List<String> attrNames = linkAttributeLookup.linkRoadAttrColumnNames;
    		String isoCountryCode = null;
    		boolean urban = false;
    		int routeTypes = -1;
    		for (int i = 0; i < attrNames.size(); i++) {
    			switch (attrNames.get(i).toUpperCase()) {
    				case "ISO_COUNTRY_CODE": isoCountryCode = attrs[i]; break;
    				case "URBAN"           : urban = attrs[i].equals("Y"); break;
    				case "ROUTE_TYPES"     : routeTypes = Integer.parseInt(attrs[i]); break;
    			}
    		}
    		if (isoCountryCode == null) throw new Exception("ISO_COUNTRY_CODE missing in the result");
    		if (routeTypes == -1) throw new Exception("ROUTE_TYPES missing in the result");

    		// lookup speed limit

    		attrs = linkAttributeLookup.getLinkSpeedAttributes(rl.linkId, rl.shapeCoordsLatLon, rl.functionalClass);
    		attrNames = linkAttributeLookup.linkSpeedColumnNames;
    		rl.speedLimitMps = -1;
    		for (int i = 0; attrs != null && i < attrNames.size(); i++) {
    			if (attrs[i] == null || attrs[i].equals("null")) continue;
    			switch (attrNames.get(i).toUpperCase()) {
    				case "FROM_REF_SPEED_LIMIT":
    					if (rl.linkId > 0) rl.speedLimitMps = Integer.parseInt(attrs[i]) / 3.6;
    					break;
    				case "TO_REF_SPEED_LIMIT":
    					if (rl.linkId < 0) rl.speedLimitMps = Integer.parseInt(attrs[i]) / 3.6;
    					break;
    			}
    		}
    		w.write((linkSeqNum++) + "," + rl.linkId + "," + isoCountryCode + "," + rl.functionalClass + "," + (urban ? "U" : "R") + "," + routeTypes + "," + rl.speedLimitMps + "," + rl.length + ",");
    		for (int i = 0; i < rl.shapeCoordsLatLon.length; i += 2)
    			w.write((i == 0 ? "" : " ") + rl.shapeCoordsLatLon[i] + " " + rl.shapeCoordsLatLon[i + 1]);
    		w.write("\r\n");
    	}
    }

    File fileMatched = new File(routesFileOrDir.getPath().replace(".csv", "").replace(".gpx", "").replace(".nmea", "") + "_matched.txt");
    try (BufferedWriter w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileMatched)))) {
    	w.write("seq_num,lat,lon,elevation,speed_mps,lat_matched,lon_matched,link_id_matched,speed_limit_mps_matched,timestamp\r\n");
    	for (int i = 0; i < tracePoints.size(); i++) {
    		TracePoint p = tracePoints.get(i);
    		// we already looked up the link speed limits on the route above
    		w.write(i + "," + p.lat + "," + p.lon + "," + p.elevation + "," + p.speedMps + "," +
    				p.latMatched + "," + p.lonMatched + "," + p.linkMatched.linkId + "," + p.linkMatched.speedLimitMps + "," + new Date(p.timestamp) + "\r\n");
    	}
    }

    // compute route length
    double routeLength = 0;
    for (RouteLink rl : routeLinks) {
      routeLength += rl.length;
    }
    return routeLength;
  }

  private String sendRouteRequestAndAddRouteLinks(File traceFile, List<TracePoint> tracePoints, List<RouteLink> routeLinks, String routeMatchBaseUrl) throws Exception {
    String mapVersion = null;
    String url = "http://" + routeMatchBaseUrl + "/2/matchroute.txt?app_id=" + appId + "&app_code=" + appCode;
    long startTime = System.currentTimeMillis(); 
    try (BufferedReader r = new BufferedReader(new InputStreamReader(httpRequest(url, traceFile), "UTF-8"))) {
      /* RouteLinks: 4
         linkId,functionalClass,linkLength,shape
         555309127,5,24.234732152419987,41.8656387 12.3731298 41.8656807 12.3734503
         555309126,5,46.11148479987003,41.8656807 12.3734503 41.8656807 12.3736496 41.8656807 12.3738403 41.8657494 12.3740501
         55601767,5,99.4727806357305,41.8657494 12.3740501 41.8657913 12.37428 41.8658981 12.3744802 41.8660812 12.37463 41.8662491 12.3747797 41.8663788 12.3748703 41.8664513 12.3748598
         703993459,5,9.581359557457228,41.8664513 12.3748598 41.8665314 12.3749304
         TracePoints: 2
         lat,lon,elevation,speedMps,heading,latMatched,lonMatched,linkIdMatched
         41.865973,12.372682,0.0,0.0,0.0,41.8656387,12.3731298,555309127
         41.866455,12.374999,0.0,0.0,0.0,41.8665014399771,12.37490399328818,703993459
         Warnings: 1
         Ignoring input file column 'seq_num'
         MapVersion: 2013Q3 */
      String line = r.readLine();
      if (!line.startsWith("RouteLinks:")) throw new Exception("Response parse error: Expected line 'RouteLinks: N' but got '" + line + "'");
      int n = Integer.parseInt(line.substring(11).trim());
      line = r.readLine();
      if (!line.equals("linkId,functionalClass,linkLength,shape,confidence")) throw new Exception("Response parse error: Expected line 'linkId,functionalClass,linkLength,shape' but got '" + line + "'");
      for (int i = 0; i < n; i++) {
        String a[] = r.readLine().split(",", -1);
        String co[] = a[3].split(" ", -1);
        double coordsLatLon[] = new double[co.length];
        for (int c = 0; c < co.length; c++)
          coordsLatLon[c] = Double.parseDouble(co[c]);
        routeLinks.add(new RouteLink(Integer.parseInt(a[0]), Byte.parseByte(a[1]), Double.parseDouble(a[2]), coordsLatLon));
      }

      line = r.readLine();
      if (!line.startsWith("TracePoints:")) throw new Exception("Response parse error: Expected line 'TracePoints: N' but got '" + line + "'");
      n = Integer.parseInt(line.substring(12).trim());
      line = r.readLine();
      String expectedAttrs = "lat,lon,elevation,speedMps,heading,latMatched,lonMatched,linkIdMatched,routeSeqNrMatched,timestamp,matchDist,headingMatched,minError,confidenceValue";
      if (!line.equals(expectedAttrs)) throw new Exception("Response parse error: Expected line '" + expectedAttrs + "' but got '" + line + "'");
      for (int i = 0; i < n; i++) {
        String a[] = r.readLine().split(",", -1);
        tracePoints.add(new TracePoint(Double.parseDouble(a[0]), Double.parseDouble(a[1]), Double.parseDouble(a[2]), Double.parseDouble(a[3]), Double.parseDouble(a[4]),
                                       Double.parseDouble(a[5]), Double.parseDouble(a[6]), Integer.parseInt(a[7]), Long.parseLong(a[9]), routeLinks));
      }
      line = r.readLine();
      if (!line.startsWith("Warnings:")) throw new Exception("Response parse error: Expected line 'Warnings: N' but got '" + line + "'");
      n = Integer.parseInt(line.substring(9).trim());
      line = r.readLine();
      expectedAttrs = "category,routelinkSeqnum,waypointseqnum,text";
      if (!line.equals(expectedAttrs)) throw new Exception("Response parse error: Expected line '" + expectedAttrs + "' but got '" + line + "'");
      
      for (int i = 0; i < n; i++) {
        System.out.println(r.readLine());
      }
      line = r.readLine();
      if (!line.startsWith("MapVersion:")) throw new Exception("Response parse error: Expected line 'MapVersion: Q' but got '" + line + "'");
      mapVersion = line.substring(11).trim();
    }
    routeMatchWaitTime += System.currentTimeMillis() - startTime;
    return mapVersion;
  }

  private InputStream httpRequest(String url, File postContent) throws Exception
  {
    System.out.println(url + "\n  " + postContent.getPath());
    HttpPost httpReq = new HttpPost(url);
    FileEntity entity = new FileEntity(postContent, ContentType.create("application/octet-stream", "UTF-8"));        
    httpReq.setEntity(entity);
    HttpResponse response = httpClient.execute(httpReq, httpClientContext);
    int statusCode = response.getStatusLine().getStatusCode();
    if (statusCode != HttpStatus.SC_OK)
    {
      // read response body for error information
      String errorContent;
      try (InputStream is = response.getEntity().getContent())
      {
        try (OutputStream os = new ByteArrayOutputStream())
        {
          byte buf[] = new byte[4096];
          while (true)
          {
            int n = is.read(buf);
            if (n <= 0) break;
            os.write(buf, 0, n);
          }
          errorContent = os.toString();
        }
      }
      String reason = response.getStatusLine().getReasonPhrase();
      httpReq.abort();
      throw new Exception("HTTP request (" + url + ") failed: Status " + statusCode + " - " + reason + ", response content: " + errorContent);
    }
    return response.getEntity().getContent();
  }

}
