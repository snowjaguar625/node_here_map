/**
 * Copyright (c) 2014 - 2015 HERE. All rights reserved.
 * This software is the confidential and proprietary information of HERE.
 * You shall not disclose such confidential information and shall use it only in
 * accordance with the terms of the license agreement you entered into with HERE.
 */
package com.here.platform.examples.RME_PDE_Java_Example;

import java.util.List;

public class TracePoint {
  double lat;
  double lon;
  double elevation;
  double speedMps;
  double heading;
  double latMatched;
  double lonMatched;
  long timestamp;
  RouteLink linkMatched;

  TracePoint(double lat, double lon, double elevation, double speedMps, double heading,
             double latMatched, double lonMatched, int linkIdMatched, long timestamp, List<RouteLink> routeLinks) throws Exception {
    this.lat           = lat;
    this.lon           = lon;
    this.elevation     = elevation;
    this.speedMps      = speedMps;
    this.heading       = heading;
    this.latMatched    = latMatched;
    this.lonMatched    = lonMatched;
    this.timestamp     = timestamp;
    for (RouteLink rl : routeLinks) {
      if (rl.linkId == linkIdMatched) {
        linkMatched = rl;
        break;
      }
    }
    if (linkMatched == null)
      throw new Exception("Couldn't find link " + linkIdMatched + " within route links");
  }
}
