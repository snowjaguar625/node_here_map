/**
 * Copyright (c) 2014 HERE. All rights reserved.
 * This software is the confidential and proprietary information of HERE.
 * You shall not disclose such confidential information and shall use it only in
 * accordance with the terms of the license agreement you entered into with HERE.
 */
package com.here.platform.examples.RME_PDE_Java_Example;

public class RouteLink
{
  int linkId;
  byte functionalClass;
  double shapeCoordsLatLon[]; // sorted in driving direction
  double speedLimitMps;
  double length;

  RouteLink(int linkId, byte functionalClass, double length, double shapeCoordsLatLon[])
  {
    this.linkId          = linkId;
    this.functionalClass = functionalClass;
    this.length          = length;
    this.shapeCoordsLatLon = shapeCoordsLatLon;
  }
}
